library(readr)
#library(magrittr)
library(stringr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(sf)
library(lubridate)
#library(parallel)
#library(foreach)
library(raster)

####耐药菌数据####
isolates <- read_tsv('isolates.tsv')
names(isolates)
isolates.location.time <- isolates[!is.na(isolates$Location)&!is.na(isolates$`Collection date`), ]
#isolates.location.time.sp <- isolates.location.time[(grepl("-", isolates.location.time$`Collection date`)), ]
isolates.location.time.sp <- isolates.location.time[str_count(isolates.location.time$`Collection date`, "-") >= 1, ]


isolates.location.time.sp.lat <- isolates.location.time.sp[grepl("\\d",isolates.location.time.sp$`Lat/Lon`), ]
#isolates.location.time.sp.lat <- isolates.location.time.sp[!is.na(isolates.location.time.sp$`Lat/Lon`), ]

#isolates.location.time.sp.lat <- isolates.location.time.sp.lat[(!grepl("not",isolates.location.time.sp.lat$`Lat/Lon`))&
#                                                                 (!grepl("Not",isolates.location.time.sp.lat$`Lat/Lon`))&
#                                                                 (!grepl("Tilburg",isolates.location.time.sp.lat$`Lat/Lon`))&
#                                                                 (!grepl("restricted",isolates.location.time.sp.lat$`Lat/Lon`)), ]

sum(is.na(isolates.location.time.sp.lat$`AMR genotypes`))

paper.data<-isolates.location.time.sp.lat[,c("#Organism group",
                                             "Host",
                                             "Scientific name",
                                             "Method","Level",
                                             "Collection date",
                                             "AMRFinderPlus version",
                                             "AMRFinderPlus analysis type",
                                             "Lat/Lon",
                                             "Location",
                                             "Isolation source",
                                             "Isolation type",
                                             "BioSample")] %>% as.data.frame()





####经纬度转换####
paper.data$`Lat/Lon` <- gsub("/", " ", paper.data$`Lat/Lon`)
paper.data$`Lat/Lon` <- sapply(paper.data$`Lat/Lon`, function(x) {
  x <- gsub("([/'])([A-Za-z])", "\\1 \\2", x)
  x <- gsub("([0-9]+)([A-Za-z])", "\\1 \\2", x)
  return(x)
})
# 处理特殊值
paper.data <- paper.data %>%
  mutate(
    `Lat/Lon` = ifelse(`Lat/Lon` == "1°22'0 N 103°48'0 E", "1.367 N 103.8 E", 
                       ifelse(`Lat/Lon` == "6?12?52?_106?50?42?", "6.2006 S 106.845 E",
                              ifelse(`Lat/Lon` == "46°10' N 09°52' E", "46.1667 N 9.8667 E",
                                     ifelse(`Lat/Lon` == "44°29'37? N, 11°20'19? E", "44.4936 N 11.3386 E",
                                            ifelse(`Lat/Lon` =="44°41'53.7 N, 10°37'52.5 E", "44.69822 N 10.63128 E",
                                                   ifelse(`Lat/Lon` == "45°32'8.09 N, 10°12'52.99 E" ,"45.5356 N 10.21472 E",`Lat/Lon`))))))
  )


for (i in 1:nrow(paper.data)) {
  value <- paper.data$`Lat/Lon`[i]
  if (grepl("[a-zA-Z]", value)) {  # 判断是否包含字母
    parts <- strsplit(value, " ")
    lat <- as.numeric(parts[[1]][1])
    lon <- as.numeric(parts[[1]][3])
    if (parts[[1]][2] == "S") {
      lat <- -lat
    }
    if (parts[[1]][4] == "W") {
      lon <- -lon
    }
    paper.data$latitude[i] <- lat
    paper.data$longitude[i] <- lon
  }
}




sum(is.na(paper.data$latitude))
####日期处理####
# 定义一个函数来处理日期字符串  
sort(table(nchar(paper.data$`Collection date`)))
paper.data$`Collection date`[nchar(paper.data$`Collection date`)%in%c(17)][1:10]
process_date <- function(date_str) {  
  if (nchar(date_str) == 7) {  
    # 如果日期字符串长度为7（形如'2014-03'），则添加'-01'  
    return(as.Date(paste0(date_str, "-01"), format = "%Y-%m-%d"))  
  } else if (nchar(date_str) %in% c(10,17,20)) {  
    # 如果日期字符串长度为10（形如'2014-03-15'），则直接转换  
    return(as.Date(substring(date_str, 1, 10), format = "%Y-%m-%d"))  
  } else {  
    # 如果日期字符串格式不正确，返回NA  
    return(NA)  
  }  
}  

# 应用这个函数到 'Collection date' 列  
paper.data$`Collection date` <- sapply(paper.data$`Collection date`, process_date)
paper.data$`Collection date` <- as.Date(paper.data$`Collection date`, origin = "1970-01-01") 



nrow(subset(paper.data,`Collection date` < as.Date("2000-01-01")))
nrow(subset(paper.data,`Collection date` > as.Date("2022-12-31")))

paper.data <- subset(paper.data,`Collection date` >= as.Date("2000-01-01"))
paper.data <- subset(paper.data,`Collection date` <= as.Date("2022-12-31"))
paper.data <- paper.data[!is.na(paper.data$`Collection date`), ]




#####PM2.5#####
library(raster)
#library(rasterVis)
library(ncdf4)
#library(lattice)

paper.data$`Collection date`<-as.Date(paper.data$`Collection date`)
paper.data <- paper.data[paper.data$`Collection date` >= as.Date("2000-01-01"), ]
paper.data <- paper.data[paper.data$`Collection date` <= as.Date("2022-12-31"), ]
paper.data <- paper.data[!is.na(paper.data$`Collection date`), ]
# 存储所有 nc 文件的路径
nc_file_paths <- list.files("dof/Monthly/combined", pattern = ".nc$", full.names = TRUE)

# 创建一个列表来存储读取的 nc 数据



for (path in nc_file_paths) {
  matches <- regexpr("\\d{6}", path)
  a=regmatches(path, matches)
  nc_file <- ncdf4::nc_open(path)
  assign(a, nc_file)
  
}

paper.data$average_pm25_0<-NA
paper.data$average_pm25_1<-NA
paper.data$average_pm25_2<-NA
paper.data$average_pm25_3<-NA
paper.data$average_pm25_4<-NA
paper.data$average_pm25_5<-NA
paper.data$average_pm25_6<-NA
paper.data$average_pm25_7<-NA
paper.data$average_pm25_8<-NA
paper.data$average_pm25_9<-NA
paper.data$average_pm25_10<-NA
paper.data$average_pm25_11<-NA
paper.data$average_pm25_12<-NA

latitude <- ncvar_get(get("200001"), "latitude")
longitude <- ncvar_get(get("200001"), "longitude")
for (m in 1:nrow(paper.data)) {
  # 获取个体的时间、经纬度
  
  individual_lat <- paper.data$latitude[m]
  individual_lon <- paper.data$longitude[m]
  
  
  
  # 找到小于等于目标数的最大数的位置
  less_or_equal_latitude <- max(latitude[latitude <= individual_lat])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_latitude <-  min(latitude[latitude >= individual_lat])
  greater_or_equal_latitude <- less_or_equal_latitude+0.1
  # 找到小于等于目标数的最大数的位置
  less_or_equal_longitude <- max(longitude[longitude <= individual_lon])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_longitude <- min(longitude[longitude >= individual_lon])
  greater_or_equal_longitude <- less_or_equal_longitude+0.1
  
  
  for (n  in 0:12){
    individual_time <- floor_date(paper.data$`Collection date`[m], "month")-months(n)
    year_month <- format(individual_time, format = "%Y%m")
    nc_file  = get(year_month)
    
    
    r <- raster(t(ncvar_get(nc_file, "PM25"))[1300:1, ], xmn=min(longitude), xmx=max(longitude), ymn=min(latitude), ymx=max(latitude), crs=CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs+ towgs84=0,0,0"))
    #plot(r)
    # 获取对应点的 PM2.5 浓度值
    selected_pm25_values1 <- extract(r, cbind(less_or_equal_longitude,less_or_equal_latitude))#(x1,y1)
    selected_pm25_values2 <- extract(r, cbind(less_or_equal_longitude,greater_or_equal_latitude))#(x1,y2)
    selected_pm25_values3 <- extract(r, cbind(greater_or_equal_longitude,less_or_equal_latitude))#(x2,y1)
    selected_pm25_values4 <- extract(r, cbind(greater_or_equal_longitude,greater_or_equal_latitude))#(x2,y2)
    # 双线性插值法
    paper.data[[paste0("average_pm25_",n)]][m] <-(selected_pm25_values1  * (greater_or_equal_longitude - individual_lon)* (greater_or_equal_latitude - individual_lat) + 
                                                    selected_pm25_values2 *  (greater_or_equal_longitude - individual_lon) * (individual_lat - less_or_equal_latitude) +
                                                    selected_pm25_values3 * (individual_lon - less_or_equal_longitude) * (greater_or_equal_latitude - individual_lat) + 
                                                    selected_pm25_values4  * (individual_lon - less_or_equal_longitude)* (individual_lat - less_or_equal_latitude)) / 
      ((greater_or_equal_longitude - less_or_equal_longitude)*(greater_or_equal_latitude - less_or_equal_latitude))
    
    
  }
  print(m)
}
write.table(paper.data,"PM2.5_match1.csv",row.names=FALSE,col.names=TRUE,sep=",")


#####13-24####
library(raster)
#library(rasterVis)
library(ncdf4)
#library(lattice)

paper.data$`Collection date`<-as.Date(paper.data$`Collection date`)
paper.data <- paper.data[paper.data$`Collection date` >= as.Date("2000-01-01"), ]
paper.data <- paper.data[paper.data$`Collection date` <= as.Date("2022-12-31"), ]
paper.data <- paper.data[!is.na(paper.data$`Collection date`), ]
# 存储所有 nc 文件的路径
nc_file_paths <- list.files("dof/Monthly/combined", pattern = ".nc$", full.names = TRUE)

# 创建一个列表来存储读取的 nc 数据



for (path in nc_file_paths) {
  matches <- regexpr("\\d{6}", path)
  a=regmatches(path, matches)
  nc_file <- ncdf4::nc_open(path)
  assign(a, nc_file)
  
}
paper.data$average_pm25_13<-NA
paper.data$average_pm25_14<-NA
paper.data$average_pm25_15<-NA
paper.data$average_pm25_16<-NA
paper.data$average_pm25_17<-NA
paper.data$average_pm25_18<-NA
# paper.data$average_pm25_19<-NA
# paper.data$average_pm25_20<-NA
# paper.data$average_pm25_21<-NA
# paper.data$average_pm25_22<-NA
# paper.data$average_pm25_23<-NA
# paper.data$average_pm25_24<-NA


latitude <- ncvar_get(get("200001"), "latitude")
longitude <- ncvar_get(get("200001"), "longitude")
for (m in 1:nrow(paper.data)) {
  # 获取个体的时间、经纬度
  
  individual_lat <- paper.data$latitude[m]
  individual_lon <- paper.data$longitude[m]
  
  
  
  # 找到小于等于目标数的最大数的位置
  less_or_equal_latitude <- max(latitude[latitude <= individual_lat])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_latitude <-  min(latitude[latitude >= individual_lat])
  greater_or_equal_latitude <- less_or_equal_latitude+0.1
  # 找到小于等于目标数的最大数的位置
  less_or_equal_longitude <- max(longitude[longitude <= individual_lon])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_longitude <- min(longitude[longitude >= individual_lon])
  greater_or_equal_longitude <- less_or_equal_longitude+0.1
  
  
  for (n  in 13:18){
    individual_time <- floor_date(paper.data$`Collection date`[m], "month")-months(n)
    year_month <- format(individual_time, format = "%Y%m")
    nc_file  = get(year_month)
    
    
    r <- raster(t(ncvar_get(nc_file, "PM25"))[1300:1, ], xmn=min(longitude), xmx=max(longitude), ymn=min(latitude), ymx=max(latitude), crs=CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs+ towgs84=0,0,0"))
    #plot(r)
    # 获取对应点的 PM2.5 浓度值
    selected_pm25_values1 <- raster::extract(r, cbind(less_or_equal_longitude,less_or_equal_latitude))#(x1,y1)
    selected_pm25_values2 <- raster::extract(r, cbind(less_or_equal_longitude,greater_or_equal_latitude))#(x1,y2)
    selected_pm25_values3 <- raster::extract(r, cbind(greater_or_equal_longitude,less_or_equal_latitude))#(x2,y1)
    selected_pm25_values4 <- raster::extract(r, cbind(greater_or_equal_longitude,greater_or_equal_latitude))#(x2,y2)
    # 双线性插值法
    paper.data[[paste0("average_pm25_",n)]][m] <-(selected_pm25_values1  * (greater_or_equal_longitude - individual_lon)* (greater_or_equal_latitude - individual_lat) + 
                                                    selected_pm25_values2 *  (greater_or_equal_longitude - individual_lon) * (individual_lat - less_or_equal_latitude) +
                                                    selected_pm25_values3 * (individual_lon - less_or_equal_longitude) * (greater_or_equal_latitude - individual_lat) + 
                                                    selected_pm25_values4  * (individual_lon - less_or_equal_longitude)* (individual_lat - less_or_equal_latitude)) / 
      ((greater_or_equal_longitude - less_or_equal_longitude)*(greater_or_equal_latitude - less_or_equal_latitude))
    
    
  }
  print(m)
}
write.table(paper.data,"PM2.5_match13-24.csv",row.names=FALSE,col.names=TRUE,sep=",")









#####气温#####
library(raster)
library(rasterVis)
library(ncdf4)
library(lattice)

paper.data$`Collection date`<-as.Date(paper.data$`Collection date`)
paper.data <- paper.data[paper.data$`Collection date` >= as.Date("2000-01-01"), ]
paper.data <- paper.data[paper.data$`Collection date` <= as.Date("2022-12-31"), ]
paper.data <- paper.data[!is.na(paper.data$`Collection date`), ]
# 存储所有 nc 文件的路径
temp <- ncdf4::nc_open("dof/cru_ts4.07.1901.2022.tmp.dat.nc")
#plot(temp)
print(temp)

latitude <- ncvar_get(temp, "lat")
longitude <- ncvar_get(temp, "lon")
time   <- format(as.Date(ncvar_get(temp, "time"))-years(70), format = "%Y%m")
tmp_data <- ncdf4::ncvar_get(temp, "tmp")

dim(tmp_data)

paper.data$average_tmp_0<-NA
paper.data$average_tmp_1<-NA
paper.data$average_tmp_2<-NA
paper.data$average_tmp_3<-NA
paper.data$average_tmp_4<-NA
paper.data$average_tmp_5<-NA
paper.data$average_tmp_6<-NA
paper.data$average_tmp_7<-NA
paper.data$average_tmp_8<-NA
paper.data$average_tmp_9<-NA
paper.data$average_tmp_10<-NA
paper.data$average_tmp_11<-NA
paper.data$average_tmp_12<-NA

for (m in 1:nrow(paper.data)) {
  # 获取个体的时间、经纬度
  
  individual_lat <- paper.data$latitude[m]
  individual_lon <- paper.data$longitude[m]
  
  # 找到小于等于目标数的最大数的位置
  less_or_equal_latitude <- max(latitude[latitude <= individual_lat])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_latitude <-  min(latitude[latitude >= individual_lat])
  greater_or_equal_latitude <- less_or_equal_latitude+0.5
  # 找到小于等于目标数的最大数的位置
  less_or_equal_longitude <- max(longitude[longitude <= individual_lon])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_longitude <- min(longitude[longitude >= individual_lon])
  greater_or_equal_longitude <- less_or_equal_longitude+0.5
  
  
  for (n  in 0:12){
    individual_time <- floor_date(paper.data$`Collection date`[m], "month")- months(n)
    year_month <- format(individual_time, format = "%Y%m")
    
    #tmp_dataslice<- tmp_data[, ,  which(time ==year_month)]
    r <- raster(t(tmp_data[, ,  which(time ==year_month)])[360:1, ], xmn=min(longitude), xmx=max(longitude), ymn=min(latitude), ymx=max(latitude), crs=CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs+ towgs84=0,0,0"))
    #r <- flip(r, direction='y')
    #plot(r)
    # 获取对应的 温度 值
    
    selected_pm25_values1 <- extract(r, cbind(less_or_equal_longitude,less_or_equal_latitude))#(x1,y1)
    selected_pm25_values2 <- extract(r, cbind(less_or_equal_longitude,greater_or_equal_latitude))#(x1,y2)
    selected_pm25_values3 <- extract(r, cbind(greater_or_equal_longitude,less_or_equal_latitude))#(x2,y1)
    selected_pm25_values4 <- extract(r, cbind(greater_or_equal_longitude,greater_or_equal_latitude))#(x2,y2)
    # 双线性插值法
    
    paper.data[[paste0("average_tmp_",n)]][m] <-mean(c(selected_pm25_values1,selected_pm25_values2,selected_pm25_values3,selected_pm25_values4), na.rm = TRUE)
    #paper.data[[paste0("average_tmp_",n)]][m]  <-(selected_pm25_values1  * (greater_or_equal_longitude - individual_lon)* (greater_or_equal_latitude - individual_lat) + 
    #                                                 selected_pm25_values2 *  (greater_or_equal_longitude - individual_lon) * (individual_lat - less_or_equal_latitude) +
    #                                                 selected_pm25_values3 * (individual_lon - less_or_equal_longitude) * (greater_or_equal_latitude - individual_lat) + 
    #                                                 selected_pm25_values4  * (individual_lon - less_or_equal_longitude)* (individual_lat - less_or_equal_latitude)) / 
    # ((greater_or_equal_longitude - less_or_equal_longitude)*(greater_or_equal_latitude - less_or_equal_latitude))
    
  }
  print(m)
}

#####相对湿度#####
library(raster)
library(rasterVis)
library(ncdf4)
library(lattice)

paper.data$`Collection date`<-as.Date(paper.data$`Collection date`)
paper.data <- paper.data[paper.data$`Collection date` >= as.Date("2000-01-01"), ]
paper.data <- paper.data[paper.data$`Collection date` <= as.Date("2022-12-31"), ]
paper.data <- paper.data[!is.na(paper.data$`Collection date`), ]
# 存储所有 nc 文件的路径
temp <- ncdf4::nc_open("dof/cru_ts4.07.1901.2022.wet.dat.nc")
#plot(temp)
print(temp)

latitude <- ncvar_get(temp, "lat")
longitude <- ncvar_get(temp, "lon")
time   <- format(as.Date(ncvar_get(temp, "time"))-years(70), format = "%Y%m")
wet_data <- ncdf4::ncvar_get(temp, "wet")

dim(wet_data)

paper.data$average_wet_0<-NA
paper.data$average_wet_1<-NA
paper.data$average_wet_2<-NA
paper.data$average_wet_3<-NA
paper.data$average_wet_4<-NA
paper.data$average_wet_5<-NA
paper.data$average_wet_6<-NA
paper.data$average_wet_7<-NA
paper.data$average_wet_8<-NA
paper.data$average_wet_9<-NA
paper.data$average_wet_10<-NA
paper.data$average_wet_11<-NA
paper.data$average_wet_12<-NA

for (m in 1:nrow(paper.data)) {
  # 获取个体的时间、经纬度
  
  individual_lat <- paper.data$latitude[m]
  individual_lon <- paper.data$longitude[m]
  
  # 找到小于等于目标数的最大数的位置
  less_or_equal_latitude <- max(latitude[latitude <= individual_lat])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_latitude <-  min(latitude[latitude >= individual_lat])
  greater_or_equal_latitude <- less_or_equal_latitude+0.5
  # 找到小于等于目标数的最大数的位置
  less_or_equal_longitude <- max(longitude[longitude <= individual_lon])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_longitude <- min(longitude[longitude >= individual_lon])
  greater_or_equal_longitude <- less_or_equal_longitude+0.5
  
  
  for (n  in 0:12){
    individual_time <- floor_date(paper.data$`Collection date`[m], "month")- months(n)
    year_month <- format(individual_time, format = "%Y%m")
    
    #wet_dataslice<- wet_data[, ,  which(time ==year_month)]
    r <- raster(t(wet_data[, ,  which(time ==year_month)])[360:1, ], xmn=min(longitude), xmx=max(longitude), ymn=min(latitude), ymx=max(latitude), crs=CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs+ towgs84=0,0,0"))
    #r <- flip(r, direction='y')
    #plot(r)
    # 获取对应的 温度 值
    
    selected_pm25_values1 <- extract(r, cbind(less_or_equal_longitude,less_or_equal_latitude))#(x1,y1)
    selected_pm25_values2 <- extract(r, cbind(less_or_equal_longitude,greater_or_equal_latitude))#(x1,y2)
    selected_pm25_values3 <- extract(r, cbind(greater_or_equal_longitude,less_or_equal_latitude))#(x2,y1)
    selected_pm25_values4 <- extract(r, cbind(greater_or_equal_longitude,greater_or_equal_latitude))#(x2,y2)
    # 双线性插值法
    paper.data[[paste0("average_wet_",n)]][m] <-mean(c(selected_pm25_values1,selected_pm25_values2,selected_pm25_values3,selected_pm25_values4), na.rm = TRUE)
    
    #paper.data[[paste0("average_wet_",n)]][m]  <-(selected_pm25_values1  * (greater_or_equal_longitude - individual_lon)* (greater_or_equal_latitude - individual_lat) + 
    #                                                selected_pm25_values2 *  (greater_or_equal_longitude - individual_lon) * (individual_lat - less_or_equal_latitude) +
    #                                                selected_pm25_values3 * (individual_lon - less_or_equal_longitude) * (greater_or_equal_latitude - individual_lat) + 
    #                                                selected_pm25_values4  * (individual_lon - less_or_equal_longitude)* (individual_lat - less_or_equal_latitude)) / 
    #  ((greater_or_equal_longitude - less_or_equal_longitude)*(greater_or_equal_latitude - less_or_equal_latitude))
    
  }
  print(m)
}


#####降水#####
library(raster)
library(rasterVis)
library(ncdf4)
library(lattice)

paper.data$`Collection date`<-as.Date(paper.data$`Collection date`)
paper.data <- paper.data[paper.data$`Collection date` >= as.Date("2000-01-01"), ]
paper.data <- paper.data[paper.data$`Collection date` <= as.Date("2022-12-31"), ]
paper.data <- paper.data[!is.na(paper.data$`Collection date`), ]
# 存储所有 nc 文件的路径
temp <- ncdf4::nc_open("dof/cru_ts4.07.1901.2022.pre.dat.nc")
#plot(temp)
print(temp)

latitude <- ncvar_get(temp, "lat")
longitude <- ncvar_get(temp, "lon")
time   <- format(as.Date(ncvar_get(temp, "time"))-years(70), format = "%Y%m")
pre_data <- ncdf4::ncvar_get(temp, "pre")

dim(pre_data)

paper.data$average_pre_0<-NA
paper.data$average_pre_1<-NA
paper.data$average_pre_2<-NA
paper.data$average_pre_3<-NA
paper.data$average_pre_4<-NA
paper.data$average_pre_5<-NA
paper.data$average_pre_6<-NA
paper.data$average_pre_7<-NA
paper.data$average_pre_8<-NA
paper.data$average_pre_9<-NA
paper.data$average_pre_10<-NA
paper.data$average_pre_11<-NA
paper.data$average_pre_12<-NA

for (m in 1:nrow(paper.data)) {
  # 获取个体的时间、经纬度
  
  individual_lat <- paper.data$latitude[m]
  individual_lon <- paper.data$longitude[m]
  
  # 找到小于等于目标数的最大数的位置
  less_or_equal_latitude <- max(latitude[latitude <= individual_lat])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_latitude <-  min(latitude[latitude >= individual_lat])
  greater_or_equal_latitude <- less_or_equal_latitude+0.5
  # 找到小于等于目标数的最大数的位置
  less_or_equal_longitude <- max(longitude[longitude <= individual_lon])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_longitude <- min(longitude[longitude >= individual_lon])
  greater_or_equal_longitude <- less_or_equal_longitude+0.5
  
  
  for (n  in 0:12){
    individual_time <- floor_date(paper.data$`Collection date`[m], "month")- months(n)
    year_month <- format(individual_time, format = "%Y%m")
    
    #pre_dataslice<- t(pre_data[, ,  which(time ==year_month)])[360:1, ]
    r <- raster(t(pre_data[, ,  which(time ==year_month)])[360:1, ], xmn=min(longitude), xmx=max(longitude), ymn=min(latitude), ymx=max(latitude), crs=CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs+ towgs84=0,0,0"))
    #r <- flip(r, direction='y')
    #plot(r)
    # 获取对应的 温度 值
    
    selected_pm25_values1 <- extract(r, cbind(less_or_equal_longitude,less_or_equal_latitude))#(x1,y1)
    selected_pm25_values2 <- extract(r, cbind(less_or_equal_longitude,greater_or_equal_latitude))#(x1,y2)
    selected_pm25_values3 <- extract(r, cbind(greater_or_equal_longitude,less_or_equal_latitude))#(x2,y1)
    selected_pm25_values4 <- extract(r, cbind(greater_or_equal_longitude,greater_or_equal_latitude))#(x2,y2)
    # 双线性插值法
    paper.data[[paste0("average_pre_",n)]][m] <-mean(c(selected_pm25_values1,selected_pm25_values2,selected_pm25_values3,selected_pm25_values4), na.rm = TRUE)
    
    #paper.data[[paste0("average_pre_",n)]][m]  <-(selected_pm25_values1  * (greater_or_equal_longitude - individual_lon)* (greater_or_equal_latitude - individual_lat) + 
    #                                                selected_pm25_values2 *  (greater_or_equal_longitude - individual_lon) * (individual_lat - less_or_equal_latitude) +
    #                                                selected_pm25_values3 * (individual_lon - less_or_equal_longitude) * (greater_or_equal_latitude - individual_lat) + 
    #                                                selected_pm25_values4  * (individual_lon - less_or_equal_longitude)* (individual_lat - less_or_equal_latitude)) / 
    #  ((greater_or_equal_longitude - less_or_equal_longitude)*(greater_or_equal_latitude - less_or_equal_latitude))
    
  }
  print(m)
}
write.table(paper.data,"temp_wet_pre_match1.csv",row.names=FALSE,col.names=TRUE,sep=",")

####NDVI####
library(raster)
#library(rasterVis)
library(ncdf4)
#library(lattice)

paper.data$`Collection date`<-as.Date(paper.data$`Collection date`)
paper.data <- paper.data[paper.data$`Collection date` >= as.Date("2000-01-01"), ]
paper.data <- paper.data[paper.data$`Collection date` <= as.Date("2022-12-31"), ]
paper.data <- paper.data[!is.na(paper.data$`Collection date`), ]
# 存储所有 nc 文件的路径
nc_file_paths <- list.files("dof/NDVI", pattern = ".nc4$", full.names = TRUE)

# 创建一个列表来存储读取的 nc 数据



for (path in nc_file_paths) {
  matches <- regexpr("\\d{4}_\\d{2}", path)
  a=gsub('_', '', regmatches(path, matches))
  nc_file <- ncdf4::nc_open(path)
  ndvi_data <- ncvar_get(nc_file, "ndvi")
  ndvi_mean <- apply(ndvi_data, c(1, 2), mean)
  assign( paste0("NDVI",a)  , ndvi_mean)
  print(a)
}
nc_close(nc_file)
paper.data$average_NDVI_0<-NA
paper.data$average_NDVI_1<-NA

# nc_file
# latitude <- ncvar_get(get("nc_file"), "lat")
# longitude <- ncvar_get(get("nc_file"), "lon")
# ndvi_data <- ncvar_get(nc_file, "ndvi")
# dim(ndvi_data)
# ndvi_mean <- apply(ndvi_data, c(1, 2), mean)
# ndvi_first_time <- ndvi_data[,,1]

for (m in 1:nrow(paper.data)) {
  # 获取个体的时间、经纬度
  
  individual_lat <- paper.data$latitude[m]
  individual_lon <- paper.data$longitude[m]
  
  
  
  # 找到小于等于目标数的最大数的位置
  less_or_equal_latitude <- max(latitude[latitude <= individual_lat])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_latitude <-  min(latitude[latitude >= individual_lat])
  greater_or_equal_latitude <- less_or_equal_latitude+0.1
  # 找到小于等于目标数的最大数的位置
  less_or_equal_longitude <- max(longitude[longitude <= individual_lon])
  # 找到大于等于目标数的最小数的位置
  #greater_or_equal_longitude <- min(longitude[longitude >= individual_lon])
  greater_or_equal_longitude <- less_or_equal_longitude+0.1
  
  
  for (n  in 0:1){
    individual_time <- floor_date(paper.data$`Collection date`[m], "year")-months(n*6)
    year_month <- format(individual_time, format = "%Y%m")
    nc_file  = get(paste0("NDVI",year_month))
    
    r <- raster(t(nc_file) , xmn=min(longitude), xmx=max(longitude), ymn=min(latitude), ymx=max(latitude), crs=CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs+ towgs84=0,0,0"))
    #plot(r)
    # 获取对应点的 PM2.5 浓度值
    selected_pm25_values1 <- extract(r, cbind(less_or_equal_longitude,less_or_equal_latitude))#(x1,y1)
    selected_pm25_values2 <- extract(r, cbind(less_or_equal_longitude,greater_or_equal_latitude))#(x1,y2)
    selected_pm25_values3 <- extract(r, cbind(greater_or_equal_longitude,less_or_equal_latitude))#(x2,y1)
    selected_pm25_values4 <- extract(r, cbind(greater_or_equal_longitude,greater_or_equal_latitude))#(x2,y2)
    # 双线性插值法
    paper.data[[paste0("average_NDVI_",n)]][m] <-mean(c(selected_pm25_values1,selected_pm25_values2,selected_pm25_values3,selected_pm25_values4), na.rm = TRUE)
    # paper.data[[paste0("average_NDVI_",n)]][m] <-(selected_pm25_values1  * (greater_or_equal_longitude - individual_lon)* (greater_or_equal_latitude - individual_lat) + 
    #                                                 selected_pm25_values2 *  (greater_or_equal_longitude - individual_lon) * (individual_lat - less_or_equal_latitude) +
    #                                                 selected_pm25_values3 * (individual_lon - less_or_equal_longitude) * (greater_or_equal_latitude - individual_lat) + 
    #                                                 selected_pm25_values4  * (individual_lon - less_or_equal_longitude)* (individual_lat - less_or_equal_latitude)) / 
    #   ((greater_or_equal_longitude - less_or_equal_longitude)*(greater_or_equal_latitude - less_or_equal_latitude))
    
    
  }
  print(m)
}
write.table(paper.data,"NDVI_match.csv",row.names=FALSE,col.names=TRUE,sep=",")
