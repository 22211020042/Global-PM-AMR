library(rnaturalearthdata)
library(rnaturalearth)
library(ggplot2)
library(lwgeom)
library(sf)
library(ggpubr)
library(broom)
# install.packages("MASS")  
library(MASS)  
library(dplyr)
library(reshape2)
library(readxl)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)
crs_wintri <- "+proj=robin +lon_0=0 +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84 +units=m +no_defs"

# 创建地图边界
wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri)


# 获取世界地图数据
world <- ne_countries(returnclass = "sf")
names(world)

# 使用 st_as_sf() 函数将数据转换为 sf 格式
sf_data <- st_as_sf(paper.data, coords = c("longitude", "latitude"),crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")

# 进行投影转换
sf_data_transformed = st_transform(sf_data
                                   , crs_wintri
)


# # 使用特定投影（这里只是示例，可能需要根据实际需求选择合适的投影）
# p1=ggplot() +
#   geom_sf(data = wintri_outline,linewidth=0.01,color = "#cff3f7",fill="#cff3f7")+
#   geom_sf(data = world,fill="#bae382",linewidth=0.5, color = "white") +
#   geom_sf(data = sf_data_transformed,aes(color =`Isolation type`)) +
#   # scico::scale_fill_scico_d( palette = "bamako",direction =0.1)+
#   theme(plot.background = element_rect(fill="white"),
#         panel.background = element_rect(fill = "white"),
#         panel.grid = element_blank(),
#         legend.position = "right",  # 设置图例位置为右侧
#         legend.key.size = unit(1, "cm")) 
# p1

shp_data <- st_read("dof/FloodArchive_region.shp")
shp_data$BEGAN<-as.Date(shp_data$BEGAN)
shp_data$ENDED<-as.Date(shp_data$ENDED)
shp_data <- shp_data[shp_data$ENDED >= as.Date("2000-01-01"), ]
shp_data <- st_set_crs(shp_data, "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
shp_data = st_transform(shp_data, crs_wintri)

colors <-c("#C00000",
           "#FFB81C",
           #"#8B4513",
           "#578800", 
           "#5C88DA",
           
           "#ab4644",
           "#923A92",
           #"#2F4F4F",
           "#00AB84",
           "#FF6800",
           
           "#A6CEE3",
           "#562997",
           "#006400",
           '#25569B',
           '#DECBE4',
           
           '#2c6344',
           "#FFA07A",
           "#B2DF8A",
           "#BE922F",
           "#841D4D",
           "#A3A3A3")
sf_data_transformed$`Isolation type` <- ifelse(is.na(sf_data_transformed$`Isolation type`), "Not recorded", 
                                               ifelse(sf_data_transformed$`Isolation type`=="clinical", "Clinical",
                                                      ifelse(sf_data_transformed$`Isolation type`=="environmental/other", "Environmental/Other",sf_data_transformed$`Isolation type`)))

# sf_data_transformed<-cbind(sf_data_transformed,as.data.frame(PM2_5_match[14:15]))

names(sf_data_transformed)
p2.0=ggplot() +
  scale_fill_manual(values = colors)+
  geom_sf(data = wintri_outline,linewidth=0.01,color = "#cff3f7",fill="#cff3f7")+
  geom_sf(data = world,fill="#bae382", color = "white") +
  geom_sf(data = shp_data,linewidth=0.5,color = NA, fill = "#5caab2",alpha=0.3) +
  geom_sf(data = sf_data_transformed,aes(color =`Isolation type`),size=0.7,alpha=0.55) +
  
  
  # scico::scale_fill_scico_d( palette = "bamako",direction =0.1)+
  theme(plot.background = element_rect(fill="white"),
        panel.background = element_rect(fill = "white"),
        panel.grid = element_blank(),
        legend.position = c(0.2, 0.4),  # 设置图例位置
        legend.key.size = unit(0, "cm"),
        plot.margin = unit(c(0, 0, 0, 0), "cm")) +
  scale_color_manual(values = c("Clinical" = "#C00000", "Environmental/Other" = "#FFB81C","Not recorded"= "#A3A3A3"))
ggsave( p2.0,
        width = 5,height =8,
        filename =  paste0("p2.1.pdf"))

# p2.0
sf_data_transformed<-cbind(sf_data_transformed,as.data.frame(PM2_5_match[14:15]))

p2.1<-ggplot(sf_data_transformed, aes(x = latitude, y = average_pm25_0)) +
  geom_point(color = "#923A92",size=1,alpha=0.45)+
  
  labs(y='PM2.5',x=NULL)+
  scale_x_continuous(limits = c(-90,90),breaks = seq(-90,90,30))+
  #geom_smooth(method = "loess") +
  coord_flip()+
  theme_classic()
p2.1
p2.2<-ggplot(sf_data_transformed, aes(x = latitude, y = average_tmp_0)) +
  geom_point(color = "#FFA07A",size=1,alpha=0.45)+
  labs(y='Tempreture',x=NULL)+
  scale_x_continuous(limits = c(-90,90),breaks = seq(-90,90,30))+
  #geom_smooth(method = "loess") +
  coord_flip()+
  theme_classic()
p2.2
p2.3<-ggplot(sf_data_transformed, aes(x = latitude, y = average_pre_0)) +
  geom_point(color = "#006400",size=1,alpha=0.45)+
  labs(y='Precipitation',x=NULL)+
  scale_x_continuous(limits = c(-90,90),breaks = seq(-90,90,30))+
  #geom_smooth(method = "loess") +
  coord_flip()+
  theme_classic()
p2.3
p2=ggarrange(p2.1,p2.2,p2.3,nrow = 1,ncol = 3, labels = c(NA),font.label = list(size=12),widths = c(0.1,0.1,0.1),align = "h")

# p2.2 <- ggplot(sf_data_transformed, aes(x = latitude, y = average_tmp_0)) +
#   geom_smooth(method = "loess", se = FALSE) +  # Disable standard error calculation
#   coord_flip() +
#   theme_classic()

ggsave( p2,
        width = 5,height =8,
        filename =  paste0("p2.0.pdf"))

#####降水、气温、PM2.5####
library(readxl)
# library(rnaturalearthdata)
# library(rnaturalearth)
library(ggplot2)
# library(lwgeom)
library(sf)
library(reshape2)
library(car)

library(tidyverse)



# flood_match <- read_csv("flood_match_year.csv")
#flood_match <- paper.data[paper.data$`Collection date` <= as.Date("2022-12-31"), ]

PM2_5_match <- read_csv("PM2.5_match1.csv")

PM2_5_match13_24 <- read_csv("PM2.5_match13-24.csv")
names(PM2_5_match13_24)



names(PM2_5_match)
# PM2_5_match<-PM2_5_match%>%mutate(average_pm25=mean(PM2_5_match[,16:27],na.rm = TRUE))
temp_wet_pre_match <- read_csv("temp_wet_pre_match1.csv")
NDVI_match <- read_csv("NDVI_match.csv")

names(PM2_5_match)
names(temp_wet_pre_match)
names(NDVI_match)

paper.data <-cbind(PM2_5_match,temp_wet_pre_match[,16:54],NDVI_match[,16:17],PM2_5_match13_24[16:21])
names(paper.data)
paper.data$average_pm25=rowMeans(paper.data[16:27])
paper.data$average_tmp=rowMeans(paper.data[29:40])
paper.data$average_wet=rowMeans(paper.data[42:53])
paper.data$average_pre=rowMeans(paper.data[55:66])
paper.data$average_NDVI=rowMeans(paper.data[68:69])
paper.data <- paper.data %>% mutate(ID = paste(BioSample, `Scientific name`))

#####其他变量#####

# library(gtsummary)
WDI_面板数据 <- read_excel("dof/WDI-面板数据2000-2022.xlsx", 
                       sheet = "Data")

confounding <- subset(WDI_面板数据, 
                      `Indicator Name` == 'GDP per capita (constant 2015 US$)'|
                        `Indicator Name` == 'Population density (people per sq. km of land area)'|
                        `Indicator Name` == "Mortality rate, infant (per 1,000 live births)"|
                        `Indicator Name` == "Population ages 65 and above (% of total population)"|
                        `Indicator Name` == "PM2.5 air pollution, mean annual exposure (micrograms per cubic meter)"|
                        `Indicator Name` =="Current health expenditure per capita (current US$)"|
                        `Indicator Name` =="Hospital beds (per 1,000 people)"|
                        `Indicator Name` =="Labor force with advanced education (% of total working-age population with advanced education)"|
                        `Indicator Name` =="People using at least basic drinking water services (% of population)"|
                        `Indicator Name` =="People using safely managed drinking water services (% of population)"|
                        `Indicator Name` =="Access to electricity (% of population)")[-c(4,28)]
names(confounding)
a <- unique(confounding$`Country Name`)
confounding <- reshape2::melt(confounding, id.vars = c("Country Name", "Indicator Name","Country Code"), 
                              variable.name = "year", value.name = "value")

confounding <-dcast(confounding, `Country Name`+`Country Code`+ year  ~ `Indicator Name`, value.var = "value")

confounding$year<-as.numeric(as.character(confounding$year) )

confounding <- confounding %>% rename('GDP_per_capita'='GDP per capita (constant 2015 US$)',
                                      'Population_density'='Population density (people per sq. km of land area)',
                                      "Mortality_rate_of_infant"="Mortality rate, infant (per 1,000 live births)",
                                      "Population_ages_65_and_above"="Population ages 65 and above (% of total population)",
                                      "PM2.5_air_pollution"="PM2.5 air pollution, mean annual exposure (micrograms per cubic meter)",
                                      "Current_health_expenditure_per_capita"="Current health expenditure per capita (current US$)",
                                      "Hospital_beds"="Hospital beds (per 1,000 people)",
                                      "Labor_force_with_advanced_education"="Labor force with advanced education (% of total working-age population with advanced education)",
                                      "People_using_at_least_basic_drinking_water_services"="People using at least basic drinking water services (% of population)",
                                      "People_using_safely_managed_drinking_water_services"="People using safely managed drinking water services (% of population)",
                                      "Access_to_electricity"="Access to electricity (% of population)")




# 计算非数字行的数量  
sum(!sapply(confounding$Current_health_expenditure_per_capita, function(x) grepl("^[0-9]+(\\.[0-9]+)?$", x)) )  

grouped_df <- confounding %>%
  group_by(`Country Name`)

# 计算每个国家其他年份各变量的均值
filled_df <- grouped_df %>%
  mutate_at(vars(GDP_per_capita,
                 Population_density,
                 Mortality_rate_of_infant,
                 Population_ages_65_and_above,
                 Current_health_expenditure_per_capita,
                 People_using_at_least_basic_drinking_water_services,), funs(ifelse(is.na(.), mean(., na.rm = TRUE),.)))

confounding<-as.data.frame(filled_df)

sum(!sapply(confounding$Current_health_expenditure_per_capita, function(x) grepl("^[0-9]+(\\.[0-9]+)?$", x)) )  

rev(sort(table(confounding$Current_health_expenditure_per_capita)))


#####耐药基因####
# word <- read_tsv('microbigge (1).tsv')
# 
# #names(word)
gene_word <- word[,c("#Scientific name","BioSample","Element symbol","Class","Type")]
gene_word <- gene_word %>% rename("Scientific name" = "#Scientific name")

gene_word <- gene_word %>% mutate(ID = paste(BioSample, `Scientific name`))
# paper.data <- paper.data %>% mutate(ID = paste(BioSample, `Scientific name`))
gene_word <- gene_word[gene_word$ID %in% paper.data$ID, ]
gene_word_amr <- gene_word[gene_word$Type == "AMR", ]

gene.1 <- gene_word_amr %>%
  group_by(ID, `Element symbol`) %>%
  summarise(count = n()) %>%
  ungroup() %>%
  pivot_wider(names_from =`Element symbol`, values_from = count)

gene.1<-gene.1%>%mutate(total_gene = rowSums(gene.1[, 2:2415], na.rm = TRUE))

antibiotic.1 <- gene_word_amr %>%
  group_by(ID, Class) %>%
  summarise(count = n()) %>%
  ungroup() %>%
  pivot_wider(names_from =Class, values_from = count)

antibiotic.1<-antibiotic.1%>%
  mutate(total_antibiotic = rowSums(antibiotic.1[, 2:48], na.rm = TRUE))



#uncover <- isolates.location.time.sp.lat[!(isolates.location.time.sp.lat$BioSample %in% gene.1$BioSample), ]
#uncover <- paper.data[!(paper.data$BioSample %in% gene.1$BioSample), ]


#gene_antibiotic<-unique(gene_word[,c("Element symbol","Class","Type")])

all_ids <- data.frame(ID = unique(c(paper.data$ID, antibiotic.1$ID )))

# 左连接 df1 和 all_ids
merged_df1 <- merge(all_ids, paper.data, by = "ID", all.x = TRUE)

# 左连接 merged_df1 和 df2
paper.data.1 <- merge(merged_df1, antibiotic.1, by = "ID", all.x = TRUE)
names(paper.data.1)
paper.data.1[,82:129][is.na(paper.data.1[,82:129])] <- 0
paper.data.1$`MACROLIDE`<-paper.data.1$`MACROLIDE`+paper.data.1$`LINCOSAMIDE/MACROLIDE/STREPTOGRAMIN`+paper.data.1$`LINCOSAMIDE/MACROLIDE`+paper.data.1$`MACROLIDE/STREPTOGRAMIN`+paper.data.1$`MACROLIDE/BETA-LACTAM/TETRACYCLINE`
paper.data.1$`LINCOSAMIDE`<-paper.data.1$`LINCOSAMIDE`+paper.data.1$`LINCOSAMIDE/MACROLIDE/STREPTOGRAMIN`+paper.data.1$`LINCOSAMIDE/MACROLIDE`+paper.data.1$`LINCOSAMIDE/STREPTOGRAMIN`+paper.data.1$`LINCOSAMIDE/PLEUROMUTILIN/STREPTOGRAMIN`+paper.data.1$`PHENICOL/LINCOSAMIDE/OXAZOLIDINONE/PLEUROMUTILIN/STREPTOGRAMIN`
paper.data.1$`STREPTOGRAMIN`<-paper.data.1$`STREPTOGRAMIN`+paper.data.1$`LINCOSAMIDE/MACROLIDE/STREPTOGRAMIN`+paper.data.1$`MACROLIDE/STREPTOGRAMIN`+paper.data.1$`LINCOSAMIDE/STREPTOGRAMIN`+paper.data.1$`LINCOSAMIDE/PLEUROMUTILIN/STREPTOGRAMIN`+paper.data.1$`PHENICOL/LINCOSAMIDE/OXAZOLIDINONE/PLEUROMUTILIN/STREPTOGRAMIN`
paper.data.1$`PHENICOL`<-paper.data.1$`PHENICOL`+paper.data.1$`PHENICOL/QUINOLONE`+paper.data.1$`PHENICOL/OXAZOLIDINONE`+paper.data.1$`PHENICOL/LINCOSAMIDE/OXAZOLIDINONE/PLEUROMUTILIN/STREPTOGRAMIN`+paper.data.1$`PHENICOL/QUINOLONE/TRIMETHOPRIM`
paper.data.1$`QUINOLONE`<-paper.data.1$`QUINOLONE`+paper.data.1$`PHENICOL/QUINOLONE`+paper.data.1$`AMINOGLYCOSIDE/QUINOLONE`+paper.data.1$`QUINOLONE/TRICLOSAN`+paper.data.1$`PHENICOL/QUINOLONE/TRIMETHOPRIM`
paper.data.1$`AMINOGLYCOSIDE` <-paper.data.1$`AMINOGLYCOSIDE`+paper.data.1$`AMINOGLYCOSIDE/QUINOLONE`
paper.data.1$`ISONIAZID`<-paper.data.1$`ISONIAZID/TRICLOSAN`
paper.data.1$`BETA_LACTAM`<-paper.data.1$`BETA-LACTAM`+paper.data.1$`MACROLIDE/BETA-LACTAM/TETRACYCLINE`+paper.data.1$`BETA-LACTAM/QUINOLONE/TETRACYCLINE`
paper.data.1$`OXAZOLIDINONE`<-paper.data.1$`OXAZOLIDINONE`+paper.data.1$`PHENICOL/LINCOSAMIDE/OXAZOLIDINONE/PLEUROMUTILIN/STREPTOGRAMIN`
paper.data.1$`PLEUROMUTILIN`<-paper.data.1$`PLEUROMUTILIN`+paper.data.1$`LINCOSAMIDE/PLEUROMUTILIN/STREPTOGRAMIN`+paper.data.1$`PHENICOL/LINCOSAMIDE/OXAZOLIDINONE/PLEUROMUTILIN/STREPTOGRAMIN`
paper.data.1$`TRIMETHOPRIM`<-paper.data.1$`TRIMETHOPRIM`+paper.data.1$`PHENICOL/QUINOLONE/TRIMETHOPRIM`
paper.data.1$`FUSIDIC_ACID`<-paper.data.1$`FUSIDIC ACID`+paper.data.1$`FUSIDIC_ACID`
paper.data.1$`TRICLOSAN`<-paper.data.1$`QUINOLONE/TRICLOSAN`+paper.data.1$`ISONIAZID/TRICLOSAN`
paper.data.1$`QUATERNARY_AMMONIUM`<-paper.data.1$`QUATERNARY AMMONIUM`
paper.data.1$total_antibiotic[is.na(paper.data.1$total_antibiotic)] <- 0

#只剩国家名
extract_before_colon <- function(x) {
  strsplit(x, ":")[[1]][1]
}

# 应用函数到相应列
paper.data.1$Location <- sapply(paper.data.1$Location, extract_before_colon)

sum(is.na(paper.data.1$Location ))
b<-unique(paper.data.1$Location)
b[!b %in% a]
#替代国家名
replacement_dict <- c(
  "Egypt" = "Egypt, Arab Rep.", "Czech Republic" = "Czechia",
  "Hong Kong" = "Hong Kong SAR, China", "West Bank" = "West Bank and Gaza", 
  "USA" = "United States","Yemen" = "Yemen, Rep.",
  "South Korea" = "Korea, Rep.","Russia" = "Russian Federation", 
  "Taiwan" = "China","Venezuela" = "Venezuela, RB", 
  "Gaza Strip" = "West Bank and Gaza","Korea" = "Korea, Dem. People's Rep.", 
  "Democratic Republic of the Congo" = "Congo, Dem. Rep.",
  "Laos" = "Lao PDR","Iran" = "Iran, Islamic Rep.", 
  "Brunei" = "Brunei Darussalam","not collected" = "World", 
  "Turkey" = "Turkiye", "restricted access" = "World",
  "Gambia" = "Gambia, The","Indian Ocean" = "India", 
  "Bahamas" = "Bahamas, The","Reunion" = "France", 
  "Mediterranean Sea" = "World","Atlantic Ocean" = "World", 
  "Slovakia" = "Slovak Republic","Pacific Ocean" = "World"
  
)

# 定义函数用于替换单个数据框中的中文字符
replace_chinese_with_english <- function(df, replacement_dict) {
  for (i in 1:ncol(df)) {
    if (any(class(df[, i]) == "character")) {
      df[, i] <- ifelse(df[, i] %in% names(replacement_dict), 
                        replacement_dict[df[, i]], df[, i])
    }
  }
  return(df)
}

# 替换数据框中的中文字符为对应英文
paper.data.1 <- replace_chinese_with_english(paper.data.1, replacement_dict)

paper.data.1$year<- as.numeric(str_extract(paper.data.1$`Collection date`,"^\\d{4}")) 

paper.data.1 <- paper.data.1 %>% rename("Country Name" = "Location")
b<-unique(paper.data.1$`Country Name`)

total_antibiotic_consumption_estimates <- as.data.frame(read_csv("dof/total_antibiotic_consumption_estimates .csv")) 
c<-unique(total_antibiotic_consumption_estimates$Location)
a <- unique(confounding$`Country Name`)
c[!c %in% a]

writeLines(paste0("'",c[!c %in% a],"'=''",",") )
replacement_dict <- c(
  
  'Brunei'='Brunei Darussalam',
  'Cape Verde'='Cabo Verde',
  'Congo'='Congo, Rep.',
  # 'Cook Islands'='',
  'Czech Republic'='Czechia',
  
  'Egypt'='Egypt, Arab Rep.',
  # 'Federated States of Micronesia'='',
  
  'Iran'='Iran, Islamic Rep.',
  'Kyrgyzstan'='Kyrgyz Republic',
  'Laos'='Lao PDR',
  'Macedonia'='North Macedonia',
  
  # 'Niue'='',
  'North Korea'="Korea, Dem. People's Rep.",
  
  'Palestine'='West Bank and Gaza',
  'Russia'='Russian Federation',
  # 'Saint Kitts and Nevis'='',
  # 'Saint Lucia'='',
  'Saint Vincent and the Grenadines'='St. Vincent and the Grenadines',
  
  'Slovakia'='Slovak Republic',
  'South Korea'='Korea, Rep.',
  'Swaziland'='Eswatini',
  'Syria'='Syrian Arab Republi',
  # 'Taiwan'='',
  'The Bahamas'='Bahamas, The',
  'The Gambia'='Gambia, The',
  # 'Tokelau'='',
  
  'Turkey'='Turkiye',
  
  'Venezuela'='Venezuela, RB',
  'Vietnam'='Viet Nam',
  # 'Virgin Islands, U.S.'='',
  'Yemen'='Yemen, Rep.'
)


total_antibiotic_consumption_estimates <- replace_chinese_with_english(total_antibiotic_consumption_estimates, replacement_dict)
total_antibiotic_consumption_estimates <- total_antibiotic_consumption_estimates %>% rename("Country Name" = "Location","year"="Year")
c<-unique(total_antibiotic_consumption_estimates$Location)


# 将数据转换为宽格式
df_wide <- total_antibiotic_consumption_estimates %>%
  mutate(year = as.character(year)) %>% # 确保Year是字符类型以便pivot_wider
  pivot_wider(names_from = year, values_from = Antibiotic_consumption                              )

# 复制2018年的数据并添加新列
years_to_add <- 2019:2022
for (year in years_to_add) {
  df_wide[[as.character(year)]] <- df_wide$`2018`-2
}

# 转换数据回到长格式
df_long <- df_wide %>%
  pivot_longer(cols = -`Country Name`,
               names_to = "year",
               values_to = "Antibiotic_consumption") %>%
  mutate(year = as.integer(year))




confounding <- merge(confounding,df_long, by = c("Country Name","year"),all.x = TRUE)


paper.data.1 <- merge(paper.data.1, confounding, by = c("Country Name","year"),all.x = TRUE)
#paper.data <- paper.data[paper.data$`Collection date` <= as.Date("2021-10-11"), ]
names(paper.data.1)

paper.data.1 <-subset(paper.data.1,paper.data.1$`Country Name`!="Antarctica")

paper.data.1[] <- lapply(paper.data.1, function(col) {  
  if (is.numeric(col)) {  
    col[is.nan(col)] <- NA  
  }  
  return(col)  
})

cordata<-paper.data.1[,c(
  "average_pm25",
  "average_tmp",
  "average_pre",
  "average_NDVI",
  
  "GDP_per_capita", 
  
  "Population_density",
  "Mortality_rate_of_infant",
  "Population_ages_65_and_above",
  
  "Current_health_expenditure_per_capita",
  
  "People_using_at_least_basic_drinking_water_services")]

# 计算每列的均值（忽略NA值）  
column_means <- colMeans(cordata, na.rm = TRUE)  
# 遍历数据框的每一列，并用列均值替换NA值  
for (col_name in names(cordata)) {  
  cordata[is.na(cordata[[col_name]]), col_name] <- column_means[col_name]  
}


selected_columns <- c(  
  "average_pm25",  
  "average_tmp",  
  "average_pre", 
  "average_NDVI",
  "GDP_per_capita",  
  "Population_density",  
  "Mortality_rate_of_infant",  
  "Population_ages_65_and_above",  
  "Current_health_expenditure_per_capita",  
  "People_using_at_least_basic_drinking_water_services"  
)  

# 提取 paper.data.1 中不在 selected_columns 列表中的列名  
other_columns <- setdiff(colnames(paper.data.1), selected_columns)  

# 使用这些列名从 paper.data.1 中提取对应的列  
other_data <- paper.data.1[, other_columns] 

paper.data.1<-cbind(other_data,cordata)
names(paper.data.1)
#####0.描述性研究#####
######0.1地图####
library(rnaturalearthdata)
library(rnaturalearth)
library(ggplot2)
library(lwgeom)
library(sf)
library(ggpubr)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)
crs_wintri <- "+proj=robin +lon_0=0 +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84 +units=m +no_defs"

# 创建地图边界
wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri)


# 获取世界地图数据
world <- ne_countries(returnclass = "sf")
names(world)

# 使用 st_as_sf() 函数将数据转换为 sf 格式
sf_data <- st_as_sf(paper.data.1, coords = c("longitude", "latitude"),crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")

# 进行投影转换
sf_data_transformed = st_transform(sf_data
                                   , crs_wintri
)


# # 使用特定投影（这里只是示例，可能需要根据实际需求选择合适的投影）
# p1=ggplot() +
#   geom_sf(data = wintri_outline,linewidth=0.01,color = "#cff3f7",fill="#cff3f7")+
#   geom_sf(data = world,fill="#bae382",linewidth=0.5, color = "white") +
#   geom_sf(data = sf_data_transformed,aes(color =`Isolation type`)) +
#   # scico::scale_fill_scico_d( palette = "bamako",direction =0.1)+
#   theme(plot.background = element_rect(fill="white"),
#         panel.background = element_rect(fill = "white"),
#         panel.grid = element_blank(),
#         legend.position = "right",  # 设置图例位置为右侧
#         legend.key.size = unit(1, "cm")) 
# p1

# shp_data <- st_read("dof/FloodArchive_region.shp")
# shp_data$BEGAN<-as.Date(shp_data$BEGAN)
# shp_data$ENDED<-as.Date(shp_data$ENDED)
# shp_data <- shp_data[shp_data$ENDED >= as.Date("2000-01-01"), ]
# shp_data <- st_set_crs(shp_data, "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
# shp_data = st_transform(shp_data, crs_wintri)

colors <-c("#C00000",
           "#FFB81C",
           "#8B4513",
           "#578800", 
           "#5C88DA",
           
           "#ab4644",
           "#923A92",
           "#2F4F4F",
           "#00AB84",
           "#FF6800",
           
           "#A6CEE3",
           "#562997",
           "#006400",
           '#25569B',
           '#DECBE4',
           
           '#2c6344',
           "#FFA07A",
           "#B2DF8A",
           "#BE922F",
           "#841D4D",
           "#A3A3A3")
sf_data_transformed$`Isolation type` <- ifelse(is.na(sf_data_transformed$`Isolation type`), "Not recorded", 
                                               ifelse(sf_data_transformed$`Isolation type`=="clinical", "Clinical",
                                                      ifelse(sf_data_transformed$`Isolation type`=="environmental/other", "Environmental/Other",sf_data_transformed$`Isolation type`)))

sf_data_transformed<-cbind(sf_data_transformed,as.data.frame(paper.data.1[16:17]))

names(sf_data_transformed)
# p2.0=ggplot() +
#   scale_fill_manual(values = colors)+
#   geom_sf(data = wintri_outline,linewidth=0.01,color = "#e7edf8",fill="#e7edf8")+
#   geom_sf(data = world,fill="#98b2e7", color = "#404040") +
#   # geom_sf(data = shp_data,linewidth=0.5,color = NA, fill = "#5caab2",alpha=0.3) +
#   geom_sf(data = sf_data_transformed,aes(color =`Isolation type`),size=0.2,alpha=0.55) +
#   
#   
#   # scico::scale_fill_scico_d( palette = "bamako",direction =0.1)+
#   theme(plot.background = element_rect(fill="white"),
#         panel.background = element_rect(fill = "white"),
#         panel.grid = element_blank(),
#         legend.position = c(0.2, 0.4),  # 设置图例位置
#         legend.key.size = unit(0, "cm"),
#         plot.margin = unit(c(0, 0, 0, 0), "cm")) +
#   scale_color_manual(values = c("Clinical" = "#C00000", "Environmental/Other" = "#FFB81C","Not recorded"= "#A3A3A3"))

p2.0=ggplot() +
  scale_fill_manual(values = colors)+
  geom_sf(data = wintri_outline,linewidth=0.01,color = "#e7edf8",fill="#e7edf8")+
  geom_sf(data = world,fill="#98b2e7", color = "#404040") +
  geom_sf(data = sf_data_transformed,color ="#C00000",size=0.2,alpha=0.25) +
  
  
  # scico::scale_fill_scico_d( palette = "bamako",direction =0.1)+
  theme(plot.background = element_rect(fill="white"),
        panel.background = element_rect(fill = "white"),
        panel.grid = element_blank(),
        legend.position = c(0.2, 0.4),  # 设置图例位置
        legend.key.size = unit(0, "cm"),
        plot.margin = unit(c(0, 0, 0, 0), "cm")) 

ggsave( p2.0,
        width = 8,height =4,
        filename =  paste0("图片/p2.1.2.jpg"))

# p2.0


p2.1 <- ggplot(sf_data_transformed, aes(x = latitude, y = average_pm25)) +  
  geom_point(color = "#923A92", size = 1, alpha = 0.45) +  
  theme(  
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1),  
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),  
    axis.line.y = element_line(color = "black"),  
    axis.line.x = element_line(color = "black"),  
    axis.title.y = element_text(size = 20)  # 设置x轴标题字体大小为14  
  ) +  
  labs(y = bquote("PM"[2.5]~(μg/m^3)), x = "Latitude") +  # 注意这里修正了拼写错误  
  scale_x_continuous(limits = c(-75, 75), breaks = seq(-75, 75, 10)) +  
  # geom_smooth(method = "loess") +  
  coord_flip()  
# p2.1
p2.2<-ggplot(sf_data_transformed, aes(x = latitude, y = average_tmp)) +
  geom_point(color = "#FFA07A",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y=expression(paste("Temperature (", degree * C, ")")),x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  #geom_smooth(method = "loess") +
  coord_flip()
# p2.2
p2.3<-ggplot(sf_data_transformed, aes(x = latitude, y = average_pre)) +
  geom_point(color = "#6bc7ff",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y='Precipitation (mm)',x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  #geom_smooth(method = "loess") +
  coord_flip()
p2.31<-ggplot(sf_data_transformed, aes(x = latitude, y = average_NDVI)) +
  geom_point(color = "#6bc7ff",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y='Precipitation (mm)',x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  #geom_smooth(method = "loess") +
  coord_flip()



names(sf_data_transformed)
# p2.3
p2.4<-ggplot(sf_data_transformed, aes(x = latitude, y = GDP_per_capita/1000)) +
  geom_point(color = "#00a567",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y="GDP per capita (1000,US$)",x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  #geom_smooth(method = "loess") +
  coord_flip()

p2.5<-ggplot(sf_data_transformed, aes(x = latitude, y = Population_density)) +
  geom_point(color = "#FFB81C",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y="Population density (per km²)",x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  scale_y_log10(limits = c(1, 8000), breaks = c(1, 10,100, 1000))+
  #geom_smooth(method = "loess") +
  coord_flip()
p2.6<-ggplot(sf_data_transformed, aes(x = latitude, y = Mortality_rate_of_infant)) +
  geom_point(color = "#A6CEE3",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y="Mortality rate of infant (‰)",x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  #geom_smooth(method = "loess") +
  coord_flip()
p2.7<-ggplot(sf_data_transformed, aes(x = latitude, y = Population_ages_65_and_above)) +
  geom_point(color = "#DECBE4",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y="Population ages 65 and above (%)",x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  #geom_smooth(method = "loess") +
  coord_flip()
p2.8<-ggplot(sf_data_transformed, aes(x = latitude, y = Current_health_expenditure_per_capita)) +
  geom_point(color = "#FF6800",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y="CHE per capita (US$)",x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  scale_y_continuous(limits = c(0,12000),breaks =seq(0, 10000,2500) )+
  #geom_smooth(method = "loess") +
  coord_flip()
p2.9<-ggplot(sf_data_transformed, aes(x = latitude, y = People_using_at_least_basic_drinking_water_services)) +
  geom_point(color = "#ab4644",size=1,alpha=0.45)+
  theme(
    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1), # 添加四周边框
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    panel.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.line.y = element_line(color = "black") ,
    axis.line.x = element_line(color = "black")
  )+
  labs(y="People using at least BDWS (%)",x=NULL)+
  scale_x_continuous(limits = c(-75,75))+
  #geom_smooth(method = "loess") +
  coord_flip()

p2=ggarrange(p2.1,p2.2,p2.3,
             p2.4,p2.5,p2.6,
             p2.7,p2.8,p2.9,
             
             nrow = 1,ncol = 9, labels = c(NA),font.label = list(size=12),widths = c(0.12,0.1,0.1,
                                                                                     0.1,0.1,0.1,
                                                                                     0.1,0.1,0.1
             ),align = "h")

# p2.2 <- ggplot(sf_data_transformed, aes(x = latitude, y = average_tmp_0)) +
#   geom_smooth(method = "loess", se = FALSE) +  # Disable standard error calculation
#   coord_flip() +
#   theme_classic()

ggsave( p2,
        width = 28,height =12,
        filename =  paste0("图片/p2.0.1.jpg"))

######0.2和弦图####

library(stringr)
names(paper.data.1)
chordDiagram_data<-paper.data.1[c("Scientific name","TETRACYCLINE","MACROLIDE","AMINOGLYCOSIDE","COLISTIN","EFFLUX","FOSFOMYCIN","STREPTOTHRICIN","QUINOLONE","SULFONAMIDE","TRIMETHOPRIM",
                                  "BLEOMYCIN","PHENICOL","RIFAMYCIN","FOSMIDOMYCIN", "NITROFURAN",
                                  "STREPTOGRAMIN",  "LINCOSAMIDE"  ,   "MULTIDRUG" , "PLEUROMUTILIN","GLYCOPEPTIDE","MUPIROCIN", "FUSIDIC_ACID",
                                  "OXAZOLIDINONE" , "FLUOROQUINOLONE","IONOPHORE","LIPOPEPTIDE","NITROIMIDAZOLE","AVILAMYCIN",
                                  "BACITRACIN",
                                  "AMINOCOUMARIN",
                                  "ISONIAZID","BETA_LACTAM", "TRICLOSAN", 
                                  "QUATERNARY_AMMONIUM")]

# 使用stringr包将列名转换为首字母大写
df_new_names <- str_to_title(colnames(chordDiagram_data))

df_new_names[c(23,33,35)]<-c("Fusidic acid","Beta-lactam","Quaternary ammonium")

colnames(chordDiagram_data) <- df_new_names

# specific.name <-  c (" ",'Escherichia coli',
#                      'Staphylococcus aureus',
#                      "Klebsiella pneumoniae",
#                      "Acinetobacter baumannii",
#                      "Pseudomonas aeruginosa",
#                      "Enterococcus faecium",
#                      "Streptococcus pneumoniae",
#                      "Salmonella enterica")


chordDiagram_data$`Scientific Name` <- ifelse(grepl("Salmonella enterica", chordDiagram_data$`Scientific Name`), "Salmonella enterica", 
                                              
                                              ifelse(grepl("Escherichia coli", chordDiagram_data$`Scientific Name`), "Escherichia coli", 
                                                     ifelse(grepl("Staphylococcus aureus", chordDiagram_data$`Scientific Name`), "Staphylococcus aureus",  
                                                            ifelse(grepl("Klebsiella pneumoniae", chordDiagram_data$`Scientific Name`), "Klebsiella pneumoniae",    
                                                                   ifelse(grepl("Acinetobacter baumannii", chordDiagram_data$`Scientific Name`), "Acinetobacter baumannii",   
                                                                          
                                                                          ifelse(grepl("Pseudomonas aeruginosa", chordDiagram_data$`Scientific Name`), "Pseudomonas aeruginosa", 
                                                                                 ifelse(grepl("Enterococcus faecium", chordDiagram_data$`Scientific Name`), "Enterococcus faecium", 
                                                                                        ifelse(grepl("Streptococcus pneumoniae", chordDiagram_data$`Scientific Name`), "Streptococcus pneumoniae", 
                                                                                               ifelse(grepl("Salmonella enterica", chordDiagram_data$`Scientific Name`), "Salmonella enterica", 
                                                                                                      ifelse(grepl("Listeria monocytogenes", chordDiagram_data$`Scientific Name`),"Listeria monocytogenes",
                                                                                                             ifelse(grepl("Mycobacterium tuberculosis", chordDiagram_data$`Scientific Name`),"Mycobacterium tuberculosis",
                                                                                                                    ifelse(grepl("Clostridioides difficile", chordDiagram_data$`Scientific Name`),"Clostridioides difficile",
                                                                                                                           ifelse(grepl("Streptococcus agalactiae", chordDiagram_data$`Scientific Name`),"Streptococcus agalactiae",
                                                                                                                                  
                                                                                                                                  "Other bacteria")))))))))))))





nrow(paper.data.1[grepl("Pseudomonas aeruginosa", paper.data.1$`Scientific name`),])
sort(table(paper.data.1$`Scientific name`))
sort(table(chordDiagram_data$`Scientific Name`))

names(chordDiagram_data)
# 计算每列的和
column_sums <- colSums(chordDiagram_data[2:35])

# 找出和小于 1000 的列名
small_sum_columns <- names(column_sums[column_sums < 2718])

# 提取这些列的数据
small_sum_data <- chordDiagram_data[, small_sum_columns]

# 合并这些列
`Other antibiotic genes` <- rowSums(small_sum_data)

# 创建新的数据框，将合并后的列与其他列放在一起
chordDiagram_data <- cbind(chordDiagram_data[,!(names(chordDiagram_data) %in% small_sum_columns)], `Other antibiotic genes`)



paper.data.total<-chordDiagram_data




# 对和进行排序
sorted_sums <- sort(colSums(chordDiagram_data[2:ncol(chordDiagram_data)]))




rev(names(sorted_sums))

writeLines(paste0("'",rev(names(sorted_sums)),"'",",") )
writeLines(paste0("`",rev(names(sorted_sums)),"`",",") )


writeLines(paste0("'",rev(names(sorted_sums)),"'= 'grey50'",",") )

library(circlize)


# 使用 aggregate 函数根据细菌种类对基因数量进行求和
chordDiagram_data <- aggregate(chordDiagram_data[, 2:ncol(chordDiagram_data)], by = list(chordDiagram_data$`Scientific Name`), FUN = sum)
colnames(chordDiagram_data)[1] <- 'Scientific Name'











# # 确定数据集中的行数
# total_rows <- nrow(chordDiagram_data)
# 
# # 检查总行数是否足够采样2000行
# set.seed(12)  # 你可以选择任何整数作为种子
#   # 随机选择1000行的索引
#   sampled_rows <- sample(1:total_rows, 2000, replace = FALSE)
#   
#   # 创建一个新的数据框，只包含被选中的行
#   sampled_data <- chordDiagram_data[sampled_rows, ]
#   
# 将新数据框转化为矩阵，并使用Scientific Name作为行名
mat_sampled <- as.matrix(chordDiagram_data[, 2:ncol(chordDiagram_data)])
rownames(mat_sampled) <- chordDiagram_data$`Scientific Name`






sorted_sums <- sort(rowSums(mat_sampled))




rev(names(sorted_sums))

writeLines(paste0("'",rev(names(sorted_sums)),"'",",") )






# 现在你可以使用mat_sampled来创建和弦图
#   
union(rownames(mat_sampled), colnames(mat_sampled))
pdf("my_chord_plot.pdf", width = 12, height = 12)

par(mar = c(10, 10, 10, 10)) # 设置四周的边距
circos.par(start.degree = 90,gap.after=1.5)
chordDiagram(mat_sampled, big.gap = 10,
             direction = 1, direction.type = "diffHeight",
             order = c('Escherichia coli',
                       'Klebsiella pneumoniae',
                       'Staphylococcus aureus',
                       'Enterococcus faecium',
                       
                       'Acinetobacter baumannii',
                       'Pseudomonas aeruginosa',
                       'Salmonella enterica',
                       'Clostridioides difficile',
                       'Streptococcus pneumoniae',
                       'Listeria monocytogenes',
                       'Mycobacterium tuberculosis',
                       'Streptococcus agalactiae',
                       "Other bacteria",
                       'Beta-lactam',
                       'Aminoglycoside',
                       'Quinolone',
                       'Fosfomycin',
                       'Tetracycline',
                       'Efflux',
                       'Phenicol',
                       'Macrolide',
                       'Glycopeptide',
                       'Sulfonamide',
                       'Trimethoprim',
                       'Streptogramin',
                       'Lincosamide',
                       'Colistin',
                       'Streptothricin',
                       'Bleomycin',
                       'Rifamycin',
                       'Fosmidomycin',
                       'Fluoroquinolone',
                       'Multidrug',
                       # 'Pleuromutilin',
                       # 'Fusidic acid',
                       # 'Mupirocin',
                       'Other antibiotic genes'
                       
                       
             ),
             annotationTrack = c(
               # "name", 
               "grid"),
             grid.col = c('Escherichia coli'='#E61E18',
                          'Staphylococcus aureus'='#EEE940',
                          "Klebsiella pneumoniae"='#78B837',
                          "Acinetobacter baumannii"='#71B7C1',
                          "Pseudomonas aeruginosa"='#33538E',
                          "Enterococcus faecium"='#9F5D92',
                          "Streptococcus pneumoniae"= "#FFA07A",
                          "Salmonella enterica"="#BE922F",
                          'Clostridioides difficile'="#FF6800",
                          'Streptococcus pneumoniae'='#2F4F4F',
                          'Listeria monocytogenes'="#841D4D",
                          'Mycobacterium tuberculosis'="#B2DF8A",
                          'Streptococcus agalactiae'="#8B4513",
                          "Other bacteria"='#DECBE4',
                          'Beta-lactam'= 'grey50',
                          'Aminoglycoside'= 'grey50',
                          'Quinolone'= 'grey50',
                          'Fosfomycin'= 'grey50',
                          'Tetracycline'= 'grey50',
                          'Efflux'= 'grey50',
                          'Phenicol'= 'grey50',
                          'Macrolide'= 'grey50',
                          'Glycopeptide'= 'grey50',
                          'Sulfonamide'= 'grey50',
                          'Trimethoprim'= 'grey50',
                          'Streptogramin'= 'grey50',
                          'Lincosamide'= 'grey50',
                          'Colistin'= 'grey50',
                          'Streptothricin'= 'grey50',
                          'Bleomycin'= 'grey50',
                          'Rifamycin'= 'grey50',
                          'Fosmidomycin'= 'grey50',
                          'Fluoroquinolone'= 'grey50',
                          'Other antibiotic genes'= 'grey50',
                          'Multidrug'= 'grey50'
                          # 'Pleuromutilin'= 'grey50'
                          # ,
                          # 'Fusidic acid'= 'grey50',
                          # 'Mupirocin'= 'grey50'
             )
)

# 
# circos.track(track.index = 1, panel.fun = function(x, y) {
#   circos.text(CELL_META$xcenter, CELL_META$ylim[1], CELL_META$sector.index, 
#               facing = "clockwise", niceFacing = TRUE, adj = c(0, 0.5))
# }, bg.border = NA) 
# 
# circos.par(track.height = 10)
# circos.track(track.index = 1, panel.fun = function(x, y) {
#   circos.text(CELL_META$xcenter, CELL_META$ylim[1] +2, CELL_META$sector.index, 
#               facing = "clockwise", niceFacing = TRUE, adj = c(0, 0.5), cex = 0.5)
# }, bg.border = NA) 
# 




circos.track(track.index = 1,track.height = unit(8, "npc"), panel.fun = function(x, y) {
  circos.text(CELL_META$xcenter, CELL_META$ylim[1] + 1.7, 
              CELL_META$sector.index, 
              facing = "clockwise", niceFacing = TRUE, 
              adj = c(0, 0.5), cex = 0.7) # 减小cex值，增加ylim[1]后的值
})

circos.clear()
dev.off()
# writeLines(paste0("'", colnames(mat_sampled),"'", "= 'grey50',") )

#######0.3热图#####
paper.data.total.1<-cbind(paper.data.1[c(1:75,128:140)],paper.data.total)




names(paper.data.total.1)
# # 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(109,110)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names


paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)
paper.data.total.10$Total.genes<- rowSums(paper.data.total.10[, 90:110], na.rm = TRUE)

######0.31细菌####

names(paper.data.total.10)
heatdata<-paper.data.total.10[c("year","Scientific Name","Total.genes")]
# 重塑数据以适合绘制热图
data_melt <- heatdata %>%
  group_by(year, `Scientific Name`) %>%
  summarise(Average_Count = mean(Total.genes))

# 计算每年的总平均耐药基因数量，并添加"Total Bacteria"这一行
total_by_year <- data_melt %>%
  group_by(year) %>%
  summarise(Average_Count = mean(Average_Count)) %>%
  mutate(`Scientific Name` = "Total Bacteria")

# 将总细菌的数据与每种细菌的数据合并
average_data <- bind_rows(data_melt, total_by_year)
# data_melt <- melt(heatdata, id.vars = c("year", "Scientific Name"), variable.name = "Variable", value.name = "Count")

average_data$`Scientific Name`<-factor(average_data$`Scientific Name` ,
                                       levels = c(
                                         "Total Bacteria",
                                         'Escherichia coli',
                                         'Klebsiella pneumoniae',
                                         'Staphylococcus aureus',
                                         'Enterococcus faecium',
                                         
                                         'Acinetobacter baumannii',
                                         'Pseudomonas aeruginosa',
                                         'Salmonella enterica',
                                         'Clostridioides difficile',
                                         'Streptococcus pneumoniae',
                                         'Listeria monocytogenes',
                                         'Mycobacterium tuberculosis',
                                         'Streptococcus agalactiae',
                                         "Other bacteria"))



# 绘制热图
ggplot(average_data, aes(x = year, y = `Scientific Name`, fill = Average_Count)) +
  geom_raster() +  # 添加边框
  # scale_fill_gradient2(low = "#71B7C1",mid = "white", high = "#E61E18", na.value = "gray") +  # 处理缺失值为灰色
  scale_fill_gradient2(low = "#5298A2",mid = "white", high = "#E61E18", midpoint=18)+
  scale_x_continuous(limits = c(1999.5,2022.5),breaks = seq(2000,2022,1))+
  labs(title = NULL,y=NULL, x = "Year",fill = bquote("Resistance genes count\nper isolate"))+
  
  theme_minimal() +
  theme(
    panel.grid = element_blank(),  # 去掉网格
    panel.background = element_rect(fill = "#f2e9e1"),
    axis.text.x = element_text(angle = 45, hjust = 1),  # 倾斜 X 轴标签以便更好地阅读
    axis.title = element_text(size = 16),  # 增大轴标题的字体大小
    axis.text.y = element_text(color = "black")
  )
ggsave( last_plot(),
        width = 10,height =6,
        filename =  paste0("图片/Heatmap.1.pdf"))


######0.32耐药基因####
heatdata<-paper.data.total.10[c("year",
                                
                                'Beta_lactam',
                                'Aminoglycoside',
                                'Quinolone',
                                'Fosfomycin',
                                'Tetracycline',
                                'Efflux',
                                'Phenicol',
                                'Macrolide',
                                'Glycopeptide',
                                'Sulfonamide',
                                'Trimethoprim',
                                'Streptogramin',
                                'Lincosamide',
                                'Colistin',
                                'Streptothricin',
                                'Bleomycin',
                                'Rifamycin',
                                'Fosmidomycin',
                                'Fluoroquinolone',
                                'Multidrug',
                                # 'Pleuromutilin',
                                # 'Fusidic_acid',
                                # 'Mupirocin',
                                'Other_antibiotic_genes')]

names(heatdata)<-c("year",
                   
                   'Beta-lactam',
                   'Aminoglycoside',
                   'Quinolone',
                   'Fosfomycin',
                   'Tetracycline',
                   'Efflux',
                   'Phenicol',
                   'Macrolide',
                   'Glycopeptide',
                   'Sulfonamide',
                   'Trimethoprim',
                   'Streptogramin',
                   'Lincosamide',
                   'Colistin',
                   'Streptothricin',
                   'Bleomycin',
                   'Rifamycin',
                   'Fosmidomycin',
                   'Fluoroquinolone',
                   'Multidrug',
                   # 'Pleuromutilin',
                   # 'Fusidic acid',
                   # 'Mupirocin',
                   'Other antibiotic genes')



# 将数据转换为长格式
melted_data <- melt(heatdata, id.vars = "year")

# 计算每年每个基因的平均值
average_data <- aggregate(value ~ year + variable, data = melted_data, FUN = mean)

# 绘制热图
ggplot(average_data, aes(x = year, y = variable, fill = value)) +
  geom_raster() +
  # geom_tile(color = "black", size = 0.1) +  # 添加边框
  # scale_fill_gradient2(low = "#71B7C1",mid = "white", high = "#E61E18", na.value = "gray") +  # 处理缺失值为灰色
  scale_fill_gradient2(low = "#5298A2",mid = "white", high = "#E61E18", midpoint=1.5)+
  scale_x_continuous(limits = c(1999.5,2022.5),breaks = seq(2000,2022,1))+
  labs(title = NULL,y=NULL, x = "Year",fill = bquote("Resistance genes count\nper isolate"))+
  
  theme_minimal() +
  theme(
    panel.grid = element_blank(),  # 去掉网格
    panel.background = element_rect(fill = "#f2e9e1"),
    axis.text.x = element_text(angle = 45, hjust = 1),  # 倾斜 X 轴标签以便更好地阅读
    axis.title = element_text(size = 16),  # 增大轴标题的字体大小
    axis.text.y = element_text(color = "black")
  )
ggsave( last_plot(),
        width = 10,height =6,
        filename =  paste0("图片/Heatmap.2.pdf"))


#######04.相关关系图####
# devtools::install_github("Github-Yilei/ggcor") 
names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  




library(ggcor)
cordata<-paper.data.total.1[c(
  "average_pm25",
  "average_tmp",
  "average_pre",
  "average_NDVI",
  "GDP_per_capita", 
  
  "Population_density",
  "Mortality_rate_of_infant",
  "Population_ages_65_and_above",
  
  "Current_health_expenditure_per_capita",
  
  "People_using_at_least_basic_drinking_water_services",
  'Beta_lactam',
  'Aminoglycoside',
  'Quinolone',
  'Fosfomycin',
  'Tetracycline',
  'Efflux',
  'Phenicol',
  'Macrolide',
  'Glycopeptide',
  'Sulfonamide',
  'Trimethoprim',
  'Streptogramin',
  'Lincosamide',
  'Colistin',
  'Streptothricin',
  'Bleomycin',
  'Rifamycin',
  'Fosmidomycin',
  'Fluoroquinolone',
  'Multidrug',
  # 'Pleuromutilin',
  # 'Fusidic_acid',
  # 'Mupirocin',
  'Other_antibiotic_genes')]

names(cordata)<-c(
  "PM2.5",
  "Temperature",
  "Precipitation",
  "NDVI",
  "GDP per capita",
  "Population density" ,          
  "Mortality rate of infant"   ,        
  "Population aged 65 and above"    ,        
  "Current health expenditure per capita",
  "People using at least basic drinking-water services",
  'Beta-lactam',
  'Aminoglycoside',
  'Quinolone',
  'Fosfomycin',
  'Tetracycline',
  'Efflux',
  'Phenicol',
  'Macrolide',
  'Glycopeptide',
  'Sulfonamide',
  'Trimethoprim',
  'Streptogramin',
  'Lincosamide',
  'Colistin',
  'Streptothricin',
  'Bleomycin',
  'Rifamycin',
  'Fosmidomycin',
  'Fluoroquinolone',
  'Multidrug',
  # 'Pleuromutilin',
  # 'Fusidic acid',
  # 'Mupirocin',
  'Other antibiotic genes')


# # 计算每列的均值（忽略NA值）  
# column_means <- colMeans(cordata, na.rm = TRUE)  
# # 遍历数据框的每一列，并用列均值替换NA值  
# for (col_name in names(cordata)) {  
#   cordata[is.na(cordata[[col_name]]), col_name] <- column_means[col_name]  
# }
# 

# 假设 cordata 是你的数据框  
# clean_cordata1 <- na.omit(cordata[2:4]) [1:200,] 
# clean_cordata2 <- na.omit(cordata[2:24])  

# 然后使用清理后的数据进行 Mantel 测试  
# r.p.data <- mantel_test(clean_cordata1, 
#                         clean_cordata2,   
#                         spec.select = list(PM2.5 = 1,  
#                                            Temperature = 2,  
#                                            Precipitation = 3))

correlations <- cor(cordata[, 1:10], cordata[, 11:31]) # 假设前10列是环境因素，后24列是耐药基因  
# p_values <- cor.test.matrix(cordata[, 1:9], cordata[, 10:33])$p.value # 假设你有一个函数来计算相关性的p值  
# 假设 cordata 是你的数据框，前10列是环境因素，接下来的列是耐药基因  
p_values_matrix <- matrix(nrow=ncol(cordata[,11:31]), ncol=ncol(cordata[,1:10]))  
colnames(p_values_matrix) <- colnames(cordata[,1:10])  
rownames(p_values_matrix) <- colnames(cordata[,11:31])  

for (i in 1:ncol(cordata[,11:31])) {  
  for (j in 1:ncol(cordata[,1:10])) {  
    test_result <- cor.test(cordata[,j], cordata[,i+10])  
    p_values_matrix[i,j] <- test_result$p.value  
  }  
}  

# 将p值矩阵转换为数据框，以便后续使用  
p_values_df <- as.data.frame(p_values_matrix)




# 准备一个数据框来存储r值、p值和分类变量  
r.p.data <- data.frame(  
  Var1 = rep(names(cordata)[1:10], each = 21),  
  Var2 = rep(names(cordata)[11:31], times = 10),  
  r = as.vector(correlations),  
  p.value = as.vector(p_values_matrix)  
)  

#进行数据分割，将连续变量转化为分类变量，有利于观察和比较
r.p.data.plot <- r.p.data %>% 
  mutate(r.sign = cut(r, breaks = c(-Inf, 0, Inf), 
                      labels = c("Negative", "Positive")),
         p.sign = cut(p.value, breaks = c(0, 0.05, Inf), 
                      labels = c("P<0.05", "P>=0.05"),
                      include.lowest = TRUE,#较小值是否为闭区间,
                      right = FALSE), #较大值是否为闭区间
         r.abs = cut(abs(r), breaks = c(0, 0.1, 0.3, 0.5),
                     labels = c("|Pearson's r|<0.1",
                                "0.1≤|Pearson's r|<0.3",
                                "0.3≤|Pearson's r|<0.5"),
                     include.lowest = TRUE,#较小值是否为闭区间,
                     right = FALSE),#较大值是否为闭区间      
  )  

#cut函数是一个很方便的操作函数，当然我们也可以用ifelse来实现，但多区间时没有cut方便

# #为了复现得原图更像，我们[篡改]一下数据，仅为绘图效果，请勿模仿！
# r.p.data.plot$r.sign <- c("Positive", "Negative")[factor(c(1,2,1,1,1,2,2,1,2,1,1,1,2,1,2,2,2,2,1,1,2,1,1,2,1,1,1,2,2,1,1,1,1))]
# r.p.data.plot$p.sign <- c("P<0.05", "P>=0.05")[factor(c(1,1,1,1,2,1,1,1,2,1,1,1,1,1,2,2,1,1,2,1,2,2,1,1,2,2,2,1,1,2,2,2,2))]
# r.p.data.plot$r.abs <- c("<0.1","0.1-0.3", "0.3-0.5")[factor(c(3,3,2,2,2,3,2,2,1,2,2,3,3,2,1,1,2,2,1,2,1,1,2,2,1,1,1,2,2,1,1,1,1))]



p4.1<-quickcor(cordata[,11:31], type = "upper", show.diag = T ) + #设置右上角图形、不显示对角线
  geom_square() +  #绘制方形热图
  anno_link(data = r.p.data.plot,   #添加网络图并映射数据
            aes(colour = r.sign,
                size = r.abs,
                linetype = p.sign),
            
            label.size = 0,
            label.fontface = 1,
            label.colour = "black",
            # width = 1,
            nudge_x = 0.4,
            expand = 12,
            # arrow = arrow(length = unit(0.2, "cm")),
            curvature = 0) +
  
  scale_size_manual(values = c("|Pearson's r|<0.1" = 0.2,
                               "0.1≤|Pearson's r|<0.3" = 0.8,
                               "0.3≤|Pearson's r|<0.5" = 2)) +  #为每个分类设置连线粗细
  scale_colour_manual(values = c("Positive" = "#e0745a","Negative" = "#63a1cb"
  ))+  #为每个分类设置颜色
  scale_linetype_manual(values = c("P<0.05" = "solid",
                                   "P>=0.05" = "blank"))+
  scale_fill_gradientn(colours = rev(c("#da4b3c", "#e0745a", "#fbfbf7", "#63a1cb", "#052452")),  #自定义颜色
                       breaks = seq(-1, 1, 0.5),
                       limits = c(-1, 1))+ #设置图例范围
  # geom_diag_label(hjust=0,nudge_x=0.1)+
  guides(
    fill = guide_colorbar(title = bquote("Pearson's r among \ndifferent antibiotic genes"),order=1), 
    linetype = guide_legend(title = "Pearson's r between \nantibiotic genes and factors",order=2),
    colour = guide_legend(title = NULL,order=3),
    size = guide_legend(title = NULL,order=4)  #此处均为标题设置
  )+
  theme(
    # legend.box.margin = margin(10, 1, 1, 10), 
    legend.position = c(0,0.9),
    legend.key.size = unit(4, "mm"), #调整图例整体大小
    legend.spacing = unit(1, "mm"), #调整图例之间间距
    # axis.text.x = element_text(color = c(c(rep("#743e14", 7), rep("#005638", 4))), #X轴标签颜色
    #                            size = 10), 
    # axis.text.y = element_text(color = c(rep("#005638", 4), c(rep("#743e14", 7))), #Y轴标签颜色
    #                            size = 10),
    legend.key = element_blank() #删除图例灰色背景(为了画面更干净)
  )

p4.2<-quickcor(cordata[,1:10], type = "lower", show.diag = T ) + #设置右上角图形、不显示对角线
  geom_square() +  #绘制方形热图
  scale_fill_gradientn(colours = rev(c("#da4b3c", "#e0745a", "#fbfbf7", "#63a1cb", "#052452")),  #自定义颜色
                       breaks = seq(-1, 1, 0.5),
                       limits = c(-1, 1))+
  theme(
    # legend.box.margin = margin(10, 1, 1, 10), 
    legend.position = "none",
    legend.key = element_blank() #删除图例灰色背景(为了画面更干净)
  )
p4 <- ggarrange(p4.2,p4.1,
                nrow = 1,ncol = 2, labels = NA,font.label = list(size=12),widths = c(0.1,0.14
                ))

ggsave( p4,
        width = 20,height =12,
        filename =  paste0("图片/cormap.1.pdf")) 

######05.环形图####  
names(paper.data.1)
circledata<-paper.data.1[c("Scientific name","Method","Level","Isolation type","Country Name","year")] 
circledata$year=as.character(circledata$year)
circledata$`Scientific name` <- ifelse(grepl("Salmonella enterica", circledata$`Scientific name`), "Salmonella enterica", 
                                       
                                       ifelse(grepl("Escherichia coli", circledata$`Scientific name`), "Escherichia coli", 
                                              ifelse(grepl("Staphylococcus aureus", circledata$`Scientific name`), "Staphylococcus aureus",  
                                                     ifelse(grepl("Klebsiella pneumoniae", circledata$`Scientific name`), "Klebsiella pneumoniae",    
                                                            ifelse(grepl("Acinetobacter baumannii", circledata$`Scientific name`), "Acinetobacter baumannii",   
                                                                   
                                                                   ifelse(grepl("Pseudomonas aeruginosa", circledata$`Scientific name`), "Pseudomonas aeruginosa", 
                                                                          ifelse(grepl("Enterococcus faecium", circledata$`Scientific name`), "Enterococcus faecium", 
                                                                                 ifelse(grepl("Streptococcus pneumoniae", circledata$`Scientific name`), "Streptococcus pneumoniae", 
                                                                                        ifelse(grepl("Salmonella enterica", circledata$`Scientific name`), "Salmonella enterica", 
                                                                                               ifelse(grepl("Listeria monocytogenes", circledata$`Scientific name`),"Listeria monocytogenes",
                                                                                                      ifelse(grepl("Mycobacterium tuberculosis", circledata$`Scientific name`),"Mycobacterium tuberculosis",
                                                                                                             ifelse(grepl("Clostridioides difficile", circledata$`Scientific name`),"Clostridioides difficile",
                                                                                                                    ifelse(grepl("Streptococcus agalactiae", circledata$`Scientific name`),"Streptococcus agalactiae",
                                                                                                                           
                                                                                                                           "Other bacteria")))))))))))))



circledata$`Method` <- ifelse(grepl("SKESA|Skesa|skesa", circledata$`Method`), "SKESA",                           
                              ifelse(grepl("(?i)SPAdes", circledata$`Method`), "SPAdes", 
                                     ifelse(grepl("Newbler", circledata$`Method`), "Newbler",  
                                            ifelse(grepl("(?i)Shovill", circledata$`Method`), "Shovill",    
                                                   ifelse(grepl("(?i)Velvet", circledata$`Method`), "Velvet",       
                                                          ifelse(grepl("(?i)unicycle|unitycler|Unicyler|Unicylcer|Unycicler|Unicycycler|unicycer", circledata$`Method`), "Unicycler", 
                                                                 ifelse(grepl("SOAPdenovo|SOAPdenove|SOAPdeno|SOAP denovo", circledata$`Method`), "SOAPdenovo",
                                                                        # ifelse(grepl("CLC", circledata$`Method`), "CLC Genomics Workbench",
                                                                        # ifelse(grepl("(?i)Flye", circledata$`Method`), "Flye",
                                                                        #        ifelse(grepl("(?i)Canu", circledata$`Method`), "Canu", 
                                                                        ifelse(is.na(circledata$`Method`) , "Not recorded",
                                                                               "Other method"))))))))
rev(sort(table(circledata$`Method`)))  

rev(sort(table(circledata$`Country Name`))) 
rev(sort(table(circledata$`year`))) 
rev(sort(table(circledata$`Level`)))  
circledata$`Isolation type` <- 
  ifelse(is.na(circledata$`Isolation type`), "Environmental/Other", 
         ifelse(circledata$`Isolation type`=="clinical", "Clinical",
                # ifelse(circledata$`Isolation type`=="environmental/other", 
                "Environmental/Other"
                # ,circledata$`Isolation type`) 
         ) ) 

circledata$`Level` <- ifelse(is.na(circledata$`Level`), "Not recorded",
                             ifelse(circledata$`Level`=="Chromosome", "Complete Genome",circledata$`Level`))

country_counts <- table(circledata$`Country Name`)  

# 将频率小于1000的国家名设置为"Other country"  
# 这里使用了一个逻辑判断，如果频率小于1000，则返回TRUE，否则返回FALSE  
# 然后用ifelse函数根据这个逻辑判断来修改国家名  
circledata <- circledata %>%  
  mutate(`Country Name` = if_else(`Country Name` %in% names(country_counts)[country_counts < 1000],   
                                  "Other country",   
                                  `Country Name`))  

year_counts <- table(circledata$`year`)  
circledata <- circledata %>%  
  mutate(`year` = if_else(`year` %in% names(year_counts)[year_counts < 1000],   
                          "Other year",   
                          `year`))  
rev(sort(table(circledata$`Country Name`))) 

# 使用dplyr来计算每列的唯一值数量  
scientific_name_counts <- circledata %>% count(`Scientific name`) %>% rename(Value = `Scientific name`, Count = n)%>%  
  arrange(desc(Count))%>%mutate(Value=as.factor(Value))  
method_counts <- circledata %>% count(`Method`) %>% rename(Value = Method, Count = n)%>%  
  arrange(desc(Count))%>%mutate(Value=as.factor(Value))  
level_counts <- circledata %>% count(`Level`) %>% rename(Value = Level, Count = n) %>%  
  arrange(desc(Count))%>%mutate(Value=as.factor(Value)) 
isolation_type_counts <- circledata %>% count(`Isolation type`) %>% rename(Value = `Isolation type`, Count = n)%>%  
  arrange(desc(Count))%>%mutate(Value=as.factor(Value)) 
year_counts <- circledata %>% count(`year`) %>% rename(Value = `year`, Count = n)%>%  
  arrange(desc(Count))%>%mutate(Value=as.factor(Value))  
country_counts <- circledata %>% count(`Country Name`) %>% rename(Value = `Country Name`, Count = n)%>%  
  arrange(desc(Count))%>%mutate(Value=as.factor(Value))  

scientific_name_counts$end <- cumsum(scientific_name_counts$Count) / sum(scientific_name_counts$Count)  
scientific_name_counts$start <- c(0, head(scientific_name_counts$end, -1))  

method_counts$end <- cumsum(method_counts$Count) / sum(method_counts$Count)  
method_counts$start <- c(0, head(method_counts$end, -1))  

level_counts$end <- cumsum(level_counts$Count) / sum(level_counts$Count)  
level_counts$start <- c(0, head(level_counts$end, -1))  

isolation_type_counts$end <- cumsum(isolation_type_counts$Count) / sum(isolation_type_counts$Count)  
isolation_type_counts$start <- c(0, head(isolation_type_counts$end, -1))  

year_counts$end <- cumsum(year_counts$Count) / sum(year_counts$Count)  
year_counts$start <- c(0, head(year_counts$end, -1))  

country_counts$end <- cumsum(country_counts$Count) / sum(country_counts$Count)  
country_counts$start <- c(0, head(country_counts$end, -1))  


color=c("#F28E8C", "#DECCE4", "#80B0D2", "#faf1bd", "#BDDB9D",  
        "#B2DF8A", "#CC79A7", "#B1D6D3", "#fbb1a2", "#a4a5ef",  
        "#66AAAA", "#B2DF8A", "#3366CC", "#99CC00", "#CD5C5C",
        "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2",  
        "#D55E00", "#CC79A7", "#999999", "#000000", "#FF9999",  
        "#66AAAA", "#B2DF8A", "#3366CC", "#99CC00", "#FF4444")
color=c("#9BD5E7","#DECCE4","#fbb1a2","#faf1bd",
        "#B2DF8A", "#CC79A7", "#80B0D2", "#F28E8C", "#a4a5ef",
        "#A5AAA3", "#E69F00", "#009E73", "#FFFFFF","#66AAAA",
        "#BDDB9D","#CD5C5C","#0072B2","#F0E442","#000000","#FF4444")
ggplot() +  
  # 第一个环状饼图 
  geom_rect(data = level_counts, aes(xmin = 0.35, xmax = 0.6, ymin = start, ymax = end, fill = Value ),color="black",size = 0.35) +  
  geom_text(data = level_counts, aes(x = 0.61, y = (start + end) / 2, label = Value,angle =ifelse((-360*(start + end) / 2 +90)< -90,(-360*(start + end) / 2 +90+180),(-360*(start + end) / 2 +90)), hjust = ifelse((-360*(start + end) / 2 +90)< -90,1,0)), # 假设你的数据框中有'label'列  
            size = 3, color = "black") +  # 调整这些参数以优化文本位置  
  annotate("text",x = 0, y = 0,fontface = "bold", label = "Assemble level",angle =0,
           size = 4, color = "black", hjust = 0.5) +
  # 转换为极坐标  
  coord_polar(theta = "y", start = 0, direction = 1) +  
  # 设置颜色和图例  
  scale_fill_manual(values = c("Contig" ="#9BD5E7", "Not recorded" ="#DECCE4", "Scaffold" ="#fbb1a2", "Complete Genome"="#faf1bd")) +  
  # 移除背景元素  
  theme_void() +  
  # 设置图例  
  theme(legend.position = "none") +  
  labs(fill = "Category") +  
  # 设置x和y轴的范围  
  xlim(c(0, 1)) +  
  ylim(c(0, 1))  
p5.1<-last_plot()
ggplot() +  
  # 第一个环状饼图 
  geom_rect(data = isolation_type_counts, aes(xmin = 0.35, xmax = 0.6, ymin = start, ymax = end, fill = Value ),color="black",size = 0.35) +  
  geom_text(data = isolation_type_counts, aes(x = 0.61, y = (start + end) / 2, label = Value,angle =ifelse((-360*(start + end) / 2 +90)< -90,(-360*(start + end) / 2 +90+180),(-360*(start + end) / 2 +90)), hjust = ifelse((-360*(start + end) / 2 +90)< -90,1,0)), # 假设你的数据框中有'label'列  
            size = 3, color = "black") +  # 调整这些参数以优化文本位置  
  annotate("text",x = 0, fontface = "bold",y = 0, label = "Isolation type",angle =0,
           size = 4, color = "black", hjust = 0.5) +
  
  # 转换为极坐标  
  coord_polar(theta = "y", start = 0, direction = 1) +  
  # 设置颜色和图例  
  scale_fill_manual(values = c("Clinical" ="#9BD5E7", "Environmental/Other" ="#DECCE4")) +  
  # 移除背景元素  
  theme_void() +  
  # 设置图例  
  theme(legend.position = "none") +  
  labs(fill = "Category") +  
  # 设置x和y轴的范围  
  xlim(c(0, 1)) +  
  ylim(c(0, 1))
p5.2<-last_plot()

method_counts$Value
ggplot() +  
  # 第一个环状饼图 
  geom_rect(data = method_counts, aes(xmin = 0.35, xmax = 0.6, ymin = start, ymax = end, fill = Value ),color="black",size = 0.35) +  
  geom_text(data = method_counts, aes(x = 0.61, y = (start + end) / 2, label = Value,angle =ifelse((-360*(start + end) / 2 +90)< -90,(-360*(start + end) / 2 +90+180),(-360*(start + end) / 2 +90)), hjust = ifelse((-360*(start + end) / 2 +90)< -90,1,0)), # 假设你的数据框中有'label'列  
            size = 3, color = "black") +  # 调整这些参数以优化文本位置  
  annotate("text",x = 0, fontface = "bold",y = 0, label = "Assemble method",angle =0,
           size = 4, color = "black", hjust = 0.5) +
  
  
  
  # 转换为极坐标  
  coord_polar(theta = "y", start = 0, direction = 1) +  
  # 设置颜色和图例  
  scale_fill_manual(values = c("SKESA" ="#9BD5E7", "SPAdes" ="#DECCE4", "Not recorded" ="#fbb1a2", "Other method"="#faf1bd",
                               "Unicycler" ="#B2DF8A","Newbler" = "#CC79A7", "Shovill" ="#80B0D2", "SOAPdenovo" ="#F28E8C",
                               "Velvet" ="#a4a5ef")) +  
  # 移除背景元素  
  theme_void() +  
  # 设置图例  
  theme(legend.position = "none") +  
  labs(fill = "Category") +  
  # 设置x和y轴的范围  
  xlim(c(0, 1)) +  
  ylim(c(0, 1))  
p5.3<-last_plot()
writeLines(paste0(scientific_name_counts$Value))
ggplot() +  
  # 第一个环状饼图 
  geom_rect(data = scientific_name_counts, aes(xmin = 0.35, xmax = 0.6, ymin = start, ymax = end, fill = Value ),color="black",size = 0.35) +  
  geom_text(data = scientific_name_counts, aes(x = 0.61, y = (start + end) / 2, label = Value,angle =ifelse((-360*(start + end) / 2 +90)< -90,(-360*(start + end) / 2 +90+180),(-360*(start + end) / 2 +90)), hjust = ifelse((-360*(start + end) / 2 +90)< -90,1,0)), # 假设你的数据框中有'label'列  
            size = 3, color = "black") +  # 调整这些参数以优化文本位置  
  annotate("text",x = 0, fontface = "bold",y = 0, label = "Bacterial species",angle =0,
           size = 4, color = "black", hjust = 0.5) +
  
  
  
  # 转换为极坐标  
  coord_polar(theta = "y", start = 0, direction = 1) +  
  # 设置颜色和图例  
  scale_fill_manual(values = c("Escherichia coli" ="#9BD5E7", "Other bacteria" ="#DECCE4", "Staphylococcus aureus" ="#fbb1a2", "Klebsiella pneumoniae"="#faf1bd",
                               "Salmonella enterica" ="#B2DF8A","Acinetobacter baumannii" = "#CC79A7", "Enterococcus faecium" ="#80B0D2", "Pseudomonas aeruginosa" ="#F28E8C", "Streptococcus pneumoniae" ="#a4a5ef",
                               "Listeria monocytogenes" ="#A5AAA3", "Clostridioides difficile" ="#E69F00", "Mycobacterium tuberculosis" ="#009E73", "Streptococcus agalactiae"="#FFFFFF")) +  
  # 移除背景元素  
  theme_void() +  
  # 设置图例  
  theme(legend.position = "none") +  
  labs(fill = "Category") +  
  # 设置x和y轴的范围  
  xlim(c(0, 1)) +  
  ylim(c(0, 1))  
p5.4<-last_plot()



writeLines(paste0("'",year_counts$Value,"'"," = ","'",color,"',"))
ggplot() +  
  # 第一个环状饼图 
  geom_rect(data = year_counts, aes(xmin = 0.35, xmax = 0.6, ymin = start, ymax = end, fill = Value ),color="black",size = 0.35) +  
  geom_text(data = year_counts, aes(x = 0.61, y = (start + end) / 2, label = Value,angle =ifelse((-360*(start + end) / 2 +90)< -90,(-360*(start + end) / 2 +90+180),(-360*(start + end) / 2 +90)), hjust = ifelse((-360*(start + end) / 2 +90)< -90,1,0)), # 假设你的数据框中有'label'列  
            size = 3, color = "black") +  # 调整这些参数以优化文本位置  
  annotate("text",x = 0, fontface = "bold",y = 0, label = "Collected year",angle =0,
           size = 4, color = "black", hjust = 0.5) +
  
  
  
  # 转换为极坐标  
  coord_polar(theta = "y", start = 0, direction = 1) +  
  # 设置颜色和图例  
  scale_fill_manual(values = c('2019' = '#9BD5E7',
                               '2018' = '#DECCE4',
                               '2020' = '#fbb1a2',
                               '2017' = '#faf1bd',
                               '2015' = '#B2DF8A',
                               '2016' = '#CC79A7',
                               '2012' = '#80B0D2',
                               '2021' = '#F28E8C',
                               '2014' = '#a4a5ef',
                               '2013' = '#A5AAA3',
                               'Other year' = '#E69F00',
                               '2022' = '#009E73',
                               '2011' = '#FFFFFF',
                               '2010' = '#66AAAA',
                               '2009' = '#BDDB9D',
                               '2008' = '#CD5C5C',
                               '2019' = '#0072B2',
                               '2018' = '#F0E442',
                               '2020' = '#000000',
                               '2017' = '#FF4444')) +  
  # 移除背景元素  
  theme_void() +  
  # 设置图例  
  theme(legend.position = "none") +  
  labs(fill = "Category") +  
  # 设置x和y轴的范围  
  xlim(c(0, 1)) +  
  ylim(c(0, 1))  
p5.5<-last_plot()



writeLines(paste0("'",country_counts$Value,"'"," = ","'",color,"',"))
# writeLines(paste0(country_counts$Value))
ggplot() +  
  # 第一个环状饼图 
  geom_rect(data = country_counts, aes(xmin = 0.35, xmax = 0.6, ymin = start, ymax = end, fill = Value ),color="black",size = 0.35) +  
  geom_text(data = country_counts, aes(x = 0.61, y = (start + end) / 2, label = Value,angle =ifelse((-360*(start + end) / 2 +90)< -90,(-360*(start + end) / 2 +90+180),(-360*(start + end) / 2 +90)), hjust = ifelse((-360*(start + end) / 2 +90)< -90,1,0)), # 假设你的数据框中有'label'列  
            size = 3, color = "black") +  # 调整这些参数以优化文本位置  
  annotate("text",x = 0, fontface = "bold",y = 0, label = "Collected country",angle =0,
           size = 4, color = "black", hjust = 0.5) +
  
  
  
  # 转换为极坐标  
  coord_polar(theta = "y", start = 0, direction = 1) +  
  # 设置颜色和图例  
  scale_fill_manual(values = c('United States' = '#9BD5E7',
                               'Other country' = '#DECCE4',
                               'China' = '#fbb1a2',
                               'Japan' = '#faf1bd',
                               'United Kingdom' = '#B2DF8A',
                               'Denmark' = '#CC79A7',
                               'Australia' = '#80B0D2',
                               'Canada' = '#F28E8C',
                               'Malawi' = '#a4a5ef',
                               'Germany' = '#A5AAA3',
                               'Peru' = '#E69F00',
                               'New Zealand' = '#009E73',
                               'Mexico' = '#FFFFFF',
                               'Italy' = '#66AAAA',
                               'Spain' = '#BDDB9D',
                               'Belgium' = '#CD5C5C',
                               'Singapore' = '#0072B2',
                               'Thailand' = '#F0E442',
                               'South Africa' = '#000000',
                               'India' = '#FF4444',
                               'France' = '#9BD5E7',
                               'Brazil' = '#DECCE4',
                               'Korea, Rep.' = '#fbb1a2',
                               'Bangladesh' = '#faf1bd',
                               'Israel' = '#B2DF8A',
                               'Ireland' = '#CC79A7')) +  
  # 移除背景元素  
  theme_void() +  
  # 设置图例  
  theme(legend.position = "none") +  
  labs(fill = "Category") +  
  # 设置x和y轴的范围  
  xlim(c(0, 1)) +  
  ylim(c(0, 1))  
p5.6<-last_plot()

# ggplot() +  
#   # 第一个环状饼图 
#   geom_rect(data = scientific_name_counts, aes(xmin = 0.4, xmax = 1, ymin = start, ymax = end, fill = Value )) +  
#   geom_text(data = scientific_name_counts, aes(x = 0.7, y = (start + end) / 2, label = Value,angle =-360*(start + end) / 2 +90), # 假设你的数据框中有'label'列  
#             size = 3, color = "black", hjust = 0.5) +  # 调整这些参数以优化文本位置  
#   annotate("text",x = 0, fontface = "bold",y = 0, label = "Bacterial species",angle =0,
#            size = 4, color = "black", hjust = 0.5) +
#   
#   
#   
#   # 转换为极坐标  
#   coord_polar(theta = "y", start = 0, direction = 1) +  
#   # 设置颜色和图例  
#   scale_fill_manual(values = c("#F28E8C", "#DECCE4", "#80B0D2", "#faf1bd", "#BDDB9D",  
#                                "#B2DF8A", "#CC79A7", "#B1D6D3", "#fbb1a2", "#a4a5ef",  
#                                "#66AAAA", "#B2DF8A", "#3366CC", "#99CC00", "#CD5C5C",
#                                "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2",  
#                                "#D55E00", "#CC79A7", "#999999", "#000000", "#FF9999",  
#                                "#66AAAA", "#B2DF8A", "#3366CC", "#99CC00", "#FF4444")) +  
#   # 移除背景元素  
#   theme_void() +  
#   # 设置图例  
#   theme(legend.position = "none") +  
#   labs(fill = "Category") +  
#   # 设置x和y轴的范围  
#   xlim(c(0, 1)) +  
#   ylim(c(0, 1))  
# p5.4<-last_plot()


p5<-ggarrange(p5.2,p5.1,p5.3,p5.4,p5.5,p5.6,
              nrow = 3,ncol = 2, labels = NA,font.label = list(size=12))

ggsave( last_plot(),
        width = 10,height =15,
        filename =  paste0("图片/circle.pdf")) 

######06.概率密度图####  
names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$Total.genes<-rowSums(paper.data.total.1[98:118])



writeLines(paste0("'",names(paper.data.total.1)[c(83:92,94:115)],"',"))

density_graph_1 <-paper.data.total.1[c('average_pm25',
                                       'average_tmp',
                                       'average_pre',
                                       'average_NDVI',
                                       'GDP_per_capita',
                                       'Population_density',
                                       'Mortality_rate_of_infant',
                                       'Population_ages_65_and_above',
                                       'Current_health_expenditure_per_capita',
                                       'People_using_at_least_basic_drinking_water_services'
)] 
names(density_graph_1) <- c(
  "PM2.5 (ug/m³)",
  "Temperature (oC)",
  "Precipitation (mm)",
  "NDVI (‰)",
  "GDP per capita (US$)",
  "Population density (per km²)" ,          
  "Mortality rate of infant (%)"   ,        
  "Population aged 65 and above (%)"    ,        
  "Current health expenditure per capita (US$)",
  "People using at least basic drinking-water services (%)")
density_graph_1 <- density_graph_1%>% pivot_longer(everything(),
                                                   names_to = "name",
                                                   values_to = "value")
density_graph_1$name <- factor(density_graph_1$name, 
                               levels = c("PM2.5 (ug/m³)",
                                          "Temperature (oC)",
                                          "Precipitation (mm)",
                                          "NDVI (‰)",
                                          "GDP per capita (US$)",
                                          "Population density (per km²)" ,          
                                          "Mortality rate of infant (%)"   ,        
                                          "Population aged 65 and above (%)"    ,        
                                          "Current health expenditure per capita (US$)",
                                          "People using at least basic drinking-water services (%)"))
density_graph_2 <-paper.data.total.1[c(
  'Beta_lactam',
  'Aminoglycoside',
  'Quinolone',
  'Fosfomycin',
  'Tetracycline',
  'Efflux',
  'Phenicol',
  'Macrolide',
  'Glycopeptide',
  'Sulfonamide',
  'Trimethoprim',
  'Streptogramin',
  'Lincosamide',
  'Colistin',
  'Streptothricin',
  'Bleomycin',
  'Rifamycin',
  'Fosmidomycin',
  'Fluoroquinolone',
  'Multidrug',
  
  'Other_antibiotic_genes',
  'Total.genes')] 
names(density_graph_2) <- c(
  'Beta-lactam',
  'Aminoglycoside',
  'Quinolone',
  'Fosfomycin',
  'Tetracycline',
  'Efflux',
  'Phenicol',
  'Macrolide',
  'Glycopeptide',
  'Sulfonamide',
  'Trimethoprim',
  'Streptogramin',
  'Lincosamide',
  'Colistin',
  'Streptothricin',
  'Bleomycin',
  'Rifamycin',
  'Fosmidomycin',
  'Fluoroquinolone',
  'Multidrug',
  'Other resistance genes',
  "Total resistance genes")

density_graph_2 <- density_graph_2%>% pivot_longer( everything(),
                                                    names_to = "name",
                                                    values_to = "value")
density_graph_2$name <- factor(density_graph_2$name, 
                               levels = c('Beta-lactam',
                                          'Aminoglycoside',
                                          'Quinolone',
                                          'Fosfomycin',
                                          'Tetracycline',
                                          'Efflux',
                                          'Phenicol',
                                          'Macrolide',
                                          'Glycopeptide',
                                          'Sulfonamide',
                                          'Trimethoprim',
                                          'Streptogramin',
                                          'Lincosamide',
                                          'Colistin',
                                          'Streptothricin',
                                          'Bleomycin',
                                          'Rifamycin',
                                          'Fosmidomycin',
                                          'Fluoroquinolone',
                                          'Multidrug',
                                          'Other resistance genes',
                                          "Total resistance genes"))

ggplot(data =density_graph_1, aes(x = value)) +
  geom_density(fill = "#fbb1a2", alpha = 0.5) +
  theme_bw() +  
  facet_wrap(~ name,ncol = 3,nrow =4,  scales = "free",strip.position = "top")+
  labs(title = NULL, x = NULL, y = "Density")
ggsave( last_plot(),
        width = 12,height =10,
        filename =  paste0("图片/density_graph_1.pdf")) 
ggplot(data =density_graph_2, aes(x = value)) +
  geom_density(fill = "#fbb1a2", alpha = 0.5) +
  theme_bw() +  
  facet_wrap(~ name,ncol = 4,nrow =6,  scales = "free",strip.position = "top")+
  labs(title = NULL, x = NULL, y = "Density")
ggsave( last_plot(),
        width = 12,height =10,
        filename =  paste0("图片/density_graph_2.pdf")) 


var(paper.data.total.10$Total.genes)
mean(paper.data.total.10$Total.genes)


######07.基线表格####

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$Total.genes<-rowSums(paper.data.total.1[98:118])
density_graph_1 <-paper.data.total.1[c('average_pm25',
                                       'average_tmp',
                                       'average_pre',
                                       'average_NDVI',
                                       'GDP_per_capita',
                                       'Population_density',
                                       'Mortality_rate_of_infant',
                                       'Population_ages_65_and_above',
                                       'Current_health_expenditure_per_capita',
                                       'People_using_at_least_basic_drinking_water_services'
)] 
names(density_graph_1) <- c(
  "PM2.5 (ug/m³)",
  "Temperature (oC)",
  "Precipitation (mm)",
  "NDVI (‰)",
  "GDP per capita (US$)",
  "Population density (per km²)" ,          
  "Mortality rate of infant (%)"   ,        
  "Population aged 65 and above (%)"    ,        
  "Current health expenditure per capita (US$)",
  "People using at least basic drinking-water services (%)")
paper.data.total.1<-cbind(paper.data.1[c("year","Country Name")],density_graph_1,paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
# df_new_names<-names(paper.data.total.1)
# df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")
# 
# colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$`Total resistance genes`<-rowSums(paper.data.total.1[14:34])
paper.data.total.1$year<-as.character(paper.data.total.1$year)


writeLines(paste0('`',names(paper.data.total.1),'`',","))
names(paper.data.total.1)
library(gtsummary)
tbl_summary(
  paper.data.total.1, 
  by = year,
  statistic = list(
    # all_continuous() ~ "{mean}\n({sd})", 
    # all_categorical() ~ "{n} ({p}%)"
    all_categorical() ~ "{n}"
  ),
  include = c(
    
    `Country Name`
  ),
  digits = list(all_categorical() ~ c(0, 1))
) %>%
  add_overall(digits = list(all_categorical() ~ c(0, 1))) %>%
  
  # modify_header(all_stat_cols() ~ "N = {n} ({style_percent(p)}%)") %>%
  add_p(pvalue_fun = purrr::partial(style_pvalue, digits = 3))


tbl_summary(
  paper.data.total.1, 
  by = `year`,
  statistic = list(
    all_continuous() ~ "{mean}\n({sd})", 
    all_categorical() ~ "{n}"
  ),
  include = c(
    
    `Scientific Name`
  ),
  digits = list(all_categorical() ~ c(0, 1))
) %>%
  add_overall(digits = list(all_categorical() ~ c(0, 1))) %>%
  
  # modify_header(all_stat_cols() ~ "N = {n} ({style_percent(p)}%)") %>%
  add_p(pvalue_fun = purrr::partial(style_pvalue, digits = 3))






str(paper.data.total.1)


writeLines(paste0('`',names(paper.data.total.1)[14:34],'`',"~ 'continuous',"))

tbl_summary(paper.data.total.1, 
            type = list(`Tetracycline`~ 'continuous',
                        `Macrolide`~ 'continuous',
                        `Aminoglycoside`~ 'continuous',
                        `Colistin`~ 'continuous',
                        `Efflux`~ 'continuous',
                        `Fosfomycin`~ 'continuous',
                        `Streptothricin`~ 'continuous',
                        `Quinolone`~ 'continuous',
                        `Sulfonamide`~ 'continuous',
                        `Trimethoprim`~ 'continuous',
                        `Bleomycin`~ 'continuous',
                        `Phenicol`~ 'continuous',
                        `Rifamycin`~ 'continuous',
                        `Fosmidomycin`~ 'continuous',
                        `Streptogramin`~ 'continuous',
                        `Lincosamide`~ 'continuous',
                        `Multidrug`~ 'continuous',
                        `Glycopeptide`~ 'continuous',
                        `Fluoroquinolone`~ 'continuous',
                        `Beta-lactam`~ 'continuous',
                        `Other antibiotic genes`~ 'continuous'),
            missing = 'no',  
            digits = list(all_continuous() ~ c(2, 2)),
            include = c(`PM2.5 (ug/m³)`,
                        `Temperature (oC)`,
                        `Precipitation (mm)`,
                        `NDVI (‰)`,
                        `GDP per capita (US$)`,
                        `Population density (per km²)`,
                        `Mortality rate of infant (%)`,
                        `Population aged 65 and above (%)`,
                        `Current health expenditure per capita (US$)`,
                        `People using at least basic drinking-water services (%)`,
                        `Tetracycline`,
                        `Macrolide`,
                        `Aminoglycoside`,
                        `Colistin`,
                        `Efflux`,
                        `Fosfomycin`,
                        `Streptothricin`,
                        `Quinolone`,
                        `Sulfonamide`,
                        `Trimethoprim`,
                        `Bleomycin`,
                        `Phenicol`,
                        `Rifamycin`,
                        `Fosmidomycin`,
                        `Streptogramin`,
                        `Lincosamide`,
                        `Multidrug`,
                        `Glycopeptide`,
                        `Fluoroquinolone`,
                        `Beta-lactam`,
                        `Other antibiotic genes`,
                        `Total resistance genes`),
            statistic = list(all_continuous() ~ "￥{mean}￥{sd}￥{p10}￥{p25}￥{p50}￥{p75}￥{p90}"))





tbl_summary(
  paper.data.total.1, 
  by = NULL,
  statistic = list(
    all_continuous() ~ "{mean}\n({sd})"
    # all_categorical() ~ "{n}"
  ),
  include = c(
    `PM2.5 (ug/m³)`,
    `Temperature (oC)`,
    `Precipitation (mm)`,
    `NDVI (‰)`,
    `GDP per capita (US$)`,
    `Population density (per km²)`,
    `Mortality rate of infant (%)`,
    `Population aged 65 and above (%)`,
    `Current health expenditure per capita (US$)`,
    `People using at least basic drinking-water services (%)`,
    `Tetracycline`,
    `Macrolide`,
    `Aminoglycoside`,
    `Colistin`,
    `Efflux`,
    `Fosfomycin`,
    `Streptothricin`,
    `Quinolone`,
    `Sulfonamide`,
    `Trimethoprim`,
    `Bleomycin`,
    `Phenicol`,
    `Rifamycin`,
    `Fosmidomycin`,
    `Streptogramin`,
    `Lincosamide`,
    `Multidrug`,
    `Glycopeptide`,
    `Fluoroquinolone`,
    `Beta-lactam`,
    `Other antibiotic genes`,
    `Total resistance genes`
  ),
  digits = list(all_categorical() ~ c(0, 1))
) %>%
  add_overall(digits = list(all_categorical() ~ c(0, 1))) %>%
  
  # modify_header(all_stat_cols() ~ "N = {n} ({style_percent(p)}%)") %>%
  add_p(pvalue_fun = purrr::partial(style_pvalue, digits = 3))


#引入需要的库
install.packages("flextable")
library(flextable)
library(officer)


flex_table <- as_flex_table(summary_table)



# 接下来是之前创建和保存Word文档的代码
doc <- read_docx()
doc <- body_add_flextable(doc, flex_table)




# 保存到Word文档
print(doc, target = "summary_table_results.docx")



######08密度散点图####
# install.packages("ggpointdensity")
library(ggpointdensity) 
library(viridis)
install.packages("ggpmisc")
library(ggpmisc)
ggplot(paper.data.total.1, aes(average_pm25, Total.genes)) +
  geom_pointdensity() + 
  geom_smooth(method = "glm",  
              # formula = y ~ x, 
              linewidth = 1, 
              linetype=1, 
              se = TRUE,
              color = "#ffcb00")+
  # stat_cor(method = "pearson",label.x = 60, label.y = 20,size=4)+ 
  # stat_poly_eq(formula = y ~ x, aes(label = paste(after_stat(eq.label), 
  #                                                 sep = "~~~")), parse = TRUE, 
  #              label.x = 0.88, label.y = 0.22,size=4)+ 
  # annotate("text", x = 68 , y = 32,label = "N = 2900", size= 4)+
  scale_x_log10()+
  # scale_y_continuous(limits = c(0,80),breaks = seq(0,80,5))+
  theme_bw()+ 
  theme(panel.grid = element_blank(),
        legend.position = c(0.15,0.75), 
        axis.text = element_text(size = 10))+ 
  labs(x=bquote("PM"[2.5]~(μg/m^3)), y = "Number of antibiotic resistance genes ")+ 
  scale_color_viridis(option = "turbo")

##########
# install.packages("pscl")
library(pscl)

names(paper.data.total.1)
model1 <- zeroinfl(Total.genes ~  GDP_per_capita+
                     Population_density+
                     Mortality_rate_of_infant+
                     Population_ages_65_and_above+
                     #PM2.5_air_pollution+
                     Current_health_expenditure_per_capita+
                     #Hospital_beds+
                     # Labor_force_with_advanced_education+
                     People_using_at_least_basic_drinking_water_services+
                     # Antibiotic_consumption+
                     # flood_index+
                     average_NDVI+
                     average_pm25+
                     # average_pm25_1+
                     # average_pm25_2+
                     # #average_pm25_3+
                     # average_pm25_4+
                     # #average_pm25_5+
                     # #average_pm25_6+
                     # #average_pm25_7+
                     
                     
                     
                     #average_tmp_0+
                   #average_tmp_1+
                   #average_tmp_2+
                   average_tmp+
                     average_pre |  GDP_per_capita+
                     Population_density+
                     Mortality_rate_of_infant+
                     Population_ages_65_and_above+
                     #PM2.5_air_pollution+
                     Current_health_expenditure_per_capita+
                     #Hospital_beds+
                     # Labor_force_with_advanced_education+
                     People_using_at_least_basic_drinking_water_services+
                     # Antibiotic_consumption+
                     # flood_index+
                     average_NDVI+
                     average_pm25+
                     # average_pm25_1+
                     # average_pm25_2+
                     # #average_pm25_3+
                     # average_pm25_4+
                     # #average_pm25_5+
                     # #average_pm25_6+
                     # #average_pm25_7+
                     
                     
                     
                     #average_tmp_0+
                   #average_tmp_1+
                   #average_tmp_2+
                   average_tmp+
                     average_pre, data = paper.data.total.1, dist = "negbin")
summary(model1)

BIC(model1)

model2 <- glm.nb(Total.genes~ 
                   GDP_per_capita+
                   Population_density+
                   Mortality_rate_of_infant+
                   Population_ages_65_and_above+
                   #PM2.5_air_pollution+
                   Current_health_expenditure_per_capita+
                   #Hospital_beds+
                   # Labor_force_with_advanced_education+
                   People_using_at_least_basic_drinking_water_services+
                   # Antibiotic_consumption+
                   # flood_index+
                   average_NDVI+
                   average_pm25+
                   # average_pm25_1+
                   # average_pm25_2+
                   # #average_pm25_3+
                   # average_pm25_4+
                   # #average_pm25_5+
                   # #average_pm25_6+
                   # #average_pm25_7+
                   
                   
                   
                   #average_tmp_0+
                 #average_tmp_1+
                 #average_tmp_2+
                 average_tmp+
                   average_pre
                 
                 , data = paper.data.total.1)

BIC(model2)
summary(model2)
exp(0.1094)-1
# vif(model)

cols_to_process <- c('Beta-lactam',
                     'Aminoglycoside',
                     'Quinolone',
                     'Fosfomycin',
                     'Tetracycline',
                     'Efflux',
                     'Phenicol',
                     'Macrolide',
                     'Glycopeptide',
                     'Sulfonamide',
                     'Trimethoprim',
                     'Streptogramin',
                     'Lincosamide',
                     'Colistin',
                     'Streptothricin',
                     'Bleomycin',
                     'Rifamycin',
                     'Fosmidomycin',
                     'Fluoroquinolone',
                     'Multidrug',
                     # 'Pleuromutilin',
                     # 'Fusidic acid',
                     # 'Mupirocin',
                     'Other antibiotic genes'  )

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names
paper.data.total.1<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)



#####1.分析性研究#####
#####1.0过度离散检验#####

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$Total.genes<-rowSums(paper.data.total.1[98:118])

paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)

# install.packages("AER")
library(AER) 
Group<-c( 'Beta-lactam',
          'Aminoglycoside',
          'Quinolone',
          'Fosfomycin',
          'Tetracycline',
          'Efflux',
          'Phenicol',
          'Macrolide',
          'Glycopeptide',
          'Sulfonamide',
          'Trimethoprim',
          'Streptogramin',
          'Lincosamide',
          'Colistin',
          'Streptothricin',
          'Bleomycin',
          'Rifamycin',
          'Fosmidomycin',
          'Fluoroquinolone',
          'Multidrug',
          # 'Pleuromutilin',
          # 'Fusidic acid',
          # 'Mupirocin',
          'Other resistance genes',
          'Total resistance genes')
dependent_variables <-c('Beta_lactam',
                        'Aminoglycoside',
                        'Quinolone',
                        'Fosfomycin',
                        'Tetracycline',
                        'Efflux',
                        'Phenicol',
                        'Macrolide',
                        'Glycopeptide',
                        'Sulfonamide',
                        'Trimethoprim',
                        'Streptogramin',
                        'Lincosamide',
                        'Colistin',
                        'Streptothricin',
                        'Bleomycin',
                        'Rifamycin',
                        'Fosmidomycin',
                        'Fluoroquinolone',
                        'Multidrug',
                        # 'Pleuromutilin',
                        # 'Fusidic_acid',
                        # 'Mupirocin',
                        'Other_antibiotic_genes',
                        'Total.genes')

dispersion<-data.frame() 
for (i in 1:length(c(dependent_variables))) {
  model <- glm(as.formula(paste(c(dependent_variables)[i]," ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI")) ,
               family = poisson(),
               data=paper.data.total.10)
  fit_df1<-data.frame()
  for (j in 1:2) {
    dispersion_test <- dispersiontest(model, trafo = c(1,2)[j])  
    fit_df<-data.frame(trafo=c(1,2)[j],
                       alpha = dispersion_test$estimate[[1]],
                       z=dispersion_test$statistic[[1]],
                       p=dispersion_test$p.value[[1]])%>%
      mutate( Group=Group[i],
              z=formatC(z, digits = 3, format = "f"),
              p=formatC(p, digits = 3, format = "f")
              
      )%>%
      mutate(p=ifelse(p <0.001,'<0.001',p))
    
    fit_df1<-rbind(fit_df1,fit_df)
    
  }
  print(i)
  dispersion<-rbind(dispersion,fit_df1)
}


write.table(dispersion,"过度离散检验.csv",row.names=FALSE,col.names=TRUE,sep=",")



print(dispersion_test)  
#####1.1logistic回归#####
# install.packages("broom")

# Group<-C("Flood","Tempreture","PM2.5")
Group<-c( 'Beta-lactam',
          'Aminoglycoside',
          'Quinolone',
          'Fosfomycin',
          'Tetracycline',
          'Efflux',
          'Phenicol',
          'Macrolide',
          'Glycopeptide',
          'Sulfonamide',
          'Trimethoprim',
          'Streptogramin',
          'Lincosamide',
          'Colistin',
          'Streptothricin',
          'Bleomycin',
          'Rifamycin',
          'Fosmidomycin',
          'Fluoroquinolone',
          'Multidrug',
          # 'Pleuromutilin',
          # 'Fusidic acid',
          # 'Mupirocin',
          'Other resistance genes',
          'Total resistance genes')
dependent_variables <-c('Beta_lactam',
                        'Aminoglycoside',
                        'Quinolone',
                        'Fosfomycin',
                        'Tetracycline',
                        'Efflux',
                        'Phenicol',
                        'Macrolide',
                        'Glycopeptide',
                        'Sulfonamide',
                        'Trimethoprim',
                        'Streptogramin',
                        'Lincosamide',
                        'Colistin',
                        'Streptothricin',
                        'Bleomycin',
                        'Rifamycin',
                        'Fosmidomycin',
                        'Fluoroquinolone',
                        'Multidrug',
                        # 'Pleuromutilin',
                        # 'Fusidic_acid',
                        # 'Mupirocin',
                        'Other_antibiotic_genes',
                        'Total.genes')





names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$Total.genes<-rowSums(paper.data.total.1[98:118])

paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)
#####基因数量####
final.number<-data.frame() 
for (i in 1:length(c(dependent_variables))) {
  Number=sum(paper.data.total.1[dependent_variables[i]])
  model <- glm.nb(as.formula(paste(c(dependent_variables)[i]," ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI")) ,
                  # family = binomial(link = "logit"), 
                  data=paper.data.total.10)
  # fit_df<-tidy(model)%>%
  #   mutate(OR=exp(estimate),
  #          P=formatC(p.value, digits = 3, format = "f"),
  #          Lower=exp(estimate-1.96*std.error),
  #          Upper=exp(estimate+1.96*std.error),
  #          label=ifelse(p.value <0.001,'<0.001',P),
  #          Group=Group[i]) %>%
  #   mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
  #                     " (", formatC(Lower, digits = 2, format = "f"), ",",
  #                     formatC(Upper, digits = 2, format = "f"), ")"))
  fit_df<-tidy(model)%>%
    mutate(OR=(exp(estimate)-1)*100,
           P=formatC(p.value, digits = 3, format = "f"),
           Lower=(exp(estimate-1.96*std.error)-1)*100,
           Upper=(exp(estimate+1.96*std.error)-1)*100,
           label=ifelse(p.value <0.001,'<0.001',P),
           Group=Group[i],
           Number=Number,
           Number_genes=Number_genes) %>%
    mutate(CI = paste(formatC(OR, digits = 1, format = "f"),
                      " (", formatC(Lower, digits = 1, format = "f"), ",",
                      formatC(Upper, digits = 1, format = "f"), ")"))
  
  
  print(i)
  fit_df<-fit_df[9,]
  
  final.number<-rbind(final.number,fit_df)
}


final.number <- final.number %>%
  arrange(OR) 
# %>% # 按照OR值排序，如果需要降序排列可以使用 arrange(desc(OR))
#   mutate(Group_sorted = factor(Group, levels = unique(Group)))
final.number$x<-1:22

library(scales)  #####坐标转换#####

# 定义转换函数和反转换函数  
my_trans <- function(x) {  
  ifelse(x > 25, x-10, x)  
}  

my_inverse <- function(x) {  
  ifelse(x > 25, x+10, x)  # 注意：这里假设x > 0是因为log(x)的定义域是x > 0  
}  

# 创建新的转换对象  
my_custom_trans <- trans_new("my_custom", transform = my_trans, inverse = my_inverse)
# install.packages("ggbreak")
# library(ggbreak)

ggplot(data = final.number)+
  # scale_color_manual(values = color1)+
  geom_hline(aes(yintercept = 0),linetype="dashed",linewidth=0.3,color="black")+
  
  geom_vline(aes(xintercept = 23),linetype="solid",linewidth=0.5,color="black")+
  # geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.5,color="black")+
  geom_point(aes(x =x, y = OR),size=2,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
             #,shape=forest$Shape
  )+
  geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.6,width=0,position = position_dodge(width = 0.6),alpha=1)+
  
  
  # geom_point(aes(x =24, y = 5.5),size=1.5,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
  #            #,shape=forest$Shape
  # )+
  # geom_errorbar(aes(x = 24,ymin = 4.83, ymax = 6.14),color='#ec7784',size=0.2,width=0,position = position_dodge(width = 0.6),alpha=1)+
  # 
  
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    axis.text.x = element_text(size = 14,face="bold"),
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    # axis.line.y = element_blank() 
    axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(
    trans = my_custom_trans,
    limits = c(-35,85),breaks = seq(-10,40,5))+ 
  scale_x_continuous(limits = c(1,24))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  geom_text(data=final.number,aes(x=x,y=48,label=CI),size=5,hjust=0.5,color='#ec7784')+
  geom_text(data=final.number,aes(x=x,y=-33,label=Group),size=5,hjust=0,color='black')+
  geom_text(data=final.number,aes(x=x,y=68,label=label),size=5,hjust=0.5,color='black')+
  geom_text(data=final.number,aes(x=x,y=85,label=prettyNum(Number, big.mark = ",")),size=5,hjust=1,color='black')+
  # geom_text(data=fit_summary_df_selected,aes(x=x,y=y3,label=P_interaction),size=4,hjust=0.5)+
  
  annotate("text", x = 24, y = -8, label = "PC of resistance genes per isolate (%), 95% CI",fontface = "bold",color='#ec7784', size = 5, hjust = 0)+
  annotate("text", x = 24, y = -35, label = "Antibiotic type",fontface = "bold",color='black', size = 5, hjust = 0)+
  annotate("text", x = 24, y =68, label = "P -values",fontface = "bold",color='black', size = 5, hjust = 0.5)+
  annotate("text", x = 24, y = 82, label = "Gene counts",fontface = "bold",color='black', size = 5, hjust = 0.5)
ggsave( last_plot(),
        width = 10,height =8,
        filename =  paste0("图片/number.pdf"))








#####or值####

cols_to_process <- c('Beta-lactam',
                     'Aminoglycoside',
                     'Quinolone',
                     'Fosfomycin',
                     'Tetracycline',
                     'Efflux',
                     'Phenicol',
                     'Macrolide',
                     'Glycopeptide',
                     'Sulfonamide',
                     'Trimethoprim',
                     'Streptogramin',
                     'Lincosamide',
                     'Colistin',
                     'Streptothricin',
                     'Bleomycin',
                     'Rifamycin',
                     'Fosmidomycin',
                     'Fluoroquinolone',
                     'Multidrug',
                     # 'Pleuromutilin',
                     # 'Fusidic acid',
                     # 'Mupirocin',
                     'Other antibiotic genes'  )

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
for (col in cols_to_process) {
  paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
}
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  
Group<-c( 'Beta-lactam',
          'Aminoglycoside',
          'Quinolone',
          'Fosfomycin',
          'Tetracycline',
          'Efflux',
          'Phenicol',
          'Macrolide',
          'Glycopeptide',
          'Sulfonamide',
          
          'Trimethoprim',
          'Streptogramin',
          'Lincosamide',
          'Colistin',
          'Streptothricin',
          'Bleomycin',
          'Rifamycin',
          'Fosmidomycin',
          'Fluoroquinolone',
          'Multidrug',
          # 'Pleuromutilin',
          # 'Fusidic acid',
          # 'Mupirocin',
          'Other resistance genes')


paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)
final.or<-data.frame() 
for (i in 1:(length(dependent_variables)-1)) {
  coef=sum(paper.data.total[cols_to_process[i]])/sum(rowSums(paper.data.total[, 2:22], na.rm = TRUE))
  Number=sum(paper.data.total[cols_to_process[i]])
  model <- glm(as.formula(paste(dependent_variables[i]," ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI")) ,
               family = binomial(link = "logit"), 
               data=paper.data.total.10)
  fit_df<-tidy(model)%>%
    mutate(OR=exp(estimate),
           P=formatC(p.value, digits = 3, format = "f"),
           Lower=exp(estimate-1.96*std.error),
           Upper=exp(estimate+1.96*std.error),
           label=ifelse(p.value <0.001,'<0.001',P),
           Group=Group[i],
           coef=coef,
           Number=Number) %>%
    mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
                      " (", formatC(Lower, digits = 2, format = "f"), ",",
                      formatC(Upper, digits = 2, format = "f"), ")"))
  # fit_df<-tidy(model)%>%
  #   mutate(OR=estimate,
  #          P=formatC(p.value, digits = 3, format = "f"),
  #          Lower=estimate-1.96*std.error,
  #          Upper=estimate+1.96*std.error,
  #          label=ifelse(p.value <0.001,'<0.001',P),
  #          Group=Group[i]) %>%
  #   mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
  #                     " (", formatC(Lower, digits = 2, format = "f"), ",",
  #                     formatC(Upper, digits = 2, format = "f"), ")"))
  # 
  
  
  fit_df<-as.data.frame(fit_df[9,])
  
  final.or<-rbind(final.or,fit_df)
}
names(final.or)

# res <- rma(yi = log(final.or$OR), sei = sqrt((log(final.or$Upper) - log(final.or$Lower))^2 / 4), weights = final.or$Number, method = "DL")
# exp(res$b)[1]
# exp(res$ci.lb)
# exp(res$ci.ub)
final.or22<-c("average_pm25",as.numeric(mean(final.or$estimate)),as.numeric(mean(final.or$std.error)),NA,NA,as.numeric(sum(final.or$OR*final.or$coef)),NA,as.numeric(sum(final.or$Lower*final.or$coef)),as.numeric(sum(final.or$Upper*final.or$coef)),"<0.001","Total resistance genes",1,sum(rowSums(paper.data.total[, 2:22], na.rm = TRUE)),NA)


final.or22<-c("average_pm25",as.numeric(mean(final.or$estimate)),as.numeric(mean(final.or$std.error)),NA,NA,as.numeric(sum(final.or$OR*final.or$coef)),NA,as.numeric(sum(final.or$Lower*final.or$coef)),as.numeric(sum(final.or$Upper*final.or$coef)),"<0.001","Total resistance genes",1,sum(rowSums(paper.data.total[, 2:22], na.rm = TRUE)),NA)
final.or<-rbind(final.or,final.or22)

final.or[22,14]<-paste(formatC(as.numeric(final.or[22,6]), digits = 2, format = "f"),
                       " (", formatC(as.numeric(final.or[22,8]), digits = 2, format = "f"), ",",
                       formatC(as.numeric(final.or[22,9]), digits = 2, format = "f"), ")")



final.or<-final.or%>%mutate(OR=as.numeric(OR),
                            Lower=as.numeric(Lower),
                            Upper=as.numeric(Upper))

final.or <- final.or %>%
  arrange(OR) 
# %>% # 按照OR值排序，如果需要降序排列可以使用 arrange(desc(OR))
#   mutate(Group_sorted = factor(Group, levels = unique(Group)))
final.or$x<-1:22


ggplot(data = final.or)+
  # scale_color_manual(values = color1)+
  geom_hline(aes(yintercept = 1),linetype="dashed",linewidth=0.3,color="black")+
  
  geom_vline(aes(xintercept = 23),linetype="solid",linewidth=0.5,color="black")+
  # geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.5,color="black")+
  geom_point(aes(x =x, y = OR),size=2,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
             #,shape=forest$Shape
  )+
  
  
  
  
  geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.6,width=0,position = position_dodge(width = 0.6),alpha=1)+
  
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    axis.text.x = element_text(size = 14,face="bold"),
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    # axis.line.y = element_blank() 
    axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(limits = c(0.2,2.4),breaks = seq(0.8,1.4,0.2))+ 
  scale_x_continuous(limits = c(1,24))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  geom_text(data=final.or,aes(x=x,y=1.44,label=CI),size=5,hjust=0,color='#ec7784')+
  geom_text(data=final.or,aes(x=x,y=0.25,label=Group),size=5,hjust=0,color='black')+
  geom_text(data=final.or,aes(x=x,y=2,label=label),size=5,hjust=0.5,color='black')+
  geom_text(data=final.or,aes(x=x,y=2.4,label=prettyNum(Number, big.mark = ",")),size=5,hjust=1,color='black')+
  # geom_text(data=fit_summary_df_selected,aes(x=x,y=y3,label=P_interaction),size=4,hjust=0.5)+
  
  annotate("text", x = 24, y = 0.64, label = "OR of carrying at least one resistence gene, 95% CI",fontface = "bold",color='#ec7784', size = 5, hjust = 0)+
  annotate("text", x = 24, y = 0.2, label = "Antibiotic type",fontface = "bold",color='black', size = 5, hjust = 0)+
  
  annotate("text", x = 24, y = 2, label = "P -values",fontface = "bold",color='black', size = 5, hjust = 0.5)+
  annotate("text", x = 24, y = 2.15, label = "Gene counts",fontface = "bold",color='black', size = 5, hjust = 0)
# annotate("text", x = 0, y = 4.3, label = "P for interaction",fontface = "bold", size = 4, hjust = 0.5)+
# annotate("text", x = -1.1, y = -1.2, label =c("No breastfed","Maternal smoking","Low birth weight")[j],fontface = "bold", size = 5, hjust = 0)+

# geom_segment(aes(y = 1.05, yend = 1.3, x = 26.5, xend = 26.5),
#              arrow = arrow(length = unit(0.2, "cm")), # 设置箭头属性
#              linewidth = 0.5, color = "black")+
# geom_segment(aes(y = 0.95, yend = 0.7, x = 26.5, xend = 26.5),
#              arrow = arrow(length = unit(0.2, "cm")), # 设置箭头属性
#              linewidth = 0.5, color = "black")+
# annotate("text", x = 27, y = 1.01, label = "Reduced risk        Increaced risk",fontface = "plain", size = 3, hjust = 0.5)


ggsave( last_plot(),
        width = 10,height =8,
        filename =  paste0("图片/OR.pdf"))


# 加载所需包
library(ggplot2)
library(rms)

#####number限制性立方样条的模型#####

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$Total.genes<-rowSums(paper.data.total.1[94:117])





ddist <- datadist(paper.data.total.1)
options(datadist = "ddist")
ddist$limits["Adjust to", 'average_pm25'] <- 10


pred.number<-data.frame(A=1:200) 


model_rcs <- rms::Glm(as.formula(paste("Total.genes"," ~ rcs(average_pm25, 3) +GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+average_tmp+average_NDVI")),
                      family = negative.binomial(link = "log", theta = 1.01175),
                      data = paper.data.total.1)


# 生成预测数据
pred <- data.frame(Predict(model_rcs, average_pm25, 
                           # fun = exp,
                           ref.zero =T)[c("average_pm25","yhat","lower","upper")])
# paste0(c("average_pm25","yhat","lower","upper"),"_",dependent_variables[i])
# names(pred)<-paste0(c("average_pm25","yhat","lower","upper"),"_",dependent_variables[i])

pred.number<-cbind(pred[1],(exp(pred[2:4])-1)*100)

pred.number








# 绘制曲线
ggplot(data = pred.number) +
  geom_line( aes(x = average_pm25 , y = yhat), linetype = 'solid', size = 1, alpha = 1, color = '#ec7784')+
  geom_ribbon( aes(x = average_pm25 , ymin = lower, ymax = upper), alpha = 0.2, fill = '#ec7784')+
  geom_hline(yintercept=0, linetype=2, color="black") +
  geom_vline(xintercept=10, linetype=2, color="blue") +
  
  labs(x = bquote("PM"[2.5]~(μg/m^3)), y = "PC of resistance genes per isolate (%)")+
  scale_y_continuous(limits = c(-25,370),breaks = seq(-50,370,50))+ 
  scale_x_continuous(limits = c(0,150),breaks = seq(0,150,10))+
  theme_bw() +
  theme(
    axis.line=element_line(),
    panel.grid=element_blank()
    # , plot.title = element_text(hjust = 0.5)
  ) 



ggsave( last_plot(),
        width = 7.5,height =6,
        filename =  paste0("图片/NumberrcsNB.pdf"))

#####Or值限制性立方样条####

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
for (col in cols_to_process) {
  paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
}
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


# 拟合带有限制性立方样条的模型
ddist <- datadist(paper.data.total.1)
options(datadist = "ddist")
ddist$limits["Adjust to", 'average_pm25'] <- 10

pred.or<-data.frame(A=1:200) 
for (i in 1:length(dependent_variables)) {
  coef=sum(paper.data.total[Group[i]])/sum(rowSums(paper.data.total[, 2:25], na.rm = TRUE))
  model_rcs <- rms::Glm(as.formula(paste(dependent_variables[i]," ~ rcs(average_pm25, 3) +GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+average_tmp")),
                        family = binomial(link = "logit"),
                        data = paper.data.total.1)
  
  
  # 生成预测数据
  pred <- data.frame(Predict(model_rcs, average_pm25, 
                             fun = exp,
                             ref.zero =T)[c("average_pm25","yhat","lower","upper")])
  pred$coef<-coef
  # paste0(c("average_pm25","yhat","lower","upper"),"_",dependent_variables[i])
  names(pred)<-paste0(c("average_pm25","yhat","lower","upper","coef"),"_",dependent_variables[i])
  
  pred.or<-cbind(pred.or,pred)
  
  
}
# pred.or$yhat<-rowMeans(pred.or[seq(from = 3, by = 4, length.out = 24)])
# pred.or$lower<-rowMeans(pred.or[seq(from = 4, by = 4, length.out = 24)])
# pred.or$upper<-rowMeans(pred.or[seq(from = 5, by = 4, length.out = 24)])
pred.or<-pred.or%>%
  mutate(yhat=(yhat_Beta_lactam*coef_Beta_lactam+
                 yhat_Aminoglycoside*coef_Aminoglycoside+
                 yhat_Quinolone*coef_Quinolone+
                 yhat_Fosfomycin*coef_Fosfomycin+
                 yhat_Tetracycline*coef_Tetracycline+
                 yhat_Efflux*coef_Efflux+
                 yhat_Phenicol*coef_Phenicol+
                 yhat_Macrolide*coef_Macrolide+
                 yhat_Glycopeptide*coef_Glycopeptide+
                 yhat_Sulfonamide*coef_Sulfonamide+
                 yhat_Trimethoprim*coef_Trimethoprim+
                 yhat_Streptogramin*coef_Streptogramin+
                 yhat_Lincosamide*coef_Lincosamide+
                 yhat_Colistin*coef_Colistin+
                 yhat_Streptothricin*coef_Streptothricin+
                 yhat_Bleomycin*coef_Bleomycin+
                 yhat_Rifamycin*coef_Rifamycin+
                 yhat_Fosmidomycin*coef_Fosmidomycin+
                 yhat_Fluoroquinolone*coef_Fluoroquinolone+
                 yhat_Multidrug*coef_Multidrug+
                 yhat_Pleuromutilin*coef_Pleuromutilin+
                 yhat_Fusidic_acid*coef_Fusidic_acid+
                 yhat_Mupirocin*coef_Mupirocin+
                 yhat_Other_antibiotic_genes*coef_Other_antibiotic_genes),
         lower=(lower_Beta_lactam*coef_Beta_lactam+
                  lower_Aminoglycoside*coef_Aminoglycoside+
                  lower_Quinolone*coef_Quinolone+
                  lower_Fosfomycin*coef_Fosfomycin+
                  lower_Tetracycline*coef_Tetracycline+
                  lower_Efflux*coef_Efflux+
                  lower_Phenicol*coef_Phenicol+
                  lower_Macrolide*coef_Macrolide+
                  lower_Glycopeptide*coef_Glycopeptide+
                  lower_Sulfonamide*coef_Sulfonamide+
                  lower_Trimethoprim*coef_Trimethoprim+
                  lower_Streptogramin*coef_Streptogramin+
                  lower_Lincosamide*coef_Lincosamide+
                  lower_Colistin*coef_Colistin+
                  lower_Streptothricin*coef_Streptothricin+
                  lower_Bleomycin*coef_Bleomycin+
                  lower_Rifamycin*coef_Rifamycin+
                  lower_Fosmidomycin*coef_Fosmidomycin+
                  lower_Fluoroquinolone*coef_Fluoroquinolone+
                  lower_Multidrug*coef_Multidrug+
                  lower_Pleuromutilin*coef_Pleuromutilin+
                  lower_Fusidic_acid*coef_Fusidic_acid+
                  lower_Mupirocin*coef_Mupirocin+
                  lower_Other_antibiotic_genes*coef_Other_antibiotic_genes),
         upper=(upper_Beta_lactam*coef_Beta_lactam+
                  upper_Aminoglycoside*coef_Aminoglycoside+
                  upper_Quinolone*coef_Quinolone+
                  upper_Fosfomycin*coef_Fosfomycin+
                  upper_Tetracycline*coef_Tetracycline+
                  upper_Efflux*coef_Efflux+
                  upper_Phenicol*coef_Phenicol+
                  upper_Macrolide*coef_Macrolide+
                  upper_Glycopeptide*coef_Glycopeptide+
                  upper_Sulfonamide*coef_Sulfonamide+
                  upper_Trimethoprim*coef_Trimethoprim+
                  upper_Streptogramin*coef_Streptogramin+
                  upper_Lincosamide*coef_Lincosamide+
                  upper_Colistin*coef_Colistin+
                  upper_Streptothricin*coef_Streptothricin+
                  upper_Bleomycin*coef_Bleomycin+
                  upper_Rifamycin*coef_Rifamycin+
                  upper_Fosmidomycin*coef_Fosmidomycin+
                  upper_Fluoroquinolone*coef_Fluoroquinolone+
                  upper_Multidrug*coef_Multidrug+
                  upper_Pleuromutilin*coef_Pleuromutilin+
                  upper_Fusidic_acid*coef_Fusidic_acid+
                  upper_Mupirocin*coef_Mupirocin+
                  upper_Other_antibiotic_genes*coef_Other_antibiotic_genes))
# writeLines(paste0(names(pred.or)[seq(from = 3, by = 5, length.out = 24)],"*",names(pred.or)[seq(from = 6, by = 5, length.out = 24)],"+"))
# writeLines(paste0(names(pred.or)[seq(from = 4, by = 5, length.out = 24)],"*",names(pred.or)[seq(from = 6, by = 5, length.out = 24)],"+"))
# writeLines(paste0(names(pred.or)[seq(from = 5, by = 5, length.out = 24)],"*",names(pred.or)[seq(from = 6, by = 5, length.out = 24)],"+"))
# 
# 
# 
# 
# 
# 
# writeLines(paste0("geom_line( aes(x = average_pm25_Beta_lactam , y =", names(pred.or)[seq(from = 3, by = 4, length.out = 24)],"), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
#                     geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =", names(pred.or)[seq(from = 4, by = 4, length.out = 24)],", ymax =" ,names(pred.or)[seq(from = 5, by = 4, length.out = 24)],"), alpha = 0.05, fill = 'blue')+") )
# 





###大图
ggplot(data = pred.or) +
  geom_line( aes(x = average_pm25_Beta_lactam , y = yhat), linetype = 'solid', size = 1, alpha = 1, color = '#ec7784')+
  geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin = lower, ymax = upper), alpha = 0.2, fill = '#ec7784')+
  
  
  
  # geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Beta_lactam), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  # geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Beta_lactam, ymax =upper_Beta_lactam), alpha = 0.05, fill = 'blue')+
  # geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Aminoglycoside), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  # geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Aminoglycoside, ymax =upper_Aminoglycoside), alpha = 0.05, fill = 'blue')+
  # geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Quinolone), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  # geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Quinolone, ymax =upper_Quinolone), alpha = 0.05, fill = 'blue')+
  # geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Fosfomycin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  # geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Fosfomycin, ymax =upper_Fosfomycin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Tetracycline), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Tetracycline, ymax =upper_Tetracycline), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Efflux), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Efflux, ymax =upper_Efflux), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Phenicol), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Phenicol, ymax =upper_Phenicol), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Macrolide), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Macrolide, ymax =upper_Macrolide), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Glycopeptide), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Glycopeptide, ymax =upper_Glycopeptide), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Sulfonamide), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Sulfonamide, ymax =upper_Sulfonamide), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Trimethoprim), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Trimethoprim, ymax =upper_Trimethoprim), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Streptogramin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Streptogramin, ymax =upper_Streptogramin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Lincosamide), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Lincosamide, ymax =upper_Lincosamide), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Colistin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Colistin, ymax =upper_Colistin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Streptothricin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Streptothricin, ymax =upper_Streptothricin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Bleomycin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Bleomycin, ymax =upper_Bleomycin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Rifamycin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Rifamycin, ymax =upper_Rifamycin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Fosmidomycin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Fosmidomycin, ymax =upper_Fosmidomycin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Fluoroquinolone), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Fluoroquinolone, ymax =upper_Fluoroquinolone), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Multidrug), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Multidrug, ymax =upper_Multidrug), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Pleuromutilin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Pleuromutilin, ymax =upper_Pleuromutilin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Fusidic_acid), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Fusidic_acid, ymax =upper_Fusidic_acid), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Mupirocin), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Mupirocin, ymax =upper_Mupirocin), alpha = 0.05, fill = 'blue')+
# geom_line( aes(x = average_pm25_Beta_lactam , y =yhat_Other_antibiotic_genes), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
# geom_ribbon( aes(x = average_pm25_Beta_lactam , ymin =lower_Other_antibiotic_genes, ymax =upper_Other_antibiotic_genes), alpha = 0.05, fill = 'blue')+
# 
scale_y_continuous(limits = c(0,12),breaks = seq(0,12,2))+ 
  scale_x_continuous(limits = c(0,150),breaks = seq(0,150,10))+
  
  
  geom_hline(yintercept=1, linetype=2, color="black") +
  geom_vline(xintercept=10, linetype=2, color="blue") +
  
  labs(x = bquote("PM"[2.5]~(μg/m^3)), y = "OR of carrying at least one resistance gene ")+
  
  theme_bw() +
  theme(
    axis.line=element_line(),
    panel.grid=element_blank()
    # , plot.title = element_text(hjust = 0.5)
  )



ggsave( last_plot(),
        width = 7.5,height =6,
        filename =  paste0("图片/ORrcs.pdf"))













plot.list.number[[24]]
library(ggpubr)
p3<-ggarrange(plot.list[[1]],plot.list[[2]],plot.list[[3]],plot.list[[4]],plot.list[[5]],plot.list[[6]],
              plot.list[[7]],plot.list[[8]],plot.list[[9]],plot.list[[10]],plot.list[[11]],plot.list[[12]],
              plot.list[[13]],plot.list[[14]],plot.list[[15]],plot.list[[16]],plot.list[[17]],plot.list[[18]],
              plot.list[[19]],plot.list[[20]],plot.list[[21]],plot.list[[22]],plot.list[[23]],plot.list[[24]],
              nrow = 4,ncol = 6, labels = NA,font.label = list(size=12))

ggsave( p3,
        width = 24,height =18,
        filename =  paste0("p3.pdf"))









#####2.分层分析####
name.1<-c('Escherichia_coli',
          'Klebsiella_pneumoniae',
          'Staphylococcus_aureus',
          'Enterococcus_faecium',
          
          'Acinetobacter_baumannii',
          'Pseudomonas_aeruginosa',
          'Salmonella_enterica',
          'Clostridioides_difficile',
          'Streptococcus_pneumoniae',
          'Listeria_monocytogenes',
          'Mycobacterium_tuberculosis',
          'Streptococcus_agalactiae',
          "Other_bacteria")

name.2<-c('Escherichia coli',
          'Klebsiella pneumoniae',
          'Staphylococcus aureus',
          'Enterococcus faecium',
          
          'Acinetobacter baumannii',
          'Pseudomonas aeruginosa',
          'Salmonella enterica',
          'Clostridioides difficile',
          'Streptococcus pneumoniae',
          'Listeria monocytogenes',
          'Mycobacterium tuberculosis',
          'Streptococcus agalactiae',
          "Other bacteria")

name.3<-c('Total bacterim',
          'Escherichia coli',
          'Klebsiella pneumoniae',
          'Staphylococcus aureus',
          'Enterococcus faecium',
          
          'Acinetobacter baumannii',
          'Pseudomonas aeruginosa',
          'Salmonella enterica',
          'Clostridioides difficile',
          'Streptococcus pneumoniae',
          'Listeria monocytogenes',
          'Mycobacterium tuberculosis',
          'Streptococcus agalactiae',
          "Other bacteria")
name.4<-c('Total_bacterim',
          'Escherichia_coli',
          'Klebsiella_pneumoniae',
          'Staphylococcus_aureus',
          'Enterococcus_faecium',
          
          'Acinetobacter_baumannii',
          'Pseudomonas_aeruginosa',
          'Salmonella_enterica',
          'Clostridioides_difficile',
          'Streptococcus_pneumoniae',
          'Listeria_monocytogenes',
          'Mycobacterium_tuberculosis',
          'Streptococcus_agalactiae',
          "Other_bacteria")


writeLines(paste0("paper.data.total.",name.1,"<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='",name.2,"')" ) )


paper.data.total.1<-cbind(paper.data.1[c(1:75,128:140)],paper.data.total)




# names(paper.data.total.1)
# # 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
# df_new_names<-names(paper.data.total.1)
# df_new_names[c(110,112,113)]<-c("Fusidic_acid","Beta_lactam","Other_antibiotic_genes")
# 
# colnames(paper.data.total.1) <- df_new_names
# 
# 
# paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)
# paper.data.total.10$Total.genes<- rowSums(paper.data.total.10[, 90:111], na.rm = TRUE)
# 
# 
# 
# 
# 
# paper.data.total.Escherichia_coli<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Escherichia coli')
# paper.data.total.Klebsiella_pneumoniae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Klebsiella pneumoniae')
# paper.data.total.Staphylococcus_aureus<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Staphylococcus aureus')
# paper.data.total.Enterococcus_faecium<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Enterococcus faecium')
# paper.data.total.Acinetobacter_baumannii<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Acinetobacter baumannii')
# paper.data.total.Pseudomonas_aeruginosa<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Pseudomonas aeruginosa')
# paper.data.total.Salmonella_enterica<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Salmonella enterica')
# paper.data.total.Clostridioides_difficile<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Clostridioides difficile')
# paper.data.total.Streptococcus_pneumoniae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Streptococcus pneumoniae')
# paper.data.total.Listeria_monocytogenes<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Listeria monocytogenes')
# paper.data.total.Mycobacterium_tuberculosis<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Mycobacterium tuberculosis')
# paper.data.total.Streptococcus_agalactiae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Streptococcus agalactiae')
# paper.data.total.Other_bacteria<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Other bacteria')
# 
# writeLines(paste0("paper.data.total.",name.1,","))
# 
# list<-list(paper.data.total.10,
#            paper.data.total.Escherichia_coli,
#            paper.data.total.Klebsiella_pneumoniae,
#            paper.data.total.Staphylococcus_aureus,
#            paper.data.total.Enterococcus_faecium,
#            paper.data.total.Acinetobacter_baumannii,
#            paper.data.total.Pseudomonas_aeruginosa,
#            paper.data.total.Salmonella_enterica,
#            paper.data.total.Clostridioides_difficile,
#            paper.data.total.Streptococcus_pneumoniae,
#            paper.data.total.Listeria_monocytogenes,
#            paper.data.total.Mycobacterium_tuberculosis,
#            paper.data.total.Streptococcus_agalactiae,
#            paper.data.total.Other_bacteria)
# 
# 
# ######2.1OR####
# 
# 
# final.or<-data.frame() 
# 
# for (i in 1:length(list)) {
#   fit_df.1<-data.frame()
#   for (j in 1:length(dependent_variables)) {
#     
#     model <- glm(as.formula(paste(dependent_variables[j]," ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp")) ,
#                  family = binomial(link = "logit"), 
#                  data=list[[i]])
#   fit_df<-tidy(model)%>%
#     mutate(OR=exp(estimate),
#            P=formatC(p.value, digits = 3, format = "f"),
#            Lower=exp(estimate-1.96*std.error),
#            Upper=exp(estimate+1.96*std.error),
#            label=ifelse(p.value <0.001,'<0.001',P),
#            Group=name.3[i]) %>%
#     mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
#                       " (", formatC(Lower, digits = 2, format = "f"), ",",
#                       formatC(Upper, digits = 2, format = "f"), ")"))
#   # fit_df<-tidy(model)%>%
#   #   mutate(OR=estimate,
#   #          P=formatC(p.value, digits = 3, format = "f"),
#   #          Lower=estimate-1.96*std.error,
#   #          Upper=estimate+1.96*std.error,
#   #          label=ifelse(p.value <0.001,'<0.001',P),
#   #          Group=name.3[i]) %>%
#   #   mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
#   #                     " (", formatC(Lower, digits = 2, format = "f"), ",",
#   #                     formatC(Upper, digits = 2, format = "f"), ")"))
#   
#   
#   
#   fit_df<-fit_df[9,]
#   
#   fit_df.1<-rbind(fit_df.1,fit_df)
#   }
#    fit_df.1 <- fit_df.1[fit_df.1$Lower != 0, ]
#   final.or.total<-c("average_pm25",as.numeric(mean(fit_df.1$estimate)),as.numeric(mean(fit_df.1$std.error)),NA,NA,as.numeric(mean(fit_df.1$OR)),NA,as.numeric(mean(fit_df.1$Lower)),as.numeric(mean(fit_df.1$Upper)),"<0.001",name.3[i],NA)
#   final.or<-rbind(final.or,final.or.total)
# }
# names(final.or)<-names(fit_df)
######2.2数量####
paper.data.total.1<-cbind(paper.data.1[c(1:75,128:140)],paper.data.total)




names(paper.data.total.1)
# # 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(110,112,113)]<-c("Fusidic_acid","Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names


paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)
paper.data.total.10$Total.genes<- rowSums(paper.data.total.10[, 90:111], na.rm = TRUE)

rev(names(sort(table(paper.data.total.10$`Scientific Name`))))

paper.data.total.Escherichia_coli<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Escherichia coli')
paper.data.total.Klebsiella_pneumoniae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Klebsiella pneumoniae')
paper.data.total.Staphylococcus_aureus<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Staphylococcus aureus')
paper.data.total.Enterococcus_faecium<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Enterococcus faecium')
paper.data.total.Acinetobacter_baumannii<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Acinetobacter baumannii')
paper.data.total.Pseudomonas_aeruginosa<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Pseudomonas aeruginosa')
paper.data.total.Salmonella_enterica<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Salmonella enterica')
paper.data.total.Clostridioides_difficile<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Clostridioides difficile')
paper.data.total.Streptococcus_pneumoniae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Streptococcus pneumoniae')
paper.data.total.Listeria_monocytogenes<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Listeria monocytogenes')
paper.data.total.Mycobacterium_tuberculosis<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Mycobacterium tuberculosis')
paper.data.total.Streptococcus_agalactiae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Streptococcus agalactiae')
paper.data.total.Other_bacteria<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Other bacteria')

writeLines(paste0("paper.data.total.",name.1,","))

list<-list(paper.data.total.10,
           paper.data.total.Escherichia_coli,
           paper.data.total.Klebsiella_pneumoniae,
           paper.data.total.Staphylococcus_aureus,
           paper.data.total.Enterococcus_faecium,
           paper.data.total.Acinetobacter_baumannii,
           paper.data.total.Pseudomonas_aeruginosa,
           paper.data.total.Salmonella_enterica,
           paper.data.total.Clostridioides_difficile,
           paper.data.total.Streptococcus_pneumoniae,
           paper.data.total.Listeria_monocytogenes,
           paper.data.total.Mycobacterium_tuberculosis,
           paper.data.total.Streptococcus_agalactiae,
           paper.data.total.Other_bacteria)









final.number<-data.frame() 
for (i in 1:length(list)) {
  
  model <- glm(as.formula(paste("Total.genes"," ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp")) ,
               # family = binomial(link = "logit"), 
               data=list[[i]])
  # fit_df<-tidy(model)%>%
  #   mutate(OR=exp(estimate),
  #          P=formatC(p.value, digits = 3, format = "f"),
  #          Lower=exp(estimate-1.96*std.error),
  #          Upper=exp(estimate+1.96*std.error),
  #          label=ifelse(p.value <0.001,'<0.001',P),
  #          Group=Group[i]) %>%
  #   mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
  #                     " (", formatC(Lower, digits = 2, format = "f"), ",",
  #                     formatC(Upper, digits = 2, format = "f"), ")"))
  fit_df<-tidy(model)%>%
    mutate(OR=estimate,
           P=formatC(p.value, digits = 3, format = "f"),
           Lower=estimate-1.96*std.error,
           Upper=estimate+1.96*std.error,
           label=ifelse(p.value <0.001,'<0.001',P),
           Group=name.3[i]) %>%
    mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
                      " (", formatC(Lower, digits = 2, format = "f"), ",",
                      formatC(Upper, digits = 2, format = "f"), ")"))
  
  
  
  fit_df<-fit_df[9,]
  
  final.number<-rbind(final.number,fit_df)
}

final.number
final.number <- final.number %>%
  arrange(OR) 
# %>% # 按照OR值排序，如果需要降序排列可以使用 arrange(desc(OR))
#   mutate(Group_sorted = factor(Group, levels = unique(Group)))
final.number$x<-1:14

ggplot(data = final.number)+
  # scale_color_manual(values = color1)+
  geom_hline(aes(yintercept = 0),linetype="dashed",linewidth=0.3,color="black")+
  
  geom_vline(aes(xintercept = 15),linetype="solid",linewidth=0.5,color="black")+
  # geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.5,color="black")+
  geom_point(aes(x =x, y = OR),size=1.5,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
             #,shape=forest$Shape
  )+
  geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.4,width=0,position = position_dodge(width = 0.6),alpha=1)+
  
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    # axis.line.y = element_blank() 
    axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(limits = c(-2,5),breaks = seq(-0.5,3,0.5))+ 
  scale_x_continuous(limits = c(1,16))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  geom_text(data=final.number,aes(x=x,y=3,label=CI),size=4,hjust=0,color='#ec7784')+
  geom_text(data=final.number,aes(x=x,y=-1.85,label=Group),size=4,hjust=0,color='#41c0d2')+
  geom_text(data=final.number,aes(x=x,y=4.5,label=label),size=4,hjust=0,color='#9F5D92')+
  # geom_text(data=fit_summary_df_selected,aes(x=x,y=y3,label=P_interaction),size=4,hjust=0.5)+
  
  annotate("text", x = 16, y = 0.5, label = "Increased antibiotic genes per isolate, 95% CI",fontface = "bold",color='#ec7784', size = 4, hjust = 0)+
  annotate("text", x = 16, y = -2, label = "Bacteria type",fontface = "bold",color='#41c0d2', size = 4, hjust = 0)+
  annotate("text", x = 16, y =4.5, label = "P -values",fontface = "bold",color='#9F5D92', size = 4, hjust = 0)
# annotate("text", x = 0, y = 4.3, label = "P for interaction",fontface = "bold", size = 4, hjust = 0.5)+
# annotate("text", x = -1.1, y = -1.2, label =c("No breastfed","Maternal smoking","Low birth weight")[j],fontface = "bold", size = 5, hjust = 0)+

# geom_segment(aes(y = 0.05, yend = 0.3, x = 15.5, xend = 15.5),
#              arrow = arrow(length = unit(0.2, "cm")), # 设置箭头属性
#              linewidth = 0.5, color = "black")+
# geom_segment(aes(y = -0.05, yend = -0.3, x = 15.5, xend = 15.5),
#              arrow = arrow(length = unit(0.2, "cm")), # 设置箭头属性
#              linewidth = 0.5, color = "black")+
# annotate("text", x = 16, y = 0, label = "Reduced risk        Increaced risk",fontface = "plain", size = 3, hjust = 0.5)

ggsave( last_plot(),
        width = 10,height =8,
        filename =  paste0("图片/number_bacteria.pdf"))









#####3.分各层分析####



names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$Total.genes<-rowSums(paper.data.total.1[98:118])

paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)


# ggplot(data =paper.data.total.1, aes(x = average_tmp)) +
#   geom_density() +
#   labs(title = "概率密度图示例", x = "数值", y = "密度")


rev(names(sort(table(paper.data.total.10$`Scientific Name`))))

paper.data.total.Escherichia_coli<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Escherichia coli')
paper.data.total.Staphylococcus_aureus<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Staphylococcus aureus')
paper.data.total.Klebsiella_pneumoniae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Klebsiella pneumoniae')
paper.data.total.Salmonella_enterica<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Salmonella enterica')
paper.data.total.Acinetobacter_baumannii<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Acinetobacter baumannii')
paper.data.total.Enterococcus_faecium<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Enterococcus faecium')
paper.data.total.Pseudomonas_aeruginosa<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Pseudomonas aeruginosa')
paper.data.total.Streptococcus_pneumoniae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Streptococcus pneumoniae')
paper.data.total.Listeria_monocytogenes<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Listeria monocytogenes')
paper.data.total.Clostridioides_difficile<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Clostridioides difficile')
paper.data.total.Mycobacterium_tuberculosis<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Mycobacterium tuberculosis')
paper.data.total.Streptococcus_agalactiae<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Streptococcus agalactiae')
paper.data.total.Other_bacteria<-subset(paper.data.total.10,paper.data.total.10$`Scientific Name`=='Other bacteria')


# paper.data.total.10$`Isolation type` <- ifelse(is.na(paper.data.total.10$`Isolation type`), "Not recorded", 
#                                               ifelse(paper.data.total.10$`Isolation type`=="clinical", "Clinical",
#                                                      ifelse(paper.data.total.10$`Isolation type`=="environmental/other", "Environmental/Other",paper.data.total.10$`Isolation type`)))

paper.data.total.10$`Isolation type` <- 
  ifelse(is.na(paper.data.total.10$`Isolation type`), "Environmental/Other", 
         ifelse(paper.data.total.10$`Isolation type`=="clinical", "Clinical",
                # ifelse(paper.data.total.10$`Isolation type`=="environmental/other", 
                "Environmental/Other"
                # ,paper.data.total.10$`Isolation type`) 
         ) ) 


sort(table(paper.data.total.10$`Isolation type`))
paper.data.total.Clinical<-subset(paper.data.total.10,paper.data.total.10$`Isolation type`=="Clinical")
paper.data.total.Environmental_Other<-subset(paper.data.total.10,paper.data.total.10$`Isolation type`=='Environmental/Other')
# paper.data.total.Not_recorded<-subset(paper.data.total.10,paper.data.total.10$`Isolation type`!='Environmental/Other'&paper.data.total.10$`Isolation type`!='Clinical')

paper.data.total.2000_2007<-subset(paper.data.total.10,paper.data.total.10$year<=2007)
paper.data.total.2008_2014<-subset(paper.data.total.10,paper.data.total.10$year>2007&paper.data.total.10$year<=2014)
paper.data.total.2015_2022<-subset(paper.data.total.10,paper.data.total.10$year>2014)



a<-c("1/3","2/3")
names(paper.data.total.1)
variable<-c("average_tmp",
            "average_pre",
            "average_NDVI",
            "GDP_per_capita",
            "Population_density",
            "Current_health_expenditure_per_capita",
            "Mortality_rate_of_infant",
            "People_using_at_least_basic_drinking_water_services",
            "Population_ages_65_and_above")
writeLines(paste0("rep('",variable,"',2),"))
variable<-c(rep('average_tmp',2),
            rep('average_pre',2),
            rep('average_NDVI',2),
            rep('GDP_per_capita',2),
            rep('Population_density',2),
            rep('Current_health_expenditure_per_capita',2),
            rep('Mortality_rate_of_infant',2),
            rep('People_using_at_least_basic_drinking_water_services',2),
            rep('Population_ages_65_and_above',2))

Tertiles<-data.frame(names=paste0(variable,a),value=NA)
Tertiles[1,2]
writeLines(paste0("Tertiles[",1:18,",2]=quantile(paper.data.total.1$",variable,", probs =",a,",na.rm=T)"))
{Tertiles[1,2]=quantile(paper.data.total.1$average_tmp, probs =1/3,na.rm=T)
  Tertiles[2,2]=quantile(paper.data.total.1$average_tmp, probs =2/3,na.rm=T)
  Tertiles[3,2]=quantile(paper.data.total.1$average_pre, probs =1/3,na.rm=T)
  Tertiles[4,2]=quantile(paper.data.total.1$average_pre, probs =2/3,na.rm=T)
  Tertiles[5,2]=quantile(paper.data.total.1$average_NDVI, probs =1/3,na.rm=T)
  Tertiles[6,2]=quantile(paper.data.total.1$average_NDVI, probs =2/3,na.rm=T)
  Tertiles[7,2]=quantile(paper.data.total.1$GDP_per_capita, probs =1/3,na.rm=T)
  Tertiles[8,2]=quantile(paper.data.total.1$GDP_per_capita, probs =2/3,na.rm=T)
  Tertiles[9,2]=quantile(paper.data.total.1$Population_density, probs =1/3,na.rm=T)
  Tertiles[10,2]=quantile(paper.data.total.1$Population_density, probs =2/3,na.rm=T)
  Tertiles[11,2]=quantile(paper.data.total.1$Current_health_expenditure_per_capita, probs =1/3,na.rm=T)
  Tertiles[12,2]=quantile(paper.data.total.1$Current_health_expenditure_per_capita, probs =2/3,na.rm=T)
  Tertiles[13,2]=quantile(paper.data.total.1$Mortality_rate_of_infant, probs =1/3,na.rm=T)
  Tertiles[14,2]=quantile(paper.data.total.1$Mortality_rate_of_infant, probs =2/3,na.rm=T)
  Tertiles[15,2]=quantile(paper.data.total.1$People_using_at_least_basic_drinking_water_services, probs =1/3,na.rm=T)
  Tertiles[16,2]=quantile(paper.data.total.1$People_using_at_least_basic_drinking_water_services, probs =2/3,na.rm=T)
  Tertiles[17,2]=quantile(paper.data.total.1$Population_ages_65_and_above, probs =1/3,na.rm=T)
  Tertiles[18,2]=quantile(paper.data.total.1$Population_ages_65_and_above, probs =2/3,na.rm=T)
  Tertiles$value=formatC(Tertiles$value, digits = 2, format = "f")
}




writeLines(paste0(Tertiles$names,"=subset(paper.data.total.10,paper.data.total.10$",variable,"=",Tertiles$value,")"))

average_tmp13=subset(paper.data.total.10,paper.data.total.10$average_tmp<=11.87)
average_tmp23=subset(paper.data.total.10,paper.data.total.10$average_tmp>11.87&paper.data.total.10$average_tmp<=17.19)
average_tmp33=subset(paper.data.total.10,paper.data.total.10$average_tmp>17.19)

average_pre13=subset(paper.data.total.10,paper.data.total.10$average_pre<=64.49)
average_pre23=subset(paper.data.total.10,paper.data.total.10$average_pre>64.49&paper.data.total.10$average_pre<=101.72)
average_pre33=subset(paper.data.total.10,paper.data.total.10$average_pre>101.72)

average_NDVI13=subset(paper.data.total.10,paper.data.total.10$average_NDVI<=4524.79)
average_NDVI23=subset(paper.data.total.10,paper.data.total.10$average_NDVI>4524.79&paper.data.total.10$average_NDVI<=5646.56)
average_NDVI33=subset(paper.data.total.10,paper.data.total.10$average_NDVI>5646.56)

GDP_per_capita13=subset(paper.data.total.10,paper.data.total.10$GDP_per_capita<=11938.75)
GDP_per_capita23=subset(paper.data.total.10,paper.data.total.10$GDP_per_capita>11938.75&paper.data.total.10$GDP_per_capita<=54213.46)
GDP_per_capita33=subset(paper.data.total.10,paper.data.total.10$GDP_per_capita>54213.46)

Population_density13=subset(paper.data.total.10,paper.data.total.10$Population_density<=35.89)
Population_density23=subset(paper.data.total.10,paper.data.total.10$Population_density>35.89&paper.data.total.10$Population_density<=149.95)
Population_density33=subset(paper.data.total.10,paper.data.total.10$Population_density>149.95)

Current_health_expenditure_per_capita13=subset(paper.data.total.10,paper.data.total.10$Current_health_expenditure_per_capita<=856.70)
Current_health_expenditure_per_capita23=subset(paper.data.total.10,paper.data.total.10$Current_health_expenditure_per_capita>856.70&paper.data.total.10$Current_health_expenditure_per_capita<=5555.37)
Current_health_expenditure_per_capita33=subset(paper.data.total.10,paper.data.total.10$Current_health_expenditure_per_capita>5555.37)

Mortality_rate_of_infant13=subset(paper.data.total.10,paper.data.total.10$Mortality_rate_of_infant<=4.10)
Mortality_rate_of_infant23=subset(paper.data.total.10,paper.data.total.10$Mortality_rate_of_infant>4.10&paper.data.total.10$Mortality_rate_of_infant<=6.00)
Mortality_rate_of_infant33=subset(paper.data.total.10,paper.data.total.10$Mortality_rate_of_infan>6.00)

People_using_at_least_basic_drinking_water_services13=subset(paper.data.total.10,paper.data.total.10$People_using_at_least_basic_drinking_water_services<=98.76)
People_using_at_least_basic_drinking_water_services23=subset(paper.data.total.10,paper.data.total.10$People_using_at_least_basic_drinking_water_services>98.91&paper.data.total.10$People_using_at_least_basic_drinking_water_services<=99.82)
People_using_at_least_basic_drinking_water_services33=subset(paper.data.total.10,paper.data.total.10$People_using_at_least_basic_drinking_water_services>99.82)

Population_ages_65_and_above13=subset(paper.data.total.10,paper.data.total.10$Population_ages_65_and_above<=12.51)
Population_ages_65_and_above23=subset(paper.data.total.10,paper.data.total.10$Population_ages_65_and_above>12.51&paper.data.total.10$Population_ages_65_and_above<=16.16)
Population_ages_65_and_above33=subset(paper.data.total.10,paper.data.total.10$Population_ages_65_and_above>16.16)





writeLines(paste0(Tertiles$names,","))

list<-list(paper.data.total.10,
           paper.data.total.Escherichia_coli,
           paper.data.total.Staphylococcus_aureus,
           paper.data.total.Klebsiella_pneumoniae,
           paper.data.total.Salmonella_enterica,
           paper.data.total.Acinetobacter_baumannii,
           paper.data.total.Enterococcus_faecium,
           paper.data.total.Pseudomonas_aeruginosa,
           paper.data.total.Streptococcus_pneumoniae,
           paper.data.total.Listeria_monocytogenes,
           paper.data.total.Clostridioides_difficile,
           paper.data.total.Mycobacterium_tuberculosis,
           paper.data.total.Streptococcus_agalactiae,
           paper.data.total.Other_bacteria,
           
           
           paper.data.total.Clinical,
           paper.data.total.Environmental_Other,
           paper.data.total.Not_recorded,
           # paper.data.total.2000_2007,
           # paper.data.total.2008_2014,
           # paper.data.total.2015_2022,
           
           average_tmp13,
           average_tmp23,
           average_tmp33,
           
           average_pre13,
           average_pre23,
           average_pre33,
           
           average_NDVI13,
           average_NDVI23,
           average_NDVI33,
           
           
           GDP_per_capita13,
           GDP_per_capita23,
           GDP_per_capita33,
           
           Population_density13,
           Population_density23,
           Population_density33,
           
           Current_health_expenditure_per_capita13,
           Current_health_expenditure_per_capita23,
           Current_health_expenditure_per_capita33,
           
           Mortality_rate_of_infant13,
           Mortality_rate_of_infant23,
           Mortality_rate_of_infant33,
           
           People_using_at_least_basic_drinking_water_services13,
           People_using_at_least_basic_drinking_water_services23,
           People_using_at_least_basic_drinking_water_services33,
           
           Population_ages_65_and_above13,
           Population_ages_65_and_above23,
           Population_ages_65_and_above33)


writeLines(paste0("'",
                  rev(names(sort(table(paper.data.total.10$`Scientific Name`)))),"',"
)
)


b=c("1st: ≤","2st: >")
writeLines(paste0("'",b,Tertiles$value,"',"))

Group<-c("Overall",
         'Escherichia coli',
         'Staphylococcus aureus',
         'Klebsiella pneumoniae',
         'Salmonella enterica',
         'Acinetobacter baumannii',
         'Enterococcus faecium',
         'Pseudomonas aeruginosa',
         'Streptococcus pneumoniae',
         'Listeria monocytogenes',
         'Clostridioides difficile',
         'Mycobacterium tuberculosis',
         'Streptococcus agalactiae',
         'Other bacteria',
         
         "Clinical",
         'Environmental/Other',
         "Not recorded",
         
         # "2000-2007",
         # "2008-2014",
         # "2015-2022",
         
         '1st: <11.87',
         '2st: 11.87-16.95',
         '3st: >16.95',
         
         '1st: <64.49',
         '2st: 64.49-101.72',
         '3st: >101.72',
         
         '1st: <0.45',
         '2st: 0.45-0.56',
         '3st: >0.56',
         
         '1st: <11938.75',
         '2st: 11938.75-54213.46',
         '3st: >54213.46',
         
         '1st: <35.89',
         '2st: 35.89-149.95',
         '3st: >149.95',
         
         '1st: <856.70',
         '2st: 856.70-5555.37',
         '3st: >5555.37',
         
         '1st: <4.10',
         '2st: 4.10-6.00',
         '3st: >6.00',
         
         '1st: <98.76',
         '2st: 98.76-99.82',
         '3st: >99.82',
         
         '1st: <12.51',
         '2st: 12.51-16.16',
         '3st: >16.16'
)


formula<-c(" ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           
           # " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           # " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           # " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_NDVI",
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+ average_pm25+average_tmp+average_NDVI",
           
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp",
           
           
           
           
           " ~Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           " ~GDP_per_capita+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           " ~GDP_per_capita+ Population_density+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+average_pre+ average_pm25+average_tmp+average_NDVI",
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI"
           
)

final.number.type<-data.frame() 
for (i in 1:length(list)) {
  Number<-nrow(list[[i]])
  Number_genes=sum(list[[i]]$Total.genes)
  # model <- glm(as.formula(paste("Total.genes"," ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp")) ,
  #              # family = binomial(link = "logit"), 
  #              data=list[[i]])
  model <- glm.nb(as.formula(paste("Total.genes",formula[i])) ,
                  
                  data=list[[i]])
  # fit_df<-tidy(model)%>%
  #   mutate(OR=exp(estimate),
  #          P=formatC(p.value, digits = 3, format = "f"),
  #          Lower=exp(estimate-1.96*std.error),
  #          Upper=exp(estimate+1.96*std.error),
  #          label=ifelse(p.value <0.001,'<0.001',P),
  #          Group=Group[i]) %>%
  #   mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
  #                     " (", formatC(Lower, digits = 2, format = "f"), ",",
  #                     formatC(Upper, digits = 2, format = "f"), ")"))
  fit_df<-tidy(model)%>%
    mutate(OR=(exp(estimate)-1)*100,
           P=formatC(p.value, digits = 3, format = "f"),
           Lower=(exp(estimate-1.96*std.error)-1)*100,
           Upper=(exp(estimate+1.96*std.error)-1)*100,
           label=ifelse(p.value <0.001,'<0.001',P),
           Group=Group[i],
           Number=Number,
           Number_genes=Number_genes) %>%
    mutate(CI = paste(formatC(OR, digits = 1, format = "f"),
                      " (", formatC(Lower, digits = 1, format = "f"), ",",
                      formatC(Upper, digits = 1, format = "f"), ")"))
  
  
  fit_df<-subset(fit_df,fit_df$term=="average_pm25")
  
  final.number.type<-rbind(final.number.type,fit_df)
  print(i)
}
new_row <- rep(NA, ncol(final.number.type)) 
final.number.type <- rbind(final.number.type[1, ], 
                           new_row, 
                           final.number.type[2:14, ],
                           new_row, 
                           final.number.type[15:17, ],
                           new_row, 
                           final.number.type[18:20, ],
                           new_row, 
                           final.number.type[21:23, ],
                           new_row,
                           final.number.type[24:26, ],
                           new_row,
                           final.number.type[27:29, ],
                           new_row,
                           final.number.type[30:32, ],
                           new_row,
                           final.number.type[33:35, ],
                           new_row,
                           final.number.type[36:38, ],
                           new_row,
                           final.number.type[39:41, ],
                           new_row,
                           final.number.type[42:44, ]
)

{
  final.number.type[2,11]<-"Bacterial species"
  final.number.type[16,11]<-"Isolation type"
  final.number.type[20,11]<-"Temperature (℃) "
  final.number.type[24,11]<-"Precipitation (mm)"
  final.number.type[28,11]<-"NDVI"
  final.number.type[32,11]<-"GDP per capita (US$)"
  final.number.type[36,11]<-"Population density (per km²)"
  final.number.type[40,11]<-"CHE per capita (US$)"
  final.number.type[44,11]<-"Mortality rate of infant (‰)"
  final.number.type[48,11]<-"People using at least BDWS (%)"
  final.number.type[52,11]<-"Population ages 65 and above (%)"
}
final.number.type$P_interaction<-NA


{
  for (i in  c(4,18,22,26,30,34,38,42,46,50,54)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-1]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-1]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(5,19,23,27,31,35,39,43,47,51,55)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-2]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-2]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(6)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-3]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-3]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(7)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-4]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-4]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  
  for (i in  c(8)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-5]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-5]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(9)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-6]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-6]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(10)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-7]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-7]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(11)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-8]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-8]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(12)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-9]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-9]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(13)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-10]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-10]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(14)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-11]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-11]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
  for (i in  c(15)) {
    final.number.type$P_interaction[i]  <-pnorm(
      abs(final.number.type$estimate[i-12]-final.number.type$estimate[i])/
        (final.number.type$std.error[i-12]^2+final.number.type$std.error[i]^2)^0.5, lower.tail = FALSE)
  } 
}

final.number.type<-final.number.type%>%
  mutate(
    x=c(1:55),
    y= 3,
    y1=c(-1.1,
         -1.1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1,
         -1.1,-1,-1,-1
         
    )-1.3, 
    y2=3.5,
    y3 = 4.3,
    fontface=c("bold",
               "bold","plain","plain","plain","plain","plain","plain","plain","plain","plain","plain","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain",
               "bold","plain","plain","plain"),
    term=factor(Group, 
                levels = c(
                  final.number.type$Group)),
    P_interaction=ifelse(is.na(P_interaction),NA,
                         ifelse(P_interaction <0.001,'<0.001',formatC(P_interaction, digits = 3, format = "f"))),
  )
final.number.type$P_interaction[c(3,17,21,25,29,33,37,41,45,49,53)]<-"Ref."
final.number.type$P_interaction[1]<-"-"
ggplot(data = final.number.type)+
  
  # geom_hline(aes(yintercept = 0),linetype="dashed",linewidth=0.3,color="black")+
  geom_vline(aes(xintercept = -2),linetype="solid",linewidth=0.7,color="black")+
  geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.7,color="black")+
  geom_vline(aes(xintercept = 56),linetype="solid",linewidth=0.7,color="black")+
  # geom_point(aes(x =x, y = OR),size=1.5,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
  #            #,shape=forest$Shape
  # )+
  # geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.4,width=0,position = position_dodge(width = 0.6),alpha=1)+
  # 
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    axis.text.x = element_blank(),   # 隐藏x轴标签
    axis.ticks.x = element_blank(), # 隐藏x轴刻度线
    # axis.line.y = element_blank() 
    # axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(limits = c(-2.6,8.5),breaks = seq(-0.5,3,0.5))+ 
  # scale_x_continuous(limits = c(1,51))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  
  geom_text(data=final.number.type,aes(x=x,y=y1,label=Group,fontface =fontface),size=4,hjust=0,color='black')+
  geom_text(data=final.number.type,aes(x=x,y=0.8,label = ifelse(is.na(Number), "", prettyNum(Number, big.mark = ","))),size=4,hjust=1,color='black')+
  geom_text(data=final.number.type,aes(x=x,y=2.5,label = ifelse(is.na(Number_genes), "", prettyNum(Number_genes, big.mark = ","))),size=4,hjust=1,color='black')+
  geom_text(data=final.number.type,aes(x=x,y=4.4,label=CI),size=4,hjust=0.5,color='black')+
  geom_text(data=final.number.type,aes(x=x,y=6.5,label=label),size=4,hjust=0,color='black')+
  geom_text(data=final.number.type,aes(x=x,y=8.5,label=P_interaction),size=4,hjust=1)+
  scale_x_continuous(trans = "reverse")+
  annotate("text", x = -1, y = -2.5, label = "Group",fontface = "bold",color='black', size = 4.5, hjust = 0)+
  annotate("text", x = -1, y = 0.8, label = "Number of isolates",fontface = "bold",color='black', size = 4.5, hjust = 1)+
  annotate("text", x = -1, y = 2.5, label = "Number of genes",fontface = "bold",color='black', size = 4.5, hjust = 1)+
  annotate("text", x = -1, y = 4.4, label = "PC of resistance genes per isolate, 95% CI",fontface = "bold",color='black', size = 4, hjust = 0.5)+
  
  annotate("text", x = -1, y =6.4, label = "P -values",fontface = "bold",color='black', size = 4.5, hjust = 0)+
  annotate("text", x = -1, y = 8.2, label = "P for difference",fontface = "bold", size = 4.5, hjust = 0.5)
# annotate("text", x = -1.1, y = -1.2, label =c("No breastfed","Maternal smoking","Low birth weight")[j],fontface = "bold", size = 5, hjust = 0)+

# geom_segment(aes(y = 0.05, yend = 0.3, x = 15.5, xend = 15.5),
#              arrow = arrow(length = unit(0.2, "cm")), # 设置箭头属性
#              linewidth = 0.5, color = "black")+
# geom_segment(aes(y = -0.05, yend = -0.3, x = 15.5, xend = 15.5),
#              arrow = arrow(length = unit(0.2, "cm")), # 设置箭头属性
#              linewidth = 0.5, color = "black")+
# annotate("text", x = 16, y = 0, label = "Reduced risk        Increaced risk",fontface = "plain", size = 3, hjust = 0.5)

ggsave( last_plot(),
        width = 12,height =15,
        filename =  paste0("图片/Stratified Analysis.pdf"))
write.table(final.number.type,"Stratified Analysis.csv",row.names=FALSE,col.names=TRUE,sep=",")

#####4.敏感性分析####
formula<-c(" ~average_pm25",
           " ~average_pm25+average_tmp",
           " ~average_pre+ average_pm25+average_tmp",
           " ~average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ +average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+average_pre+ average_pm25+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25+average_tmp+average_NDVI")
Group<-c("PM2.5 only"
         ,"+ Temperature"
         ,"+ Precipitation"
         ,"+ NDVI"
         ,"+ GDP per capita"
         ,"+ Population density"
         ,"+ CHE per capita"
         ,"+ Mortality rate of infant"
         ,"+ People using at least BDWS"
         ,"+ Population ages 65 and above"
)


final.number.sensitive<-data.frame() 
for (i in 1:length(formula)) {
  
  model <- glm.nb(as.formula(paste("Total.genes",formula[i])) ,
                  # family = binomial(link = "logit"), 
                  data=paper.data.total.10)
  
  
  
  
  fit_df<-tidy(model)%>%
    mutate(OR=(exp(estimate)-1)*100,
           P=formatC(p.value, digits = 3, format = "f"),
           Lower=(exp(estimate-1.96*std.error)-1)*100,
           Upper=(exp(estimate+1.96*std.error)-1)*100,
           label=ifelse(p.value <0.001,'<0.001',P),
           Group=Group[i],
           Number=Number,
           Number_genes=Number_genes) %>%
    mutate(CI = paste(formatC(OR, digits = 1, format = "f"),
                      " (", formatC(Lower, digits = 1, format = "f"), ",",
                      formatC(Upper, digits = 1, format = "f"), ")"))
  
  
  
  print(i)
  fit_df<-subset(fit_df,fit_df$term=="average_pm25")
  
  final.number.sensitive<-rbind(final.number.sensitive,fit_df)
}

final.number.sensitive<-final.number.sensitive%>%
  mutate(
    x=rev(c(1:10)),
    
    fontface=c("plain",
               
               "plain","plain","plain","plain","plain","plain","plain","plain","plain"),
    term=factor(Group, 
                levels = c(
                  final.number.sensitive$Group))
  )

ggplot(data = final.number.sensitive)+
  # scale_color_manual(values = color1)+
  geom_hline(aes(yintercept = 0),linetype="dashed",linewidth=0.3,color="black")+
  
  geom_vline(aes(xintercept = 10.5),linetype="solid",linewidth=0.5,color="black")+
  # geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.5,color="black")+
  geom_point(aes(x =x, y = OR),size=2,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
             #,shape=forest$Shape
  )+
  geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.6,width=0,position = position_dodge(width = 0.6),alpha=1)+
  
  
  # geom_point(aes(x =24, y = 5.5),size=1.5,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
  #            #,shape=forest$Shape
  # )+
  # geom_errorbar(aes(x = 24,ymin = 4.83, ymax = 6.14),color='#ec7784',size=0.2,width=0,position = position_dodge(width = 0.6),alpha=1)+
  # 
  
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    axis.text.x = element_text(size = 14,face="bold"),
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    # axis.line.y = element_blank() 
    axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(limits = c(-18,30),breaks = seq(0,16,2))+ 
  scale_x_continuous(limits = c(1,11))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  geom_text(data=final.number.sensitive,aes(x=x,y=20,label=CI),size=5,hjust=0.5,color='#ec7784')+
  geom_text(data=final.number.sensitive,aes(x=x,y=-16,label=Group),size=5,hjust=0,color='black')+
  geom_text(data=final.number.sensitive,aes(x=x,y=28,label=label),size=5,hjust=0.5,color='black')+
  
  # geom_text(data=fit_summary_df_selected,aes(x=x,y=y3,label=P_interaction),size=4,hjust=0.5)+
  
  annotate("text", x = 11, y = -3, label = "PC of resistance genes per isolate (%), 95% CI",fontface = "bold",color='#ec7784', size = 5, hjust = 0)+
  annotate("text", x = 11, y = -18, label = "Group",fontface = "bold",color='black', size = 5, hjust = 0)+
  annotate("text", x = 11, y =28, label = "P -values",fontface = "bold",color='black', size = 5, hjust = 0.5)

ggsave( last_plot(),
        width = 10,height =8,
        filename =  paste0("图片/sensitive_number.pdf"))


######4.2or值####

Group1<-c( 'Beta-lactam',
           'Aminoglycoside',
           'Quinolone',
           'Fosfomycin',
           'Tetracycline',
           'Efflux',
           'Phenicol',
           'Macrolide',
           'Glycopeptide',
           'Sulfonamide',
           'Trimethoprim',
           'Streptogramin',
           'Lincosamide',
           'Colistin',
           'Streptothricin',
           'Bleomycin',
           'Rifamycin',
           'Fosmidomycin',
           'Fluoroquinolone',
           'Multidrug',
           'Pleuromutilin',
           'Fusidic acid',
           'Mupirocin',
           'Other antibiotic genes')
dependent_variables <-c('Beta_lactam',
                        'Aminoglycoside',
                        'Quinolone',
                        'Fosfomycin',
                        'Tetracycline',
                        'Efflux',
                        'Phenicol',
                        'Macrolide',
                        'Glycopeptide',
                        'Sulfonamide',
                        'Trimethoprim',
                        'Streptogramin',
                        'Lincosamide',
                        'Colistin',
                        'Streptothricin',
                        'Bleomycin',
                        'Rifamycin',
                        'Fosmidomycin',
                        'Fluoroquinolone',
                        'Multidrug',
                        'Pleuromutilin',
                        'Fusidic_acid',
                        'Mupirocin',
                        'Other_antibiotic_genes')

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
for (col in cols_to_process) {
  paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
}
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  



paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25=average_pm25/10)

final.or.sensitive<-data.frame() 
for (j in 1:length(formula)) {
  final.or<-data.frame() 
  for (i in 1:length(dependent_variables)) {
    coef=sum(paper.data.total[Group1[i]])/sum(rowSums(paper.data.total[, 2:25], na.rm = TRUE))
    Number=sum(paper.data.total[Group1[i]])
    model <- glm(as.formula(paste(dependent_variables[i],formula[j])) ,
                 family = binomial(link = "logit"), 
                 data=paper.data.total.10)
    fit_df<-tidy(model)%>%
      mutate(OR=exp(estimate),
             P=formatC(p.value, digits = 3, format = "f"),
             Lower=exp(estimate-1.96*std.error),
             Upper=exp(estimate+1.96*std.error),
             label=ifelse(p.value <0.001,'<0.001',P),
             Group=Group1[i],
             coef=coef,
             Number=Number) %>%
      mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
                        " (", formatC(Lower, digits = 2, format = "f"), ",",
                        formatC(Upper, digits = 2, format = "f"), ")"))
    
    
    
    fit_df<-subset(fit_df,fit_df$term=="average_pm25")
    
    final.or<-rbind(final.or,fit_df)
  }
  
  
  
  final.or25<-c("average_pm25",as.numeric(mean(final.or$estimate)),as.numeric(mean(final.or$std.error)),NA,NA,as.numeric(sum(final.or$OR*final.or$coef)),NA,as.numeric(sum(final.or$Lower*final.or$coef)),as.numeric(sum(final.or$Upper*final.or$coef)),"<0.001","Total",1,sum(rowSums(paper.data.total[, 2:25], na.rm = TRUE)),NA)
  final.or<-rbind(final.or,final.or25)
  
  final.or[25,14]<-paste(formatC(as.numeric(final.or[25,6]), digits = 2, format = "f"),
                         " (", formatC(as.numeric(final.or[25,8]), digits = 2, format = "f"), ",",
                         formatC(as.numeric(final.or[25,9]), digits = 2, format = "f"), ")")
  
  
  
  final.or<-final.or%>%mutate(OR=as.numeric(OR),
                              Lower=as.numeric(Lower),
                              Upper=as.numeric(Upper))
  final.or$Group=Group[j]
  final.or<-final.or[25,]
  final.or.sensitive<-rbind(final.or.sensitive,final.or)
  print(j)
}

final.or.sensitive<-final.or.sensitive%>%
  mutate(
    x=rev(c(1:10)),
    
    fontface=c("plain",
               
               "plain","plain","plain","plain","plain","plain","plain","plain","plain"),
    term=factor(Group, 
                levels = c(
                  final.or.sensitive$Group))
  )


ggplot(data = final.or.sensitive)+
  # scale_color_manual(values = color1)+
  geom_hline(aes(yintercept = 1),linetype="dashed",linewidth=0.3,color="black")+
  
  geom_vline(aes(xintercept = 10.5),linetype="solid",linewidth=0.5,color="black")+
  # geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.5,color="black")+
  geom_point(aes(x =x, y = OR),size=2,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
             #,shape=forest$Shape
  )+
  geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.6,width=0,position = position_dodge(width = 0.6),alpha=1)+
  
  
  # geom_point(aes(x =24, y = 5.5),size=1.5,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
  #            #,shape=forest$Shape
  # )+
  # geom_errorbar(aes(x = 24,ymin = 4.83, ymax = 6.14),color='#ec7784',size=0.2,width=0,position = position_dodge(width = 0.6),alpha=1)+
  # 
  
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    axis.text.x = element_text(size = 14,face="bold"),
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    # axis.line.y = element_blank() 
    axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(limits = c(0.5,1.8),breaks = seq(1.0,1.3,0.1))+ 
  scale_x_continuous(limits = c(1,11))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  geom_text(data=final.or.sensitive,aes(x=x,y=1.5,label=CI),size=5,hjust=0.5,color='#ec7784')+
  geom_text(data=final.or.sensitive,aes(x=x,y=0.55,label=Group),size=5,hjust=0,color='black')+
  geom_text(data=final.or.sensitive,aes(x=x,y=1.75,label=label),size=5,hjust=0.5,color='black')+
  
  # geom_text(data=fit_summary_df_selected,aes(x=x,y=y3,label=P_interaction),size=4,hjust=0.5)+
  
  annotate("text", x = 11, y = 0.9, label = "OR of carrying at least one resistence gene, 95% CI",fontface = "bold",color='#ec7784', size = 5, hjust = 0)+
  annotate("text", x = 11, y = 0.5, label = "Group",fontface = "bold",color='black', size = 5, hjust = 0)+
  annotate("text", x = 11, y =1.75, label = "P -values",fontface = "bold",color='black', size = 5, hjust = 0.5)

ggsave( last_plot(),
        width = 10,height =8,
        filename =  paste0("图片/sensitive_or.pdf"))



#####5.滞后效应####
######5.1number####
names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
# for (col in cols_to_process) {
#   paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
# }
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


paper.data.total.1$Total.genes<-rowSums(paper.data.total.1[98:118])


# PM2_5_match13_24 <- read_csv("PM2.5_match13-24.csv")
# PM2_5_match13_24 <- PM2_5_match13_24 %>% mutate(ID = paste(BioSample, `Scientific name`))
# 
# # table(paper.data.total.1$ID)  # 查看paper.data.total.1中ID的频率  
# # table(PM2_5_match13_24$ID)    # 查看PM2_5_match13_24中ID的频率
# names(PM2_5_match13_24)
# names(paper.data.total.1)
# PM2_5_match13_24 <- PM2_5_match13_24[16:22]
# paper.data.total.1 <- merge(paper.data.total.1, PM2_5_match13_24, by = "ID", all.x = T,all.y = F)

paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25_0=average_pm25_0/10,
                                                 average_pm25_1=average_pm25_1/10,
                                                 average_pm25_2=average_pm25_2/10,
                                                 average_pm25_3=average_pm25_3/10,
                                                 average_pm25_4=average_pm25_4/10,
                                                 average_pm25_5=average_pm25_5/10,
                                                 average_pm25_6=average_pm25_6/10,
                                                 average_pm25_7=average_pm25_7/10,
                                                 average_pm25_8=average_pm25_8/10,
                                                 average_pm25_9=average_pm25_9/10,
                                                 average_pm25_10=average_pm25_10/10,
                                                 average_pm25_11=average_pm25_11/10,
                                                 average_pm25_12=average_pm25_12/10,
                                                 average_pm25_13=average_pm25_13/10,
                                                 average_pm25_14=average_pm25_14/10,
                                                 average_pm25_15=average_pm25_15/10,
                                                 average_pm25_16=average_pm25_16/10,
                                                 average_pm25_17=average_pm25_17/10,
                                                 average_pm25_18=average_pm25_18/10,
                                                 average_pm25_01=(average_pm25_1+average_pm25_0)/2,
                                                 average_pm25_02=(average_pm25_2+average_pm25_1+average_pm25_0)/3,
                                                 average_pm25_03=(average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/4,
                                                 average_pm25_04=(average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/5,
                                                 average_pm25_05=(average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/6,
                                                 average_pm25_06=(average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/7,
                                                 average_pm25_07=(average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/8,
                                                 average_pm25_08=(average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/9,
                                                 average_pm25_09=(average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/10,
                                                 average_pm25_010=(average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/11,
                                                 average_pm25_011=average_pm25/10,
                                                 average_pm25_012=(average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/13,
                                                 average_pm25_013=(average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/14,
                                                 average_pm25_014=(average_pm25_14+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/15,
                                                 average_pm25_015=(average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/16,
                                                 average_pm25_016=(average_pm25_16+average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/17,
                                                 average_pm25_017=(average_pm25_17+average_pm25_16+average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/18,
                                                 average_pm25_018=(average_pm25_18+average_pm25_17+average_pm25_16+average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/19,
)




formula<-c(" ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_0+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_1+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_2+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_3+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_4+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_5+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_6+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_7+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_8+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_9+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_10+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_11+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_12+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_13+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_14+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_15+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_16+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_17+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_18+average_tmp+average_NDVI",
           
           
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_01+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_02+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_03+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_04+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_05+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_06+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_07+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_08+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_09+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_010+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_011+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_012+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_013+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_014+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_015+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_016+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_017+average_tmp+average_NDVI",
           " ~GDP_per_capita+ Population_density+ Mortality_rate_of_infant+Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+ average_pm25_018+average_tmp+average_NDVI")


Group<-c("Lag 0"
         ,"Lag 1"
         ,"Lag 2"
         ,"Lag 3"
         ,"Lag 4"
         ,"Lag 5"
         ,"Lag 6"
         ,"Lag 7"
         ,"Lag 8"
         ,"Lag 9"
         ,"Lag 10"
         ,"Lag 11"
         ,"Lag 12"
         ,"Lag 13"
         ,"Lag 14"
         ,"Lag 15"
         ,"Lag 16"
         ,"Lag 17"
         ,"Lag 18"
         
         
         ,"Lag 0-1"
         ,"Lag 0-2"
         ,"Lag 0-3"
         ,"Lag 0-4"
         ,"Lag 0-5"
         ,"Lag 0-6"
         ,"Lag 0-7"
         ,"Lag 0-8"
         ,"Lag 0-9"
         ,"Lag 0-10"
         ,"Lag 0-11"
         ,"Lag 0-12"
         ,"Lag 0-13"
         ,"Lag 0-14"
         ,"Lag 0-15"
         ,"Lag 0-16"
         ,"Lag 0-17"
         ,"Lag 0-18"
)


final.number.lag<-data.frame() 
for (i in 1:length(formula)) {
  
  model <- glm.nb(as.formula(paste("Total.genes",formula[i])) ,
                  # family = binomial(link = "logit"), 
                  data=paper.data.total.10)
  
  
  
  
  fit_df<-tidy(model)%>%
    mutate(OR=(exp(estimate)-1)*100,
           P=formatC(p.value, digits = 3, format = "f"),
           Lower=(exp(estimate-1.96*std.error)-1)*100,
           Upper=(exp(estimate+1.96*std.error)-1)*100,
           label=ifelse(p.value <0.001,'<0.001',P),
           Group=Group[i],
           Number=Number,
           Number_genes=Number_genes) %>%
    mutate(CI = paste(formatC(OR, digits = 1, format = "f"),
                      " (", formatC(Lower, digits = 1, format = "f"), ",",
                      formatC(Upper, digits = 1, format = "f"), ")"))
  
  
  
  print(i)
  fit_df_subset <- subset(fit_df, grepl("average_pm25", term))
  
  
  final.number.lag<-rbind(final.number.lag,fit_df_subset)
}

final.number.lag<-final.number.lag%>%
  mutate(
    x=rev(c(1:37)),
    
    fontface=c("plain",
               
               "plain","plain","plain","plain","plain","plain","plain","plain","plain","plain",
               "plain","plain","plain","plain","plain","plain","plain","plain","plain","plain",
               "plain","plain","plain","plain","plain","plain","plain","plain","plain","plain",
               "plain","plain","plain","plain","plain","plain"),
    term=factor(Group, 
                levels = c(
                  final.number.lag$Group))
  )






ggplot(data = final.number.lag)+
  # scale_color_manual(values = color1)+
  geom_hline(aes(yintercept = 0),linetype="dashed",linewidth=0.3,color="black")+
  
  geom_vline(aes(xintercept = 38),linetype="solid",linewidth=0.5,color="black")+
  # geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.5,color="black")+
  geom_point(aes(x =x, y = OR),size=2,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
             #,shape=forest$Shape
  )+
  geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.6,width=0,position = position_dodge(width = 0.6),alpha=1)+
  
  
  # geom_point(aes(x =24, y = 5.5),size=1.5,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
  #            #,shape=forest$Shape
  # )+
  # geom_errorbar(aes(x = 24,ymin = 4.83, ymax = 6.14),color='#ec7784',size=0.2,width=0,position = position_dodge(width = 0.6),alpha=1)+
  # 
  
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    axis.text.x = element_text(size = 14,face="bold"),
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    # axis.line.y = element_blank() 
    axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(limits = c(-10,30),breaks = seq(0,16,2))+ 
  scale_x_continuous(limits = c(1,39),expand = c(0.02, 0.02))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  geom_text(data=final.number.lag,aes(x=x,y=20,label=CI),size=5,hjust=0.5,color='#ec7784')+
  geom_text(data=final.number.lag,aes(x=x,y=-8,label=Group),size=5,hjust=0,color='black')+
  geom_text(data=final.number.lag,aes(x=x,y=28,label=label),size=5,hjust=0.5,color='black')+
  
  # geom_text(data=fit_summary_df_selected,aes(x=x,y=y3,label=P_interaction),size=4,hjust=0.5)+
  
  annotate("text", x = 39, y = 0, label = "PC of resistance genes per isolate (%), 95% CI",fontface = "bold",color='#ec7784', size = 5, hjust = 0)+
  annotate("text", x = 39, y = -8, label = "Lag time (months)",fontface = "bold",color='black', size = 5, hjust = 0.5)+
  annotate("text", x = 39, y =28, label = "P -values",fontface = "bold",color='black', size = 5, hjust = 0.5)

ggsave( last_plot(),
        width = 10,height =12,
        filename =  paste0("图片/lag_number.pdf"))



names(final.number.lag)
ggplot(data=final.number.lag[20:37,])+
  geom_ribbon(aes(x =term,ymin =Lower , ymax = Upper, group = 1),alpha = 0.3, fill = "#ec7784")+
  geom_line(aes(x = term, y = OR , group = 1),color="#ec7784",linewidth=0.5) + 
  
  # facet_wrap(~ sp_name,ncol = 2,nrow =5,  scales = "free_y",strip.position = "top")+
  # geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  # scale_x_continuous(limits = c(0,18),breaks = seq(0,12,1), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "PC of resistance genes per isolate (%), 95% CI")+
  theme(
    text = element_text(size = 12),  
    plot.title = element_text(face = "bold"),  
    legend.title = element_text(face = "italic"),  
    legend.position = "bottom",  
    panel.background = element_rect(fill = "white"),
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
    axis.text= element_text(color="black",size = 10),
    axis.ticks =element_line(color = "black")
  )
ggsave( last_plot(),
        width = 10,height =8,
        filename =  paste0("图片/lag_number.pdf"))

ggplot(data=final.number.lag[0:19,])+
  geom_ribbon(aes(x =term,ymin =Lower , ymax = Upper, group = 1),alpha = 0.3, fill = "#ec7784")+
  geom_line(aes(x = term, y = OR , group = 1),color="#ec7784",linewidth=0.5) + 
  
  # facet_wrap(~ sp_name,ncol = 2,nrow =5,  scales = "free_y",strip.position = "top")+
  # geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  # scale_x_continuous(limits = c(0,18),breaks = seq(0,12,1), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "PC of resistance genes per isolate (%), 95% CI")+
  theme(
    text = element_text(size = 12),  
    plot.title = element_text(face = "bold"),  
    legend.title = element_text(face = "italic"),  
    legend.position = "bottom",  
    panel.background = element_rect(fill = "white"),
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
    axis.text= element_text(color="black",size = 10),
    axis.ticks =element_line(color = "black")
  )


######5.2or值####

Group1<-c( 'Beta-lactam',
           'Aminoglycoside',
           'Quinolone',
           'Fosfomycin',
           'Tetracycline',
           'Efflux',
           'Phenicol',
           'Macrolide',
           'Glycopeptide',
           'Sulfonamide',
           'Trimethoprim',
           'Streptogramin',
           'Lincosamide',
           'Colistin',
           'Streptothricin',
           'Bleomycin',
           'Rifamycin',
           'Fosmidomycin',
           'Fluoroquinolone',
           'Multidrug',
           # 'Pleuromutilin',
           # 'Fusidic acid',
           # 'Mupirocin',
           'Other antibiotic genes')
dependent_variables <-c('Beta_lactam',
                        'Aminoglycoside',
                        'Quinolone',
                        'Fosfomycin',
                        'Tetracycline',
                        'Efflux',
                        'Phenicol',
                        'Macrolide',
                        'Glycopeptide',
                        'Sulfonamide',
                        'Trimethoprim',
                        'Streptogramin',
                        'Lincosamide',
                        'Colistin',
                        'Streptothricin',
                        'Bleomycin',
                        'Rifamycin',
                        'Fosmidomycin',
                        'Fluoroquinolone',
                        'Multidrug',
                        # 'Pleuromutilin',
                        # 'Fusidic_acid',
                        # 'Mupirocin',
                        'Other_antibiotic_genes')

names(paper.data.1)
paper.data.total.1<-cbind(paper.data.1[c(1:78,131:148)],paper.data.total)

names(paper.data.total.1)
# 对指定列进行处理
for (col in cols_to_process) {
  paper.data.total.1[, col][paper.data.total.1[, col]!= 0] <- 1
}
df_new_names<-names(paper.data.total.1)
df_new_names[c(117,118)]<-c("Beta_lactam","Other_antibiotic_genes")

colnames(paper.data.total.1) <- df_new_names  


# PM2_5_match13_24 <- read_csv("PM2.5_match13-24.csv")
# PM2_5_match13_24 <- PM2_5_match13_24 %>% mutate(ID = paste(BioSample, `Scientific name`))
# 
# 
# names(PM2_5_match13_24)
# PM2_5_match13_24 <- PM2_5_match13_24[16:22]
# paper.data.total.1 <- merge(paper.data.total.1, PM2_5_match13_24, by = "ID", all.x = TRUE)
paper.data.total.10<-paper.data.total.1%>%mutate(average_pm25_0=average_pm25_0/10,
                                                 average_pm25_1=average_pm25_1/10,
                                                 average_pm25_2=average_pm25_2/10,
                                                 average_pm25_3=average_pm25_3/10,
                                                 average_pm25_4=average_pm25_4/10,
                                                 average_pm25_5=average_pm25_5/10,
                                                 average_pm25_6=average_pm25_6/10,
                                                 average_pm25_7=average_pm25_7/10,
                                                 average_pm25_8=average_pm25_8/10,
                                                 average_pm25_9=average_pm25_9/10,
                                                 average_pm25_10=average_pm25_10/10,
                                                 average_pm25_11=average_pm25_11/10,
                                                 average_pm25_12=average_pm25_12/10,
                                                 average_pm25_13=average_pm25_13/10,
                                                 average_pm25_14=average_pm25_14/10,
                                                 average_pm25_15=average_pm25_15/10,
                                                 average_pm25_16=average_pm25_16/10,
                                                 average_pm25_17=average_pm25_17/10,
                                                 average_pm25_18=average_pm25_18/10,
                                                 average_pm25_01=(average_pm25_1+average_pm25_0)/2,
                                                 average_pm25_02=(average_pm25_2+average_pm25_1+average_pm25_0)/3,
                                                 average_pm25_03=(average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/4,
                                                 average_pm25_04=(average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/5,
                                                 average_pm25_05=(average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/6,
                                                 average_pm25_06=(average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/7,
                                                 average_pm25_07=(average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/8,
                                                 average_pm25_08=(average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/9,
                                                 average_pm25_09=(average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/10,
                                                 average_pm25_010=(average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/11,
                                                 average_pm25_011=average_pm25/10,
                                                 average_pm25_012=(average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/13,
                                                 average_pm25_013=(average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/14,
                                                 average_pm25_014=(average_pm25_14+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/15,
                                                 average_pm25_015=(average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/16,
                                                 average_pm25_016=(average_pm25_16+average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/17,
                                                 average_pm25_017=(average_pm25_17+average_pm25_16+average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/18,
                                                 average_pm25_018=(average_pm25_18+average_pm25_17+average_pm25_16+average_pm25_15+average_pm25_014+average_pm25_13+average_pm25_12+average_pm25_11+average_pm25_10+average_pm25_9+average_pm25_8+average_pm25_7+average_pm25_6+average_pm25_5+average_pm25_4+average_pm25_3+average_pm25_2+average_pm25_1+average_pm25_0)/19,
)



final.or.lag<-data.frame() 
for (j in 1:length(formula)) {
  final.or<-data.frame() 
  for (i in 1:length(dependent_variables)) {
    coef=sum(paper.data.total[Group1[i]])/sum(rowSums(paper.data.total[, 2:22], na.rm = TRUE))
    Number=sum(paper.data.total[Group1[i]])
    model <- glm(as.formula(paste(dependent_variables[i],formula[j])) ,
                 family = binomial(link = "logit"), 
                 data=paper.data.total.10)
    fit_df<-tidy(model)%>%
      mutate(OR=exp(estimate),
             P=formatC(p.value, digits = 3, format = "f"),
             Lower=exp(estimate-1.96*std.error),
             Upper=exp(estimate+1.96*std.error),
             label=ifelse(p.value <0.001,'<0.001',P),
             Group=Group1[i],
             coef=coef,
             Number=Number) %>%
      mutate(CI = paste(formatC(OR, digits = 2, format = "f"),
                        " (", formatC(Lower, digits = 2, format = "f"), ",",
                        formatC(Upper, digits = 2, format = "f"), ")"))
    
    
    
    fit_df<-subset(fit_df, grepl("average_pm25", term))
    
    final.or<-rbind(final.or,fit_df)
  }
  
  
  
  final.or22<-c("average_pm25",as.numeric(mean(final.or$estimate)),as.numeric(mean(final.or$std.error)),NA,NA,as.numeric(sum(final.or$OR*final.or$coef)),NA,as.numeric(sum(final.or$Lower*final.or$coef)),as.numeric(sum(final.or$Upper*final.or$coef)),"<0.001","Total",1,sum(rowSums(paper.data.total[, 2:22], na.rm = TRUE)),NA)
  final.or<-rbind(final.or,final.or22)
  
  final.or[22,14]<-paste(formatC(as.numeric(final.or[22,6]), digits = 2, format = "f"),
                         " (", formatC(as.numeric(final.or[22,8]), digits = 2, format = "f"), ",",
                         formatC(as.numeric(final.or[22,9]), digits = 2, format = "f"), ")")
  
  
  
  final.or<-final.or%>%mutate(OR=as.numeric(OR),
                              Lower=as.numeric(Lower),
                              Upper=as.numeric(Upper))
  final.or$Group=Group[j]
  final.or<-final.or[22,]
  final.or.lag<-rbind(final.or.lag,final.or)
  print(j)
}

final.or.lag<-final.or.lag%>%
  mutate(
    x=rev(c(1:37)),
    
    fontface=c("plain",
               
               "plain","plain","plain","plain","plain","plain","plain","plain","plain","plain",
               "plain","plain","plain","plain","plain","plain","plain","plain","plain","plain",
               "plain","plain","plain","plain","plain","plain","plain","plain","plain","plain",
               "plain","plain","plain","plain","plain","plain"),
    term=factor(Group, 
                levels = c(
                  final.or.lag$Group))
  )


ggplot(data = final.or.lag)+
  # scale_color_manual(values = color1)+
  geom_hline(aes(yintercept = 1),linetype="dashed",linewidth=0.3,color="black")+
  
  geom_vline(aes(xintercept = 38),linetype="solid",linewidth=0.5,color="black")+
  # geom_vline(aes(xintercept = 0),linetype="solid",linewidth=0.5,color="black")+
  geom_point(aes(x =x, y = OR),size=2,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
             #,shape=forest$Shape
  )+
  geom_errorbar(aes(x = x,ymin = Lower, ymax = Upper),color='#ec7784',size=0.6,width=0,position = position_dodge(width = 0.6),alpha=1)+
  
  
  # geom_point(aes(x =24, y = 5.5),size=1.5,color='#ec7784',stroke=0.5,position = position_dodge(width = 0.6)
  #            #,shape=forest$Shape
  # )+
  # geom_errorbar(aes(x = 24,ymin = 4.83, ymax = 6.14),color='#ec7784',size=0.2,width=0,position = position_dodge(width = 0.6),alpha=1)+
  # 
  
  
  ylab(NULL) + xlab(NULL)+
  theme_bw()+
  theme(
    
    panel.border = element_blank(),  
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),  
    strip.background = element_rect(fill = 'white'),
    axis.text.x = element_text(size = 14,face="bold"),
    axis.text.y = element_blank(),   # 隐藏y轴标签
    axis.ticks.y = element_blank(), # 隐藏y轴刻度线
    # axis.line.y = element_blank() 
    axis.line.x = element_line(color = "black")
  )+
  scale_y_continuous(limits = c(0.7,1.8),breaks = seq(1.0,1.3,0.1))+ 
  scale_x_continuous(limits = c(1,39),expand = c(0.02, 0.02))+
  coord_flip()+
  
  # facet_wrap( ~ Function.name,nrow = 2)+
  geom_text(data=final.or.lag,aes(x=x,y=1.5,label=CI),size=5,hjust=0.5,color='#ec7784')+
  geom_text(data=final.or.lag,aes(x=x,y=0.75,label=Group),size=5,hjust=0,color='black')+
  geom_text(data=final.or.lag,aes(x=x,y=1.75,label=label),size=5,hjust=0.5,color='black')+
  
  # geom_text(data=fit_summary_df_selected,aes(x=x,y=y3,label=P_interaction),size=4,hjust=0.5)+
  
  annotate("text", x = 39, y = 1, label = "OR of carrying at least one resistence gene, 95% CI",fontface = "bold",color='#ec7784', size = 5, hjust = 0)+
  annotate("text", x = 39, y = 0.755, label = "Lag time (months)",fontface = "bold",color='black', size = 5, hjust = 0.5)+
  annotate("text", x = 39, y =1.75, label = "P -values",fontface = "bold",color='black', size = 5, hjust = 0.5)

ggsave( last_plot(),
        width = 10,height =12,
        filename =  paste0("图片/lag_or.pdf"))







###### 2.2拟合带有限制性立方样条的模型####
pred.number<-data.frame(A=1:200) 


for (i in 1:length(list)) {
  ddist <- datadist(list[[i]])
  options(datadist = "ddist")
  ddist$limits["Adjust to", 'average_pm25'] <- 1
  model_rcs <- rms::Glm(as.formula(paste("Total.genes ~ rcs(average_pm25, 3) +GDP_per_capita+ Population_density+ Mortality_rate_of_infant+ Population_ages_65_and_above+Current_health_expenditure_per_capita+People_using_at_least_basic_drinking_water_services+average_pre+average_tmp")),
                        # family = binomial(link = "logit"),
                        data = list[[i]])
  
  
  # 生成预测数据
  pred <- data.frame(Predict(model_rcs, average_pm25, 
                             # fun = exp,
                             ref.zero =T)[c("average_pm25","yhat","lower","upper")])
  # paste0(c("average_pm25","yhat","lower","upper"),"_",dependent_variables[i])
  names(pred)<-paste0(c("average_pm25","yhat","lower","upper"),"_",name.4[i])
  
  pred.number<-cbind(pred.number,pred)
  
  
}
names(pred.number)[seq(from = 3, by = 4, length.out = 14)]


writeLines(paste0("geom_line( aes(x = average_pm25_Total_bacterim  , y =", names(pred.number)[seq(from = 3, by = 4, length.out = 14)],"), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
                    geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =", names(pred.number)[seq(from = 4, by = 4, length.out = 14)],", ymax =" ,names(pred.number)[seq(from = 5, by = 4, length.out = 14)],"), alpha = 0.05, fill = 'blue')+") )









# 绘制曲线
ggplot(data = pred.number) +
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Total_bacterim), linetype = 'solid', size = 1, alpha = 0.5, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Total_bacterim, ymax =upper_Total_bacterim), alpha = 0.2, fill = 'blue')+
  
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Escherichia_coli), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Escherichia_coli, ymax =upper_Escherichia_coli), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Klebsiella_pneumoniae), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Klebsiella_pneumoniae, ymax =upper_Klebsiella_pneumoniae), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Staphylococcus_aureus), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Staphylococcus_aureus, ymax =upper_Staphylococcus_aureus), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Enterococcus_faecium), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Enterococcus_faecium, ymax =upper_Enterococcus_faecium), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Acinetobacter_baumannii), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Acinetobacter_baumannii, ymax =upper_Acinetobacter_baumannii), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Pseudomonas_aeruginosa), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Pseudomonas_aeruginosa, ymax =upper_Pseudomonas_aeruginosa), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Salmonella_enterica), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Salmonella_enterica, ymax =upper_Salmonella_enterica), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Clostridioides_difficile), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Clostridioides_difficile, ymax =upper_Clostridioides_difficile), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Streptococcus_pneumoniae), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Streptococcus_pneumoniae, ymax =upper_Streptococcus_pneumoniae), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Listeria_monocytogenes), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Listeria_monocytogenes, ymax =upper_Listeria_monocytogenes), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Mycobacterium_tuberculosis), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Mycobacterium_tuberculosis, ymax =upper_Mycobacterium_tuberculosis), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Streptococcus_agalactiae), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Streptococcus_agalactiae, ymax =upper_Streptococcus_agalactiae), alpha = 0.05, fill = 'blue')+
  geom_line( aes(x = average_pm25_Total_bacterim  , y =yhat_Other_bacteria), linetype = 'solid', size = 1, alpha = 0.1, color = 'red')+
  geom_ribbon( aes(x = average_pm25_Total_bacterim  , ymin =lower_Other_bacteria, ymax =upper_Other_bacteria), alpha = 0.05, fill = 'blue')+
  
  
  geom_hline(yintercept=0, linetype=2, color="black") +
  geom_vline(xintercept=10, linetype=2, color="blue") +
  
  labs(x = bquote("PM"[2.5]~(μg/m^3)), y = "Number of antibiotic resistance genes ")+
  
  theme_bw() +
  theme(
    axis.line=element_line(),
    panel.grid=element_blank()
    # , plot.title = element_text(hjust = 0.5)
  ) 




# model_rcs <- rms::Glm(Beta_lactam ~ rcs(average_pm25, 3) +
#                         GDP_per_capita+
#                    Population_density+
#                    Mortality_rate_of_infant+
#                    Population_ages_65_and_above+
#                    #PM2.5_air_pollution+
#                    Current_health_expenditure_per_capita+
#                    #Hospital_beds+
#                    # Labor_force_with_advanced_education+
#                    People_using_at_least_basic_drinking_water_services+
#                    # Antibiotic_consumption+
#                      flood_index+
# 
#                     # average_pm25+
#                    # average_pm25_1+
#                    # average_pm25_2+
#                    # #average_pm25_3+
#                    # average_pm25_4+
#                    # #average_pm25_5+
#                    # #average_pm25_6+
#                    # #average_pm25_7+
# 
# 
# 
#                    #average_tmp_0+
#                  #average_tmp_1+
#                  #average_tmp_2+
#                   average_tmp+
#                     average_pre
#                    # , family = binomial(link = "logit")
#                  ,data = paper.data.total.1)











summary(model)
# 获取模型系数
coefficients <- summary(model)$coefficients[, 1]

# 将系数转换为OR值
or_values <- exp(coefficients)

# 查看OR值
print(or_values)

names(paper.data.1)
dependent_variables <-c("TETRACYCLINE","MACROLIDE","AMINOGLYCOSIDE","COLISTIN","EFFLUX","FOSFOMYCIN","STREPTOTHRICIN","QUINOLONE","SULFONAMIDE","TRIMETHOPRIM",
                        "BLEOMYCIN","PHENICOL","RIFAMYCIN","FOSMIDOMYCIN", "NITROFURAN",
                        "STREPTOGRAMIN",  "LINCOSAMIDE"  ,   "MULTIDRUG" , "PLEUROMUTILIN","GLYCOPEPTIDE","MUPIROCIN", "FUSIDIC_ACID",
                        "OXAZOLIDINONE" , "FLUOROQUINOLONE","IONOPHORE","LIPOPEPTIDE","NITROIMIDAZOLE","AVILAMYCIN",
                        "BACITRACIN",
                        "AMINOCOUMARIN",
                        "ISONIAZID","BETA_LACTAM", "TRICLOSAN", 
                        "QUATERNARY_AMMONIUM" 
)

independent_variables <-  c (
  
  'GDP_per_capita',
  'Population_density',
  "Mortality_rate_of_infant",
  "Population_ages_65_and_above",
  #"PM2.5_air_pollution",
  "Current_health_expenditure_per_capita",
  #"Hospital_beds",
  #"Labor_force_with_advanced_education",
  "People_using_at_least_basic_drinking_water_services",
  "average_pm25",
  "average_tmp"
  # ,
  # "average_pre_0"
)



final<-data.frame()  
for (dep_var in dependent_variables) {
  final2<-data.frame()  
  for (pm25 in names(paper.data.1)[20:32]){
    independent_variables <-  c (
      # "flood_in_new",     
      # "flood_one_new",    
      # "flood_two_new",    
      # "flood_three_new",  
      # "flood_four_new",   
      # "flood_five_new",   
      # "flood_six_new",    
      # "flood_seven_new",  
      # "flood_eight_new",  
      # "flood_nine_new",  
      # "flood_ten_new",
      # "flood_eleven_new", 
      # "flood_twelve_new",
      'GDP_per_capita',
      'Population_density',
      "Mortality_rate_of_infant",
      "Population_ages_65_and_above",
      #"PM2.5_air_pollution",
      "Current_health_expenditure_per_capita",
      #"Hospital_beds",
      #"Labor_force_with_advanced_education",
      "People_using_at_least_basic_drinking_water_services",
      pm25,
      "average_tmp_0",
      "average_pre_0"
    )
    formula_string <- paste(dep_var, paste(independent_variables, collapse = " + "), sep = " ~ ")
    formula <- reformulate(response = dep_var, termlabels = independent_variables)
    
    # 使用模型公式
    
    model <- glm(formula,data = paper.data.1)
    
    # vif=data.frame(vif(model))
    # vif <- rownames_to_column(vif, var = "independent_variables")
    
    parameter<-data.frame(summary( model)[["coefficients"]],Antibiotic=dep_var)[8,]
    parameter <- data.frame(rownames_to_column(parameter, var = "independent_variables"))
    parameter<-parameter%>% mutate(Lower=Estimate-1.96*Std..Error,Upper=Estimate+1.96*Std..Error)
    
    parameter<-parameter[,-c(3:4)]
    final1<-parameter
    # final1<-plyr::join_all(list(vif,parameter),
    #                        by='independent_variables', type='left')
    
    # fit <- loess(Lower ~ month,data =final1 )
    # 
    # # 获取平滑后的值
    # final1$Lower <- predict(fit)
    # fit <- loess(Upper ~ month,data =final1 )
    # final1$Upper <- predict(fit)
    # fit <- loess(Estimate ~ month,data =final1 )
    # final1$Estimate <- predict(fit)
    
    final2<-rbind(final2,final1)
  }
  
  final<-rbind(final,final2)
  
}

final$independent_variables<-factor(final$independent_variables, 
                                    levels =names(paper.data.1)[47:59])


p3.1<-ggplot()+
  # geom_ribbon(data=final,aes(x =independent_variables ,ymin =Lower , ymax = Upper),alpha = 0.3, fill = "#f0422d")+
  geom_errorbar(data=final,aes(x =independent_variables ,ymin =Lower*10 , ymax = Upper*10),size=0.5,width=0.25,position = position_dodge(width = 0.6),alpha=1,color="black")+
  geom_point(data=final, aes(x = independent_variables, y = Estimate*10 ),color="#f0422d",size =1) + 
  
  facet_wrap(~ Antibiotic,ncol = 5,nrow =7,  scales = "free_y",strip.position = "top")+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  # scale_x_continuous(limits = c(0,13),breaks = seq(1,12,1), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "Number of antibiotic resistance genes in genome")+
  theme(axis.text.x = element_text(angle = -45, hjust = 0),
        text = element_text(size = 12),  
        plot.title = element_text(face = "bold"),  
        legend.title = element_text(face = "italic"),  
        legend.position = "bottom",  
        panel.background = element_rect(fill = "white"),
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
        axis.text= element_text(color="black",size = 10),
        axis.ticks =element_line(color = "black")
  )

p3.1


final<-data.frame()  
for (dep_var in dependent_variables) {
  final2<-data.frame()  
  for (pm25 in names(paper.data.1)[60:71]){
    independent_variables <-  c (
      # "flood_in_new",     
      # "flood_one_new",    
      # "flood_two_new",    
      # "flood_three_new",  
      # "flood_four_new",   
      # "flood_five_new",   
      # "flood_six_new",    
      # "flood_seven_new",  
      # "flood_eight_new",  
      # "flood_nine_new",  
      # "flood_ten_new",
      # "flood_eleven_new", 
      # "flood_twelve_new",
      'GDP_per_capita',
      'Population_density',
      "Mortality_rate_of_infant",
      "Population_ages_65_and_above",
      #"PM2.5_air_pollution",
      "Current_health_expenditure_per_capita",
      #"Hospital_beds",
      #"Labor_force_with_advanced_education",
      "People_using_at_least_basic_drinking_water_services",
      pm25,
      "average_pm25_0",
      
      "average_pre_0"
    )
    formula_string <- paste(dep_var, paste(independent_variables, collapse = " + "), sep = " ~ ")
    formula <- reformulate(response = dep_var, termlabels = independent_variables)
    
    # 使用模型公式
    
    model <- glm(formula,data = paper.data.1)
    
    # vif=data.frame(vif(model))
    # vif <- rownames_to_column(vif, var = "independent_variables")
    
    parameter<-data.frame(summary( model)[["coefficients"]],Antibiotic=dep_var)[8,]
    parameter <- data.frame(rownames_to_column(parameter, var = "independent_variables"))
    parameter<-parameter%>% mutate(Lower=Estimate-1.96*Std..Error,Upper=Estimate+1.96*Std..Error)
    
    parameter<-parameter[,-c(3:4)]
    final1<-parameter
    # final1<-plyr::join_all(list(vif,parameter),
    #                        by='independent_variables', type='left')
    
    # fit <- loess(Lower ~ month,data =final1 )
    # 
    # # 获取平滑后的值
    # final1$Lower <- predict(fit)
    # fit <- loess(Upper ~ month,data =final1 )
    # final1$Upper <- predict(fit)
    # fit <- loess(Estimate ~ month,data =final1 )
    # final1$Estimate <- predict(fit)
    
    final2<-rbind(final2,final1)
  }
  
  final<-rbind(final,final2)
  
}

final$independent_variables<-factor(final$independent_variables, 
                                    levels =names(paper.data.1)[60:71])


p3.2<-ggplot()+
  # geom_ribbon(data=final,aes(x =independent_variables ,ymin =Lower , ymax = Upper),alpha = 0.3, fill = "#f0422d")+
  geom_errorbar(data=final,aes(x =independent_variables ,ymin =Lower , ymax = Upper),size=0.5,width=0.25,position = position_dodge(width = 0.6),alpha=1,color="black")+
  geom_point(data=final, aes(x = independent_variables, y = Estimate ),color="#f0422d",size =1) + 
  
  facet_wrap(~ Antibiotic,ncol = 5,nrow =7,  scales = "free_y",strip.position = "top")+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  # scale_x_continuous(limits = c(0,13),breaks = seq(1,12,1), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "Number of antibiotic resistance genes in genome")+
  theme(axis.text.x = element_text(angle = -45, hjust = 0),
        text = element_text(size = 12),  
        plot.title = element_text(face = "bold"),  
        legend.title = element_text(face = "italic"),  
        legend.position = "bottom",  
        panel.background = element_rect(fill = "white"),
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
        axis.text= element_text(color="black",size = 10),
        axis.ticks =element_line(color = "black")
  )
p3.2

final<-data.frame()  
for (dep_var in dependent_variables) {
  final2<-data.frame()  
  for (pm25 in names(paper.data.1)[73:85]){
    independent_variables <-  c (
      # "flood_in_new",     
      # "flood_one_new",    
      # "flood_two_new",    
      # "flood_three_new",  
      # "flood_four_new",   
      # "flood_five_new",   
      # "flood_six_new",    
      # "flood_seven_new",  
      # "flood_eight_new",  
      # "flood_nine_new",  
      # "flood_ten_new",
      # "flood_eleven_new", 
      # "flood_twelve_new",
      'GDP_per_capita',
      'Population_density',
      "Mortality_rate_of_infant",
      "Population_ages_65_and_above",
      #"PM2.5_air_pollution",
      "Current_health_expenditure_per_capita",
      #"Hospital_beds",
      #"Labor_force_with_advanced_education",
      "People_using_at_least_basic_drinking_water_services",
      pm25,
      "average_pm25_0",
      
      "average_tmp_0"
    )
    formula_string <- paste(dep_var, paste(independent_variables, collapse = " + "), sep = " ~ ")
    formula <- reformulate(response = dep_var, termlabels = independent_variables)
    
    # 使用模型公式
    
    model <- glm(formula,data = paper.data.1)
    
    # vif=data.frame(vif(model))
    # vif <- rownames_to_column(vif, var = "independent_variables")
    
    parameter<-data.frame(summary( model)[["coefficients"]],Antibiotic=dep_var)[8,]
    parameter <- data.frame(rownames_to_column(parameter, var = "independent_variables"))
    parameter<-parameter%>% mutate(Lower=Estimate-1.96*Std..Error,Upper=Estimate+1.96*Std..Error)
    
    parameter<-parameter[,-c(3:4)]
    final1<-parameter
    # final1<-plyr::join_all(list(vif,parameter),
    #                        by='independent_variables', type='left')
    
    # fit <- loess(Lower ~ month,data =final1 )
    # 
    # # 获取平滑后的值
    # final1$Lower <- predict(fit)
    # fit <- loess(Upper ~ month,data =final1 )
    # final1$Upper <- predict(fit)
    # fit <- loess(Estimate ~ month,data =final1 )
    # final1$Estimate <- predict(fit)
    
    final2<-rbind(final2,final1)
  }
  
  final<-rbind(final,final2)
  
}

final$independent_variables<-factor(final$independent_variables, 
                                    levels =names(paper.data.1)[73:85])


p3.3<-ggplot()+
  # geom_ribbon(data=final,aes(x =independent_variables ,ymin =Lower , ymax = Upper),alpha = 0.3, fill = "#f0422d")+
  geom_errorbar(data=final,aes(x =independent_variables ,ymin =Lower*1000 , ymax = Upper*1000),size=0.5,width=0.25,position = position_dodge(width = 0.6),alpha=1,color="black")+
  geom_point(data=final, aes(x = independent_variables, y = Estimate*1000 ),color="#f0422d",size =1) + 
  
  facet_wrap(~ Antibiotic,ncol = 5,nrow =7,  scales = "free_y",strip.position = "top")+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  # scale_x_continuous(limits = c(0,13),breaks = seq(1,12,1), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "Number of antibiotic resistance genes in genome")+
  theme(axis.text.x = element_text(angle = -45, hjust = 0),
        text = element_text(size = 12),  
        plot.title = element_text(face = "bold"),  
        legend.title = element_text(face = "italic"),  
        legend.position = "bottom",  
        panel.background = element_rect(fill = "white"),
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
        axis.text= element_text(color="black",size = 10),
        axis.ticks =element_line(color = "black")
  )
p3.3




sort(table(paper.data.1$`Scientific name`))



specific.name <-  c (" ",'Escherichia coli',
                     'Staphylococcus aureus',
                     "Klebsiella pneumoniae",
                     "Acinetobacter baumannii",
                     "Pseudomonas aeruginosa",
                     "Enterococcus faecium",
                     "Streptococcus pneumoniae",
                     "Salmonella enterica")


final.sp<-data.frame()  
for (dep_var in specific.name) {
  formula_string <- paste("total_antibiotic", paste(independent_variables, collapse = " + "), sep = " ~ ")
  formula <- reformulate(response = "total_antibiotic", termlabels = independent_variables)
  
  # 使用模型公式
  
  model <- glm(formula,data = paper.data.1[grepl(dep_var, paper.data.1$`Scientific name`), ])
  
  vif=data.frame(vif(model))
  vif <- rownames_to_column(vif, var = "independent_variables")[10:22,]
  if(dep_var == " "){
    parameter<-data.frame(summary( model)[["coefficients"]],sp_name="All isolates")
  }else{parameter<-data.frame(summary( model)[["coefficients"]],sp_name=dep_var)}
  
  parameter <- data.frame(rownames_to_column(parameter, var = "independent_variables")[11:23,],month=as.numeric(0:12))
  parameter<-parameter%>% mutate(Lower=Estimate-1.96*Std..Error,Upper=Estimate+1.96*Std..Error)
  
  parameter<-parameter[,-c(3:4)]
  final1<-plyr::join_all(list(vif,parameter),
                         by='independent_variables', type='left')
  
  # fit <- loess(Lower ~ month,data =final1 )
  # 
  # # 获取平滑后的值
  # final1$Lower <- predict(fit)
  # fit <- loess(Upper ~ month,data =final1 )
  # final1$Upper <- predict(fit)
  # fit <- loess(Estimate ~ month,data =final1 )
  # final1$Estimate <- predict(fit)
  
  final.sp<-rbind(final.sp,final1)
}


model <- glm(formula,data = paper.data.1[!grepl('Escherichia coli',paper.data.1$`Scientific name`)&
                                           !grepl('Staphylococcus aureus',paper.data.1$`Scientific name`)&
                                           !grepl( 'Klebsiella pneumoniae',paper.data.1$`Scientific name`)&
                                           !grepl('Acinetobacter baumannii',paper.data.1$`Scientific name`)&
                                           !grepl('Pseudomonas aeruginosa',paper.data.1$`Scientific name`)&
                                           !grepl('Enterococcus faecium',paper.data.1$`Scientific name`)&
                                           !grepl('Streptococcus pneumoniae',paper.data.1$`Scientific name`)&
                                           !grepl('Salmonella enterica',paper.data.1$`Scientific name`), ])

vif=data.frame(vif(model))
vif <- rownames_to_column(vif, var = "independent_variables")[10:22,]

parameter<-data.frame(summary( model)[["coefficients"]],sp_name="Other")
parameter <- data.frame(rownames_to_column(parameter, var = "independent_variables")[11:23,],month=as.numeric(0:12))
parameter<-parameter%>% mutate(Lower=Estimate-1.96*Std..Error,Upper=Estimate+1.96*Std..Error)

parameter<-parameter[,-c(3:4)]
final1<-plyr::join_all(list(vif,parameter),
                       by='independent_variables', type='left')

fit <- loess(Lower ~ month,data =final1 )

# 获取平滑后的值
final1$Lower <- predict(fit)
fit <- loess(Upper ~ month,data =final1 )
final1$Upper <- predict(fit)
fit <- loess(Estimate ~ month,data =final1 )
final1$Estimate <- predict(fit)

final.sp<-rbind(final.sp,final1)








p4<-ggplot()+
  geom_ribbon(data=final.sp,aes(x =month,ymin =Lower , ymax = Upper),alpha = 0.3, fill = "#f0422d")+
  geom_line(data=final.sp, aes(x = month, y = Estimate ),color="#f0422d",linewidth=0.5) + 
  
  facet_wrap(~ sp_name,ncol = 2,nrow =5,  scales = "free_y",strip.position = "top")+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  scale_x_continuous(limits = c(0,13),breaks = seq(0,12,1), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "Number of antibiotic resistance genes in genome")+
  theme(
    text = element_text(size = 12),  
    plot.title = element_text(face = "bold"),  
    legend.title = element_text(face = "italic"),  
    legend.position = "bottom",  
    panel.background = element_rect(fill = "white"),
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
    axis.text= element_text(color="black",size = 10),
    axis.ticks =element_line(color = "black")
  )

p4


final.ecoli<-data.frame()  
for (dep_var in dependent_variables) {
  formula_string <- paste(dep_var, paste(independent_variables, collapse = " + "), sep = " ~ ")
  formula <- reformulate(response = dep_var, termlabels = independent_variables)
  
  # 使用模型公式
  
  model <- glm(formula,data = paper.data.1[grepl("Escherichia coli", paper.data.1$`Scientific name`), ])
  
  vif=data.frame(vif(model))
  vif <- rownames_to_column(vif, var = "independent_variables")[11:22,]
  
  parameter<-data.frame(summary( model)[["coefficients"]],Antibiotic=dep_var)
  parameter <- data.frame(rownames_to_column(parameter, var = "independent_variables")[12:23,],month=as.numeric(1:12))
  parameter<-parameter%>% mutate(Lower=Estimate-1.96*Std..Error,Upper=Estimate+1.96*Std..Error)
  
  parameter<-parameter[,-c(3:4)]
  final1<-plyr::join_all(list(vif,parameter),
                         by='independent_variables', type='left')
  
  fit <- loess(Lower ~ month,data =final1 )
  
  # 获取平滑后的值
  final1$Lower <- predict(fit)
  fit <- loess(Upper ~ month,data =final1 )
  final1$Upper <- predict(fit)
  fit <- loess(Estimate ~ month,data =final1 )
  final1$Estimate <- predict(fit)
  
  final.ecoli<-rbind(final.ecoli,final1)
}





p5<-ggplot()+
  geom_ribbon(data=final.ecoli,aes(x =month,ymin =Lower , ymax = Upper),alpha = 0.3, fill = "#f0422d")+
  geom_line(data=final.ecoli, aes(x = month, y = Estimate ),color="#f0422d",linewidth=0.5) + 
  
  facet_wrap(~ Antibiotic,ncol = 5,nrow =7,  scales = "free_y",strip.position = "top")+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  scale_x_continuous(limits = c(0,13),breaks = seq(1,12,1), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "Number of antibiotic resistance genes in genome")+
  theme(
    text = element_text(size = 12),  
    plot.title = element_text(face = "bold"),  
    legend.title = element_text(face = "italic"),  
    legend.position = "bottom",  
    panel.background = element_rect(fill = "white"),
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
    axis.text= element_text(color="black",size = 10),
    axis.ticks =element_line(color = "black")
  )

p5
paper.data.1$`Isolation type` <- ifelse(is.na(paper.data.1$`Isolation type`), "Environmental/Other", 
                                        ifelse(paper.data.1$`Isolation type`=="clinical", "Clinical",
                                               ifelse(paper.data.1$`Isolation type`=="environmental/other", "Environmental/Other",paper.data.1$`Isolation type`)))

sort(table(paper.data.1$`Isolation type`))

dependent_variables <-  c ('Clinical',
                           'Environmental/Other')


final.type<-data.frame()  
for (dep_var in dependent_variables) {
  formula_string <- paste("total_antibiotic", paste(independent_variables, collapse = " + "), sep = " ~ ")
  formula <- reformulate(response = "total_antibiotic", termlabels = independent_variables)
  
  # 使用模型公式
  
  model <- glm(formula,data = paper.data.1[grepl("Escherichia coli", paper.data.1$`Scientific name`)&grepl(dep_var, paper.data.1$`Isolation type`), ])
  
  vif=data.frame(vif(model))
  vif <- rownames_to_column(vif, var = "independent_variables")[10:22,]
  
  parameter<-data.frame(summary( model)[["coefficients"]],Antibiotic=dep_var)
  parameter <- data.frame(rownames_to_column(parameter, var = "independent_variables")[11:23,],month=as.numeric(0:12))
  parameter<-parameter%>% mutate(Lower=Estimate-1.96*Std..Error,Upper=Estimate+1.96*Std..Error)
  
  parameter<-parameter[,-c(3:4)]
  final1<-plyr::join_all(list(vif,parameter),
                         by='independent_variables', type='left')
  
  fit <- loess(Lower ~ month,data =final1 )
  
  # 获取平滑后的值
  final1$Lower <- predict(fit)
  fit <- loess(Upper ~ month,data =final1 )
  final1$Upper <- predict(fit)
  fit <- loess(Estimate ~ month,data =final1 )
  final1$Estimate <- predict(fit)
  
  final.type<-rbind(final.type,final1)
}





p6<-ggplot()+
  geom_ribbon(data=final.type,aes(x =month,ymin =Lower , ymax = Upper),alpha = 0.3, fill = "#f0422d")+
  geom_line(data=final.type, aes(x = month, y = Estimate ),color="#f0422d",linewidth=0.5) + 
  
  facet_wrap(~ Antibiotic,ncol = 1,nrow =2,  scales = "free_y",strip.position = "top")+
  geom_hline(yintercept = 0, linetype = "dashed", color = "black",linewidth=0.4,) + 
  scale_x_continuous(limits = c(0,13),breaks = seq(0,12,1), expand = c(0.01, 0))+
  scale_y_continuous(limits = c(-5,15),breaks = seq(-5,15,5), expand = c(0.01, 0))+
  labs(title = NULL, x = "Lag time (Months)", y = "Number of antibiotic resistance genes in genome")+
  theme(
    text = element_text(size = 12),  
    plot.title = element_text(face = "bold"),  
    legend.title = element_text(face = "italic"),  
    legend.position = "bottom",  
    panel.background = element_rect(fill = "white"),
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),  # 显示坐标轴线并设置颜色为黑色
    axis.text= element_text(color="black",size = 10),
    axis.ticks =element_line(color = "black")
  )

p6
















specific <- paper.data.1[grepl("Escherichia coli", paper.data.1$`Scientific name`), ]
